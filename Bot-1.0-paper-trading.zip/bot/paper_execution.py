from __future__ import annotations

from datetime import datetime, timezone
from math import floor
from typing import Callable

from bot.models import DecisionContext, OrderRequest
from bot.paper_portfolio import PaperPortfolioStore


class PaperExecution:
    """Fee-aware paper order sizing and local-only virtual execution."""

    def __init__(
        self,
        portfolio: PaperPortfolioStore,
        *,
        commission_rate: float = 0.0005,
        slippage_rate: float = 0.001,
        min_net_profit_percent: float = 0.2,
        max_position_percent: float = 10.0,
        risk_per_trade_percent: float = 1.0,
        stop_loss_percent: float = 2.0,
        max_quote_age_seconds: float = 120.0,
        clock: Callable[[], datetime] | None = None,
    ) -> None:
        if commission_rate < 0 or slippage_rate < 0:
            raise ValueError("commission_rate and slippage_rate must be non-negative")
        if not 0 <= min_net_profit_percent:
            raise ValueError("min_net_profit_percent must be non-negative")
        if not 0 < max_position_percent <= 100:
            raise ValueError("max_position_percent must be in (0, 100]")
        if not 0 < risk_per_trade_percent <= 100:
            raise ValueError("risk_per_trade_percent must be in (0, 100]")
        if not 0 < stop_loss_percent < 100:
            raise ValueError("stop_loss_percent must be in (0, 100)")
        if max_quote_age_seconds <= 0:
            raise ValueError("max_quote_age_seconds must be positive")
        self.portfolio = portfolio
        self.commission_rate = commission_rate
        self.slippage_rate = slippage_rate
        self.min_net_profit_rate = min_net_profit_percent / 100.0
        self.max_position_rate = max_position_percent / 100.0
        self.risk_per_trade_rate = risk_per_trade_percent / 100.0
        self.stop_loss_rate = stop_loss_percent / 100.0
        self.max_quote_age_seconds = max_quote_age_seconds
        self.clock = clock or (lambda: datetime.now(timezone.utc))

    def evaluate_buy(
        self,
        context: DecisionContext,
        *,
        equity: float,
        cash: float,
        current_position_quantity: int = 0,
    ) -> dict:
        stale_reason = self._stale_reason(context.timestamp)
        if stale_reason:
            return self._rejected(stale_reason)
        if context.price <= 0 or context.lot_size <= 0:
            return self._rejected("price and lot_size must be positive")
        if equity <= 0 or cash <= 0:
            return self._rejected("equity and cash must be positive")
        if current_position_quantity:
            return self._rejected("an open position already exists")

        atr = self._average_true_range(context)
        if atr is None:
            return self._rejected("not enough valid candle history to estimate fees")

        entry_quote = context.price
        expected_exit_quote = entry_quote + atr
        entry_cost_per_share = (
            entry_quote
            * (1 + self.slippage_rate)
            * (1 + self.commission_rate)
        )
        expected_exit_proceeds = (
            expected_exit_quote
            * (1 - self.slippage_rate)
            * (1 - self.commission_rate)
        )
        expected_net_rate = (
            expected_exit_proceeds - entry_cost_per_share
        ) / entry_cost_per_share
        target_price = (
            entry_cost_per_share * (1 + self.min_net_profit_rate)
            / ((1 - self.slippage_rate) * (1 - self.commission_rate))
        )
        if expected_net_rate < self.min_net_profit_rate:
            return self._rejected(
                "historical range does not clear round-trip fees and minimum net profit",
                expected_exit_price=expected_exit_quote,
                target_price=target_price,
                expected_net_profit_percent=expected_net_rate * 100,
            )

        stop_quote = entry_quote * (1 - self.stop_loss_rate)
        stop_proceeds_per_share = (
            stop_quote * (1 - self.slippage_rate) * (1 - self.commission_rate)
        )
        risk_per_share = max(entry_cost_per_share - stop_proceeds_per_share, 0.0)
        risk_budget = equity * self.risk_per_trade_rate
        max_position_value = equity * self.max_position_rate
        share_limit = min(
            cash / entry_cost_per_share,
            max_position_value / entry_cost_per_share,
            risk_budget / risk_per_share if risk_per_share else 0,
        )
        lot_size = context.lot_size
        quantity = floor(share_limit / lot_size) * lot_size
        if quantity < lot_size:
            return self._rejected(
                "cash, position limit, or risk budget is below one exchange lot",
                expected_exit_price=expected_exit_quote,
                target_price=target_price,
                expected_net_profit_percent=expected_net_rate * 100,
            )
        return {
            "approved": True,
            "quantity": quantity,
            "expected_exit_price": expected_exit_quote,
            "target_price": target_price,
            "expected_net_profit_percent": expected_net_rate * 100,
            "risk_budget": risk_budget,
            "reason": "BUY fits cash, lot, position, risk and fee-adjusted profit limits",
        }

    def exit_reason(self, context: DecisionContext, position, price: float) -> str | None:
        if price >= position.target_price:
            return "TAKE_PROFIT"
        if price <= position.average_price * (1 - self.stop_loss_rate):
            return "STOP_LOSS"
        return None

    def execute(
        self,
        order: OrderRequest,
        quote: DecisionContext,
        *,
        target_price: float | None = None,
    ) -> dict:
        stale_reason = self._stale_reason(quote.timestamp)
        if stale_reason:
            return {"status": "REJECTED", "reason": stale_reason}
        if order.ticker != quote.ticker or order.price <= 0:
            return {"status": "REJECTED", "reason": "order does not match a valid quote"}
        if order.quantity <= 0 or order.quantity % quote.lot_size:
            return {"status": "REJECTED", "reason": "quantity must be a positive whole number of lots"}

        snapshot = self.portfolio.snapshot({quote.ticker: quote.price})
        if order.side == "BUY":
            evaluation = self.evaluate_buy(
                quote,
                equity=snapshot.equity,
                cash=snapshot.cash,
                current_position_quantity=snapshot.positions.get(
                    quote.ticker, type("EmptyPosition", (), {"quantity": 0})()
                ).quantity,
            )
            if not evaluation["approved"] or order.quantity > evaluation["quantity"]:
                return {
                    "status": "REJECTED",
                    "reason": evaluation["reason"],
                }
            target_price = target_price or evaluation["target_price"]
            fill_price = quote.price * (1 + self.slippage_rate)
        elif order.side == "SELL":
            position = snapshot.positions.get(quote.ticker)
            if position is None or order.quantity > position.quantity:
                return {"status": "REJECTED", "reason": "insufficient virtual position"}
            reason = self.exit_reason(quote, position, quote.price)
            if reason is None:
                return {
                    "status": "REJECTED",
                    "reason": "price has not reached the profit target or risk stop",
                }
            fill_price = quote.price * (1 - self.slippage_rate)
        else:
            return {"status": "REJECTED", "reason": "side must be BUY or SELL"}

        try:
            result = self.portfolio.execute(
                order.ticker,
                order.side,
                order.quantity,
                fill_price,
                lot_size=quote.lot_size,
                target_price=target_price,
            )
        except ValueError as exc:
            return {"status": "REJECTED", "reason": str(exc)}
        result["quote_price"] = quote.price
        result["reason"] = "virtual paper execution"
        return result

    def _stale_reason(self, timestamp: datetime) -> str | None:
        if timestamp.tzinfo is None:
            timestamp = timestamp.replace(tzinfo=timezone.utc)
        age = (self.clock() - timestamp.astimezone(timezone.utc)).total_seconds()
        if age < -30 or age > self.max_quote_age_seconds:
            return f"stale quote ({age:.0f}s old)"
        return None

    @staticmethod
    def _average_true_range(context: DecisionContext) -> float | None:
        candles = context.candles
        if len(candles) < 15:
            return None
        ranges = []
        for index in range(len(candles) - 14, len(candles)):
            candle = candles[index]
            previous_close = candles[index - 1].close
            ranges.append(
                max(
                    candle.high - candle.low,
                    abs(candle.high - previous_close),
                    abs(candle.low - previous_close),
                )
            )
        return sum(ranges) / len(ranges) if ranges else None

    @staticmethod
    def _rejected(reason: str, **details) -> dict:
        return {"approved": False, "quantity": 0, "reason": reason, **details}
