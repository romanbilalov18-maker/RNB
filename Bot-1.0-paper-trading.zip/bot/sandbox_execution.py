from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any

from bot.models import OrderRequest
from bot.sandbox_reconciliation import SandboxOrderReconciler


@dataclass(frozen=True)
class SandboxAccountState:
    cash: float
    equity: float
    position_quantity: float
    average_price: float


@dataclass(frozen=True)
class SandboxPositionState:
    instrument_id: str
    figi: str
    quantity: float
    average_price: float


@dataclass(frozen=True)
class SandboxPortfolioState:
    cash: float
    equity: float
    positions: tuple[SandboxPositionState, ...]


class SandboxExecution:
    """Submit orders to the T-Bank Invest Sandbox.

    Internal bot quantities are shares. T-Invest order quantities are lots;
    this adapter performs the conversion at the API boundary.
    """

    def __init__(self, token: str, account_id: str | None = None):
        if not token or not token.strip():
            raise ValueError("T-Bank token is required")
        self.token = token.strip()
        self.account_id = account_id.strip() if account_id else None

    def get_account_state(self, ticker: str, price: float) -> SandboxAccountState:
        if not ticker:
            raise ValueError("ticker is required")
        if price <= 0:
            raise ValueError("price must be positive")

        try:
            from t_tech.invest import Client
        except ImportError as exc:
            raise RuntimeError(
                "T-Bank SDK is not installed; add t-tech-investments to requirements.txt"
            ) from exc

        with Client(self.token) as client:
            sandbox = getattr(client, "sandbox", None)
            if sandbox is None:
                raise RuntimeError("T-Bank SDK does not expose the Sandbox service")
            account_id = self.account_id or self._resolve_account_id(sandbox)
            self.account_id = account_id
            getter = getattr(sandbox, "get_sandbox_portfolio", None)
            if getter is None:
                raise RuntimeError("T-Bank SDK does not expose get_sandbox_portfolio")

            portfolio = getter(account_id=account_id)
            cash = _money_to_float(getattr(portfolio, "total_amount_currencies", None))
            if cash is None:
                raise RuntimeError("Sandbox portfolio does not contain currency balance")

            position_quantity = 0.0
            average_price = 0.0
            lot_size = self._get_lot_size(client, ticker)
            positions = getattr(portfolio, "positions", None) or []
            for position in positions:
                if getattr(position, "figi", "") != ticker:
                    continue
                # Sandbox portfolio position quantity is already expressed in
                # shares for the securities endpoint used by this SDK.
                position_quantity = _quantity_to_float(position)
                average_price = _money_to_float(
                    getattr(position, "average_position_price", None)
                    or getattr(position, "average_price", None)
                ) or 0.0
                break

            equity = _money_to_float(
                getattr(portfolio, "total_amount_portfolio", None)
            )
            if equity is None:
                raise RuntimeError(
                    "Sandbox portfolio does not contain total portfolio value"
                )

            return SandboxAccountState(
                cash=cash,
                equity=equity,
                position_quantity=position_quantity,
                average_price=average_price,
            )

    def get_portfolio_state(self) -> SandboxPortfolioState:
        try:
            from t_tech.invest import Client
        except ImportError as exc:
            raise RuntimeError(
                "T-Bank SDK is not installed; add t-tech-investments to requirements.txt"
            ) from exc

        with Client(self.token) as client:
            sandbox = getattr(client, "sandbox", None)
            if sandbox is None:
                raise RuntimeError("T-Bank SDK does not expose the Sandbox service")
            account_id = self.account_id or self._resolve_account_id(sandbox)
            self.account_id = account_id
            getter = getattr(sandbox, "get_sandbox_portfolio", None)
            if getter is None:
                raise RuntimeError("T-Bank SDK does not expose get_sandbox_portfolio")
            portfolio = getter(account_id=account_id)
            cash = _money_to_float(getattr(portfolio, "total_amount_currencies", None))
            equity = _money_to_float(getattr(portfolio, "total_amount_portfolio", None))
            if cash is None or equity is None:
                raise RuntimeError("Sandbox portfolio does not contain complete account totals")

            result = []
            for position in getattr(portfolio, "positions", None) or ():
                quantity_shares = _quantity_to_float(position)
                if quantity_shares == 0:
                    continue
                figi = str(getattr(position, "figi", None) or "")
                average_price = _money_to_float(
                    getattr(position, "average_position_price", None)
                    or getattr(position, "average_price", None)
                ) or 0.0
                result.append(
                    SandboxPositionState(
                        instrument_id=str(
                            getattr(position, "instrument_uid", None)
                            or getattr(position, "figi", None)
                            or ""
                        ),
                        figi=figi,
                        quantity=quantity_shares,
                        average_price=average_price,
                    )
                )
            return SandboxPortfolioState(
                cash=cash,
                equity=equity,
                positions=tuple(result),
            )

    def get_position(self, ticker: str) -> float:
        if not ticker:
            raise ValueError("ticker is required")
        try:
            from t_tech.invest import Client
        except ImportError as exc:
            raise RuntimeError(
                "T-Bank SDK is not installed; add t-tech-investments to requirements.txt"
            ) from exc
        with Client(self.token) as client:
            sandbox = getattr(client, "sandbox", None)
            if sandbox is None:
                raise RuntimeError("T-Bank SDK does not expose the Sandbox service")
            account_id = self.account_id or self._resolve_account_id(sandbox)
            self.account_id = account_id
            # Reconciler returns the remote position quantity in shares.
            return SandboxOrderReconciler(sandbox, account_id).get_position(ticker)

    def execute(self, order: OrderRequest) -> dict:
        try:
            from t_tech.invest import Client
        except ImportError as exc:
            raise RuntimeError(
                "T-Bank SDK is not installed; add t-tech-investments to requirements.txt"
            ) from exc

        with Client(self.token) as client:
            sandbox = getattr(client, "sandbox", None)
            if sandbox is None:
                raise RuntimeError("T-Bank SDK does not expose the Sandbox service")

            account_id = self.account_id or self._resolve_account_id(sandbox)
            self.account_id = account_id
            lot_size = self._get_lot_size(client, order.ticker)
            if order.quantity % lot_size != 0:
                raise ValueError(
                    f"Order quantity {order.quantity} shares is not a whole lot "
                    f"for {order.ticker} (lot_size={lot_size})"
                )

            response = self._post_order(sandbox, account_id, order, lot_size)
            order_id = getattr(response, "order_id", None)
            status = getattr(response, "execution_report_status", None)

            result = {
                "status": "SUBMITTED",
                "order_id": order_id,
                "account_id": account_id,
                "execution_report_status": str(status) if status is not None else None,
                "ticker": order.ticker,
                "side": order.side,
                "quantity": order.quantity,
                "quantity_lots": order.quantity // lot_size,
                "lot_size": lot_size,
                "price": order.price,
            }

            if not order_id:
                return result

            timeout = float(os.getenv("SANDBOX_ORDER_TIMEOUT", "30"))
            interval = float(os.getenv("SANDBOX_ORDER_POLL_INTERVAL", "2"))
            reconciler = SandboxOrderReconciler(sandbox, account_id)
            reconciled = reconciler.wait_for_completion(
                str(order_id),
                timeout_seconds=timeout,
                poll_interval_seconds=interval,
            )
            if reconciled.get("status") in {"FILLED", "CANCELLED", "REJECTED"}:
                # Reconciler already returns position quantities in shares.
                reconciled["position_quantity"] = reconciler.get_position(order.ticker)
            return {**result, **reconciled}

    @staticmethod
    def _resolve_account_id(sandbox: Any) -> str:
        getter = getattr(sandbox, "get_sandbox_accounts", None)
        if getter is None:
            raise RuntimeError("T-Bank SDK does not expose get_sandbox_accounts")

        response = getter()
        accounts = list(getattr(response, "accounts", ()) or ())
        if not accounts:
            opener = getattr(sandbox, "open_sandbox_account", None)
            if opener is None:
                raise RuntimeError(
                    "No Sandbox account found and SDK cannot open one automatically"
                )
            opener()
            response = getter()
            accounts = list(getattr(response, "accounts", ()) or ())

        if not accounts:
            raise RuntimeError("No T-Bank Sandbox account is available")

        account_id = getattr(accounts[0], "id", None)
        if not account_id:
            raise RuntimeError("Sandbox account response does not contain an account id")
        return str(account_id)

    @staticmethod
    def _get_lot_size(client: Any, ticker: str) -> int:
        finder = getattr(client.instruments, "find_instrument", None)
        if finder is None:
            return 1
        try:
            response = finder(query=ticker)
        except TypeError:
            try:
                from t_tech.invest import FindInstrumentRequest
                response = finder(request=FindInstrumentRequest(query=ticker))
            except (ImportError, TypeError):
                return 1

        instruments = list(getattr(response, "instruments", ()) or ())
        exact = next(
            (
                item for item in instruments
                if str(getattr(item, "figi", "") or "") == ticker
                or str(getattr(item, "instrument_uid", "") or "") == ticker
                or str(getattr(item, "ticker", "") or "") == ticker
            ),
            None,
        )
        lot_size = int(getattr(exact, "lot", 1) or 1) if exact is not None else 1
        return max(1, lot_size)

    @staticmethod
    def _post_order(
        sandbox: Any,
        account_id: str,
        order: OrderRequest,
        lot_size: int = 1,
    ) -> Any:
        try:
            from t_tech.invest import OrderDirection, OrderType, PriceType, Quotation
        except ImportError as exc:
            raise RuntimeError("Required T-Bank order types are unavailable") from exc

        direction = (
            OrderDirection.ORDER_DIRECTION_BUY
            if order.side == "BUY"
            else OrderDirection.ORDER_DIRECTION_SELL
        )

        requested_type = os.getenv("SANDBOX_ORDER_TYPE", "market").strip().lower()
        if requested_type == "limit":
            order_type = OrderType.ORDER_TYPE_LIMIT
        elif requested_type == "market":
            order_type = OrderType.ORDER_TYPE_MARKET
        else:
            raise ValueError("SANDBOX_ORDER_TYPE must be 'market' or 'limit'")

        price = Quotation(
            units=int(order.price),
            nano=int(round((order.price - int(order.price)) * 1_000_000_000)),
        )
        from uuid import uuid4
        order_id = str(uuid4())

        method = getattr(sandbox, "post_sandbox_order", None)
        if method is None:
            raise RuntimeError("T-Bank SDK does not expose post_sandbox_order")

        kwargs = {
            "figi": order.ticker,
            "quantity": int(order.quantity // lot_size),
            "price": price,
            "direction": direction,
            "order_type": order_type,
            "account_id": account_id,
            "order_id": order_id,
            "price_type": PriceType.PRICE_TYPE_CURRENCY,
        }

        try:
            return method(**kwargs)
        except TypeError:
            pass

        try:
            from t_tech.invest import PostSandboxOrderRequest
        except ImportError as exc:
            raise RuntimeError(
                "SDK post_sandbox_order signature is unsupported by this adapter"
            ) from exc

        request = PostSandboxOrderRequest(**kwargs)
        return method(request=request)


def _money_to_float(value: Any) -> float | None:
    if value is None:
        return None
    units = getattr(value, "units", None)
    nano = getattr(value, "nano", None)
    if units is None and nano is None:
        try:
            return float(value)
        except (TypeError, ValueError):
            return None
    return float(units or 0) + float(nano or 0) / 1_000_000_000


def _quantity_to_float(position: Any) -> float:
    for name in ("quantity", "quantity_lots", "balance"):
        value = getattr(position, name, None)
        if value is None:
            continue
        units = getattr(value, "units", None)
        nano = getattr(value, "nano", None)
        if units is not None or nano is not None:
            return float(units or 0) + float(nano or 0) / 1_000_000_000
        try:
            return float(value)
        except (TypeError, ValueError):
            continue

    units = getattr(position, "units", None)
    nano = getattr(position, "nano", None)
    if units is not None or nano is not None:
        return float(units or 0) + float(nano or 0) / 1_000_000_000

    return 0.0
