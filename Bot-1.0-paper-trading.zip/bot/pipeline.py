from dataclasses import dataclass

from bot.features import FeatureEngine
from bot.market_regime import MarketRegime, MarketRegimeEngine, RegimeResult
from bot.meta_decision import DecisionInput, MetaDecision, MetaDecisionEngine
from bot.model_decision import ModelDecisionEngine
from bot.outcome_model_decision import OutcomeModelDecisionEngine
from bot.models import DecisionContext, SignalResult
from bot.multi_strategy import MultiStrategyEngine, StrategyDecision
from bot.strategy import Strategy
from bot.trading_schedule import TradingSchedule


class _StrategyAdapter:
    def __init__(self, name: str, strategy: Strategy, ticker: str) -> None:
        self.name = name
        self.strategy = strategy
        self.ticker = ticker

    def evaluate(self, context: DecisionContext):
        if not context.candles:
            raise ValueError("decision context must contain historical candles")
        return self.strategy.evaluate(context)


@dataclass(frozen=True)
class DecisionPipelineResult:
    regime: RegimeResult
    strategies: tuple[StrategyDecision, ...]
    meta: MetaDecision
    model: object | None = None
    outcome: object | None = None


class TradingDecisionPipeline:
    """Connect regime, strategies, models, meta decision and trading schedule."""

    def __init__(self, ticker: str, *, min_confidence: float = 0.15, regime_engine: MarketRegimeEngine | None = None, model=None, outcome_model=None, feature_engine: FeatureEngine | None = None, model_weight: float = 1.0, outcome_min_win_probability: float = 0.4, trading_schedule: TradingSchedule | None = None, market_open_checker=None) -> None:
        if not ticker.strip():
            raise ValueError("ticker must not be empty")
        if model_weight <= 0:
            raise ValueError("model_weight must be positive")
        self.ticker = ticker
        self.regime = regime_engine or MarketRegimeEngine()
        self.base_min_confidence = min_confidence
        self.schedule = trading_schedule or TradingSchedule(market_open_checker=market_open_checker)
        if market_open_checker is not None:
            self.schedule.market_open_checker = market_open_checker
        self.meta = MetaDecisionEngine(min_confidence=min_confidence)
        self.multi = MultiStrategyEngine([
            _StrategyAdapter("sma_5_20", Strategy(5, 20, min_spread=0.00002), ticker),
            _StrategyAdapter("sma_3_10", Strategy(3, 10, min_spread=0.00002), ticker),
        ])
        self.model = ModelDecisionEngine(model, feature_engine) if model is not None else None
        self.outcome_model = OutcomeModelDecisionEngine(outcome_model, feature_engine, min_win_probability=outcome_min_win_probability) if outcome_model is not None else None
        self.model_weight = model_weight

    def decide(self, context: DecisionContext) -> DecisionPipelineResult:
        if context.ticker != self.ticker:
            raise ValueError("context ticker does not match pipeline ticker")
        if not context.candles:
            raise ValueError("decision context must contain historical candles")
        regime = self.regime.classify_context(context)
        strategies = self.multi.evaluate(context)
        inputs = [DecisionInput(source=d.strategy_name, result=d.result) for d in strategies]
        model_result = None
        if self.model is not None:
            model_result = self.model.evaluate(context)
            inputs.append(DecisionInput(source="trained_model", result=model_result, weight=self.model_weight))
        threshold = self.schedule.min_confidence(context.timestamp, self.base_min_confidence)
        self.meta.min_confidence = threshold
        meta = self.meta.decide(inputs)
        if not self.schedule.is_open(context.timestamp, context.ticker) and meta.signal != "HOLD":
            meta = MetaDecision(signal="HOLD", confidence=meta.confidence, reason="Trading schedule is closed or instrument is unavailable", contributors=meta.contributors)
        elif regime.regime not in {MarketRegime.TREND, MarketRegime.LOW_VOLATILITY} and meta.signal != "HOLD":
            meta = MetaDecision(signal="HOLD", confidence=meta.confidence, reason=f"Regime gate: {regime.regime.value}", contributors=meta.contributors)
        outcome_result = None
        if self.outcome_model is not None:
            candidate = SignalResult(ticker=context.ticker, signal=meta.signal, confidence=meta.confidence, reason=meta.reason)
            outcome_result = self.outcome_model.evaluate(context, candidate)
            if outcome_result.signal == "HOLD" and meta.signal != "HOLD":
                meta = MetaDecision(signal="HOLD", confidence=outcome_result.confidence, reason=outcome_result.reason, contributors=meta.contributors)
            elif meta.signal != "HOLD":
                meta = MetaDecision(signal=meta.signal, confidence=outcome_result.confidence, reason=outcome_result.reason, contributors=meta.contributors)
        return DecisionPipelineResult(regime=regime, strategies=strategies, meta=meta, model=model_result, outcome=outcome_result)
