from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class PerformanceSnapshot:
    cycles: int
    trades: int
    filled_buys: int
    filled_sells: int
    realized_pnl: float
    total_commission: float
    win_rate: float
    equity: float | None
    cash: float | None


class PerformanceJournal:
    """Persistent SQLite journal for autonomous trading runs.

    Every strategy cycle is stored, including HOLD/REJECTED/NO_TRADE cycles.
    Filled orders are stored separately so long Sandbox sessions can be
    analyzed after the bot process or GitHub Actions run has ended.
    """

    def __init__(self, path: str = "data/performance_journal.sqlite3") -> None:
        if not path.strip():
            raise ValueError("journal path must not be empty")
        self.path = Path(path)
        if self.path != Path(":memory:"):
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self._memory_connection = None
        else:
            self._memory_connection = sqlite3.connect(":memory:")
            self._memory_connection.row_factory = sqlite3.Row
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        if self._memory_connection is not None:
            return self._memory_connection
        return sqlite3.connect(str(self.path))

    def _initialize(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS cycles (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    ticker TEXT NOT NULL,
                    price REAL NOT NULL,
                    signal TEXT NOT NULL,
                    confidence REAL NOT NULL,
                    regime TEXT NOT NULL,
                    status TEXT NOT NULL,
                    reason TEXT NOT NULL,
                    quantity INTEGER NOT NULL DEFAULT 0,
                    position_before REAL NOT NULL DEFAULT 0,
                    position_after REAL NOT NULL DEFAULT 0,
                    equity REAL,
                    cash REAL,
                    estimated_pnl REAL NOT NULL DEFAULT 0,
                    freed_cash REAL NOT NULL DEFAULT 0,
                    journal_version INTEGER NOT NULL DEFAULT 1
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS trades (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    ticker TEXT NOT NULL,
                    side TEXT NOT NULL,
                    quantity INTEGER NOT NULL,
                    requested_price REAL NOT NULL,
                    executed_price REAL,
                    commission REAL NOT NULL DEFAULT 0,
                    realized_pnl REAL,
                    order_id TEXT,
                    status TEXT NOT NULL,
                    position_after REAL,
                    cash_after REAL,
                    equity_after REAL,
                    journal_version INTEGER NOT NULL DEFAULT 1
                )
                """
            )

    def record_cycle(
        self,
        *,
        timestamp: Any,
        ticker: str,
        price: float,
        signal: str,
        confidence: float,
        regime: str,
        status: str,
        reason: str,
        quantity: int = 0,
        position_before: float = 0,
        position_after: float = 0,
        equity: float | None = None,
        cash: float | None = None,
        estimated_pnl: float = 0,
        freed_cash: float = 0,
    ) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO cycles (
                    timestamp, ticker, price, signal, confidence, regime, status,
                    reason, quantity, position_before, position_after, equity, cash,
                    estimated_pnl, freed_cash
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    timestamp.isoformat() if hasattr(timestamp, "isoformat") else str(timestamp),
                    ticker,
                    float(price),
                    signal,
                    float(confidence),
                    regime,
                    status,
                    reason,
                    int(quantity),
                    float(position_before),
                    float(position_after),
                    None if equity is None else float(equity),
                    None if cash is None else float(cash),
                    float(estimated_pnl),
                    float(freed_cash),
                ),
            )

    def record_trade(
        self,
        *,
        timestamp: Any,
        ticker: str,
        side: str,
        quantity: int,
        requested_price: float,
        executed_price: float | None,
        commission: float = 0,
        realized_pnl: float | None = None,
        order_id: str | None = None,
        status: str,
        position_after: float | None = None,
        cash_after: float | None = None,
        equity_after: float | None = None,
    ) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO trades (
                    timestamp, ticker, side, quantity, requested_price,
                    executed_price, commission, realized_pnl, order_id, status,
                    position_after, cash_after, equity_after
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    timestamp.isoformat() if hasattr(timestamp, "isoformat") else str(timestamp),
                    ticker,
                    side,
                    int(quantity),
                    float(requested_price),
                    None if executed_price is None else float(executed_price),
                    float(commission),
                    None if realized_pnl is None else float(realized_pnl),
                    order_id,
                    status,
                    None if position_after is None else float(position_after),
                    None if cash_after is None else float(cash_after),
                    None if equity_after is None else float(equity_after),
                ),
            )

    def snapshot(self, ticker: str | None = None) -> PerformanceSnapshot:
        with self._connect() as conn:
            where = "" if ticker is None else " WHERE ticker = ?"
            args = () if ticker is None else (ticker,)
            cycles = conn.execute(
                f"SELECT COUNT(*) FROM cycles{where}", args
            ).fetchone()[0]
            trades = conn.execute(
                f"SELECT COUNT(*) FROM trades{where} AND status = 'FILLED'" if where else
                "SELECT COUNT(*) FROM trades WHERE status = 'FILLED'",
                args,
            ).fetchone()[0]
            buys = conn.execute(
                f"SELECT COUNT(*) FROM trades{where} AND status = 'FILLED' AND side = 'BUY'" if where else
                "SELECT COUNT(*) FROM trades WHERE status = 'FILLED' AND side = 'BUY'",
                args,
            ).fetchone()[0]
            sells = conn.execute(
                f"SELECT COUNT(*) FROM trades{where} AND status = 'FILLED' AND side = 'SELL'" if where else
                "SELECT COUNT(*) FROM trades WHERE status = 'FILLED' AND side = 'SELL'",
                args,
            ).fetchone()[0]
            pnl = conn.execute(
                f"SELECT COALESCE(SUM(realized_pnl), 0) FROM trades{where}" if where else
                "SELECT COALESCE(SUM(realized_pnl), 0) FROM trades",
                args,
            ).fetchone()[0]
            commission = conn.execute(
                f"SELECT COALESCE(SUM(commission), 0) FROM trades{where}" if where else
                "SELECT COALESCE(SUM(commission), 0) FROM trades",
                args,
            ).fetchone()[0]
            wins = conn.execute(
                f"SELECT COUNT(*) FROM trades{where} AND realized_pnl > 0" if where else
                "SELECT COUNT(*) FROM trades WHERE realized_pnl > 0",
                args,
            ).fetchone()[0]
            closed = conn.execute(
                f"SELECT COUNT(*) FROM trades{where} AND realized_pnl IS NOT NULL" if where else
                "SELECT COUNT(*) FROM trades WHERE realized_pnl IS NOT NULL",
                args,
            ).fetchone()[0]
            latest = conn.execute(
                f"SELECT equity, cash FROM cycles{where} ORDER BY id DESC LIMIT 1" if where else
                "SELECT equity, cash FROM cycles ORDER BY id DESC LIMIT 1",
                args,
            ).fetchone()

        return PerformanceSnapshot(
            cycles=int(cycles),
            trades=int(trades),
            filled_buys=int(buys),
            filled_sells=int(sells),
            realized_pnl=float(pnl or 0),
            total_commission=float(commission or 0),
            win_rate=float(wins / closed) if closed else 0.0,
            equity=None if latest is None else latest[0],
            cash=None if latest is None else latest[1],
        )
