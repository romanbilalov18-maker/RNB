from dataclasses import dataclass
from pathlib import Path
import pickle

from sklearn.pipeline import Pipeline

from bot.evaluation import ModelEvaluation, ModelEvaluator
from bot.training import TrainingResult
from bot.walk_forward import WalkForwardEngine, WalkForwardResult


@dataclass(frozen=True)
class ModelApprovalPolicy:
    """Explicit, deterministic gate for models entering the trading contour."""

    min_validation_accuracy: float = 0.50
    min_validation_f1: float = 0.0
    min_walk_forward_accuracy: float = 0.50
    min_walk_forward_f1: float = 0.0
    min_walk_forward_folds: int = 1

    def __post_init__(self) -> None:
        for name in (
            "min_validation_accuracy",
            "min_validation_f1",
            "min_walk_forward_accuracy",
            "min_walk_forward_f1",
        ):
            value = getattr(self, name)
            if not 0.0 <= value <= 1.0:
                raise ValueError(f"{name} must be between 0 and 1")
        if self.min_walk_forward_folds <= 0:
            raise ValueError("min_walk_forward_folds must be positive")


@dataclass(frozen=True)
class ModelApproval:
    approved: bool
    validation_accuracy: float
    validation_f1: float
    walk_forward_accuracy: float
    walk_forward_f1: float
    walk_forward_folds: int
    reason: str


@dataclass(frozen=True)
class ApprovedModelArtifact:
    model: Pipeline
    approval: ModelApproval
    feature_names: tuple[str, ...]
    target_definition: str


class ModelRegistry:
    """Connect training, evaluation and walk-forward results to model activation."""

    def __init__(self, policy: ModelApprovalPolicy | None = None):
        self.policy = policy or ModelApprovalPolicy()

    def evaluate_approval(
        self,
        training: TrainingResult,
        validation: ModelEvaluation,
        walk_forward: WalkForwardResult,
    ) -> ModelApproval:
        if validation.sample_count != training.validation_size:
            raise ValueError("validation result does not match training validation samples")
        if walk_forward.fold_count < self.policy.min_walk_forward_folds:
            return ModelApproval(
                False,
                validation.accuracy,
                validation.f1,
                walk_forward.mean_accuracy,
                walk_forward.mean_f1,
                walk_forward.fold_count,
                "Not enough walk-forward folds",
            )

        checks = (
            validation.accuracy >= self.policy.min_validation_accuracy,
            validation.f1 >= self.policy.min_validation_f1,
            walk_forward.mean_accuracy >= self.policy.min_walk_forward_accuracy,
            walk_forward.mean_f1 >= self.policy.min_walk_forward_f1,
        )
        approved = all(checks)
        reason = "Model passed approval gates" if approved else "Model failed approval gates"

        return ModelApproval(
            approved,
            validation.accuracy,
            validation.f1,
            walk_forward.mean_accuracy,
            walk_forward.mean_f1,
            walk_forward.fold_count,
            reason,
        )

    def approve_training(
        self,
        training: TrainingResult,
        *,
        train_size: int,
        validation_size: int,
        step_size: int,
        expanding: bool = True,
        evaluator: ModelEvaluator | None = None,
        walk_forward_engine: WalkForwardEngine | None = None,
    ) -> ModelApproval:
        """Evaluate one trained model and return its registry approval decision."""
        evaluator = evaluator or ModelEvaluator()
        walk_forward_engine = walk_forward_engine or WalkForwardEngine(
            training_engine=None,
            evaluator=evaluator,
        )
        validation = evaluator.evaluate(training.model, training.validation_samples)
        samples = training.train_samples + training.validation_samples
        walk_forward = walk_forward_engine.run_samples(
            samples,
            train_size=train_size,
            validation_size=validation_size,
            step_size=step_size,
            expanding=expanding,
        )
        return self.evaluate_approval(training, validation, walk_forward)

    def save_approved(
        self,
        training: TrainingResult,
        approval: ModelApproval,
        path: str | Path,
    ) -> None:
        if not approval.approved:
            raise ValueError("cannot save a model that was not approved")

        artifact = ApprovedModelArtifact(
            model=training.model,
            approval=approval,
            feature_names=training.feature_names,
            target_definition=training.target_definition,
        )
        destination = Path(path)
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open("wb") as handle:
            pickle.dump(artifact, handle)

    @staticmethod
    def load_approved(
        path: str | Path,
        *,
        expected_target_definition: str | None = None,
    ) -> ApprovedModelArtifact:
        with Path(path).open("rb") as handle:
            artifact = pickle.load(handle)

        if not isinstance(artifact, ApprovedModelArtifact):
            raise ValueError("saved artifact is not an approved model artifact")
        if not artifact.approval.approved:
            raise ValueError("model artifact is not approved")
        if not isinstance(artifact.model, Pipeline):
            raise ValueError("approved artifact does not contain a scikit-learn Pipeline")
        if (
            expected_target_definition is not None
            and artifact.target_definition != expected_target_definition
        ):
            raise ValueError("approved model target definition does not match expected target")
        return artifact
