from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
import time
from typing import Any


@dataclass(frozen=True)
class InstrumentInfo:
    instrument_id: str
    figi: str
    ticker: str
    name: str
    asset_type: str
    class_code: str = ""
    exchange: str = ""
    currency: str = ""
    lot: int = 1
    api_trade_available: bool = False
    buy_available: bool = False
    sell_available: bool = False
    trading_status: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def tradable(self) -> bool:
        return bool(
            self.api_trade_available
            and (self.buy_available or self.sell_available)
        )


@dataclass(frozen=True)
class MarketUniverseSnapshot:
    instruments: tuple[InstrumentInfo, ...]
    refreshed_at: datetime

    @property
    def by_type(self) -> dict[str, tuple[InstrumentInfo, ...]]:
        result: dict[str, list[InstrumentInfo]] = {}
        for instrument in self.instruments:
            result.setdefault(instrument.asset_type, []).append(instrument)
        return {key: tuple(value) for key, value in result.items()}

    @property
    def tradable(self) -> tuple[InstrumentInfo, ...]:
        return tuple(item for item in self.instruments if item.tradable)

    def summary(self) -> dict:
        grouped = self.by_type
        return {
            "total": len(self.instruments),
            "tradable": len(self.tradable),
            "by_type": {key: len(value) for key, value in grouped.items()},
            "tradable_by_type": {
                key: sum(item.tradable for item in value)
                for key, value in grouped.items()
            },
        }


class TBankMarketUniverse:
    """Full T-Invest instrument catalogue plus live trading-status refresh."""

    CATEGORIES = (
        ("shares", "share"),
        ("bonds", "bond"),
        ("etfs", "etf"),
        ("currencies", "currency"),
        ("futures", "futures"),
        ("options", "option"),
        ("structured_notes", "structured_note"),
        ("dfas", "dfa"),
    )

    def __init__(self, token: str):
        if not token or not token.strip():
            raise ValueError("T-Bank token is required")
        self.token = token.strip()
        self._snapshot: MarketUniverseSnapshot | None = None

    def load(
        self,
        *,
        refresh_status: bool = True,
        max_instruments: int | None = None,
    ) -> MarketUniverseSnapshot:
        try:
            from t_tech.invest import Client, InstrumentStatus
        except ImportError as exc:
            raise RuntimeError(
                "T-Bank SDK is not installed; add t-tech-investments to requirements.txt"
            ) from exc

        status_all = getattr(
            InstrumentStatus, "INSTRUMENT_STATUS_ALL", InstrumentStatus(2)
        )
        raw: list[tuple[str, Any]] = []
        with Client(self.token) as client:
            instruments = client.instruments
            for method_name, asset_type in self.CATEGORIES:
                method = getattr(instruments, method_name, None)
                if method is None and method_name == "options":
                    method = getattr(instruments, "options_by", None)
                if method is None:
                    continue
                try:
                    response = self._call_with_retry(method, instrument_status=status_all)
                except TypeError:
                    try:
                        response = self._call_with_retry(method)
                    except TypeError:
                        continue
                items = getattr(response, "instruments", None)
                if items is None:
                    items = getattr(response, "options", None)
                for item in list(items or ()):
                    raw.append((asset_type, item))

            normalized = self._normalize(raw)
            if max_instruments is not None:
                if max_instruments <= 0:
                    raise ValueError("max_instruments must be positive")
                asset_priority = {"share": 0, "etf": 1, "bond": 2, "futures": 3}
                normalized = sorted(
                    normalized,
                    key=lambda item: (
                        0 if item.tradable else 1,
                        asset_priority.get(item.asset_type, 9),
                        item.ticker,
                    ),
                )[:max_instruments]
            if refresh_status and normalized:
                normalized = self._refresh_statuses(client, normalized)

        self._snapshot = MarketUniverseSnapshot(
            instruments=tuple(normalized),
            refreshed_at=datetime.now(timezone.utc),
        )
        return self._snapshot

    @property
    def snapshot(self) -> MarketUniverseSnapshot:
        if self._snapshot is None:
            return self.load()
        return self._snapshot

    @staticmethod
    def _call_with_retry(method: Any, **kwargs: Any) -> Any:
        """Retry transient T-Invest/gRPC stream failures."""
        attempts = 3
        for attempt in range(1, attempts + 1):
            try:
                return method(**kwargs)
            except Exception as exc:
                message = str(exc)
                transient = (
                    "Stream removed" in message
                    or "StatusCode.UNKNOWN" in message
                    or "temporarily unavailable" in message.lower()
                )
                if not transient or attempt == attempts:
                    raise
                time.sleep(attempt)

    @staticmethod
    def _normalize(raw: list[tuple[str, Any]]) -> list[InstrumentInfo]:
        result: list[InstrumentInfo] = []
        seen: set[str] = set()
        for asset_type, item in raw:
            figi = str(getattr(item, "figi", "") or "")
            uid = str(
                getattr(item, "instrument_uid", None)
                or getattr(item, "uid", None)
                or ""
            )
            ticker = str(getattr(item, "ticker", "") or "")
            instrument_id = uid or figi or ticker
            if not instrument_id or instrument_id in seen:
                continue
            seen.add(instrument_id)
            result.append(
                InstrumentInfo(
                    instrument_id=instrument_id,
                    figi=figi,
                    ticker=ticker,
                    name=str(getattr(item, "name", "") or ""),
                    asset_type=asset_type,
                    class_code=str(getattr(item, "class_code", "") or ""),
                    exchange=str(getattr(item, "exchange", "") or ""),
                    currency=str(
                        getattr(item, "currency", None)
                        or getattr(item, "iso_currency_name", None)
                        or ""
                    ),
                    lot=int(getattr(item, "lot", 1) or 1),
                    api_trade_available=bool(
                        getattr(item, "api_trade_available_flag", False)
                    ),
                    buy_available=bool(
                        getattr(item, "buy_available_flag", False)
                    ),
                    sell_available=bool(
                        getattr(item, "sell_available_flag", False)
                    ),
                    trading_status=str(
                        getattr(item, "trading_status", "") or ""
                    ),
                    metadata={
                        "position_uid": getattr(item, "position_uid", None),
                        "asset_uid": getattr(item, "asset_uid", None),
                        "country_of_risk": getattr(item, "country_of_risk", None),
                        "sector": getattr(item, "sector", None),
                    },
                )
            )
        return result

    @staticmethod
    def _refresh_statuses(client: Any, instruments: list[InstrumentInfo]) -> list[InstrumentInfo]:
        getter = getattr(client.market_data, "get_trading_statuses", None)
        if getter is None:
            return instruments

        ids = [item.instrument_id for item in instruments]
        statuses: dict[str, Any] = {}
        # Batch requests avoid one RPC per instrument. The exact server-side
        # limit can change, so keep requests comfortably below large payloads.
        for start in range(0, len(ids), 100):
            chunk = ids[start:start + 100]
            try:
                response = getter(instrument_ids=chunk)
            except TypeError:
                response = getter(figi=chunk)
            for status in getattr(response, "trading_statuses", ()) or ():
                key = str(
                    getattr(status, "instrument_uid", None)
                    or getattr(status, "figi", None)
                    or ""
                )
                if key:
                    statuses[key] = status

        refreshed: list[InstrumentInfo] = []
        for item in instruments:
            status = statuses.get(item.instrument_id) or statuses.get(item.figi)
            if status is None:
                refreshed.append(item)
                continue
            refreshed.append(
                InstrumentInfo(
                    **{
                        **item.__dict__,
                        "api_trade_available": bool(
                            getattr(status, "api_trade_available_flag", item.api_trade_available)
                        ),
                        "buy_available": bool(
                            getattr(status, "limit_order_available_flag", False)
                            or getattr(status, "market_order_available_flag", False)
                        ) and item.buy_available,
                        "sell_available": bool(
                            getattr(status, "limit_order_available_flag", False)
                            or getattr(status, "market_order_available_flag", False)
                        ) and item.sell_available,
                        "trading_status": str(
                            getattr(status, "trading_status", item.trading_status)
                        ),
                    }
                )
            )
        return refreshed
