from dataclasses import dataclass

from bot.market_regime import MarketRegime, RegimeResult
from bot.meta_decision import MetaDecision
from bot.models import DecisionContext


@dataclass(frozen=True)
class PositionDecision:
    action: str
    quantity: int
    target_quantity: int
    remaining_quantity: int
    estimated_realized_pnl: float
    freed_cash: float
    capital_destination: str
    strength: float
    reason: str


class PositionManager:
    """Dynamic position sizing and reduction gate.

    Quantities are kept internally as shares so portfolio accounting remains
    intuitive. The final quantity is always aligned to the instrument lot size.
    """

    def __init__(
        self,
        max_position_percent: float = 10.0,
        min_signal_strength: float = 0.50,
        commission_rate: float = 0.0,
        min_rebalance_quantity: int = 1,
    ) -> None:
        if not 0 < max_position_percent <= 100:
            raise ValueError("max_position_percent must be in (0, 100]")
        if not 0 <= min_signal_strength <= 1:
            raise ValueError("min_signal_strength must be between 0 and 1")
        if commission_rate < 0:
            raise ValueError("commission_rate must be non-negative")
        if min_rebalance_quantity <= 0:
            raise ValueError("min_rebalance_quantity must be positive")
        self.max_position_percent = max_position_percent
        self.min_signal_strength = min_signal_strength
        self.commission_rate = commission_rate
        self.min_rebalance_quantity = min_rebalance_quantity

    def evaluate(
        self,
        context: DecisionContext,
        regime: RegimeResult,
        meta: MetaDecision,
        current_quantity: int,
        average_price: float,
        equity: float,
        available_cash: float,
        strategy_results: tuple,
    ) -> PositionDecision:
        if current_quantity < 0:
            raise ValueError("current_quantity must not be negative")
        if average_price < 0:
            raise ValueError("average_price must not be negative")
        if equity <= 0:
            raise ValueError("equity must be positive")
        if available_cash < 0:
            raise ValueError("available_cash must not be negative")
        if context.price <= 0:
            raise ValueError("context price must be positive")
        if context.lot_size <= 0:
            raise ValueError("context lot_size must be positive")

        if meta.signal not in {"BUY", "SELL"}:
            return self._hold("Meta decision is HOLD", current_quantity)

        if regime.regime not in {MarketRegime.TREND, MarketRegime.LOW_VOLATILITY}:
            return self._hold(
                f"Position change requires TREND or LOW_VOLATILITY regime, got {regime.regime.value}",
                current_quantity,
            )

        if meta.signal == "SELL" and current_quantity <= 0:
            return self._hold("SELL signal but no position is held", 0, 0.0)

        strength = self._signal_strength(meta, regime, strategy_results)
        if strength < self.min_signal_strength:
            return self._hold(
                f"Signal strength {strength:.3f} below threshold "
                f"{self.min_signal_strength:.2f}",
                current_quantity,
                strength,
            )

        if meta.signal == "BUY":
            return self._evaluate_buy(
                context, current_quantity, equity, available_cash, strength
            )

        return self._evaluate_sell(
            context, current_quantity, average_price, strength
        )

    def _signal_strength(
        self,
        meta: MetaDecision,
        regime: RegimeResult,
        strategy_results: tuple,
    ) -> float:
        if strategy_results is None:
            return max(0.0, min(1.0, meta.confidence, regime.confidence))

        directional = sum(
            1 for item in strategy_results if item.result.signal == meta.signal
        )
        total = len(strategy_results)
        if total == 0 or directional == 0:
            return 0.0
        agreement = directional / total
        strength = max(
            0.0,
            min(1.0, meta.confidence, agreement, regime.confidence),
        )
        if regime.regime == MarketRegime.LOW_VOLATILITY:
            strength *= 0.5
        return strength

    def _evaluate_buy(
        self,
        context: DecisionContext,
        current_quantity: int,
        equity: float,
        available_cash: float,
        strength: float,
    ) -> PositionDecision:
        lot_size = context.lot_size
        max_value = equity * self.max_position_percent / 100
        desired_value = max_value * strength
        desired_quantity = int(desired_value // context.price)

        unit_cost = context.price * (1.0 + self.commission_rate)
        affordable_quantity = int(available_cash // unit_cost)

        # Orders must contain whole lots. If the signal wants a partial lot,
        # allow one full lot only when it still fits inside the risk/cash caps.
        target_quantity = min(desired_quantity, affordable_quantity)
        if target_quantity > current_quantity and target_quantity < lot_size:
            if lot_size <= affordable_quantity and current_quantity == 0:
                target_quantity = lot_size
            else:
                target_quantity = current_quantity
        elif target_quantity > current_quantity:
            target_quantity = (target_quantity // lot_size) * lot_size

        if target_quantity <= current_quantity:
            return self._hold(
                "Current position already meets the dynamically sized target",
                current_quantity,
                strength,
            )

        quantity = target_quantity - current_quantity
        if quantity < max(self.min_rebalance_quantity, lot_size):
            return self._hold(
                "Required BUY adjustment is below one exchange lot",
                current_quantity,
                strength,
            )

        return PositionDecision(
            action="BUY",
            quantity=quantity,
            target_quantity=target_quantity,
            remaining_quantity=target_quantity,
            estimated_realized_pnl=0.0,
            freed_cash=0.0,
            capital_destination="position",
            strength=strength,
            reason=(
                f"Dynamic BUY target {target_quantity} shares "
                f"({target_quantity // lot_size} lots) from "
                f"{strength:.3f} signal strength"
            ),
        )

    def _evaluate_sell(
        self,
        context: DecisionContext,
        current_quantity: int,
        average_price: float,
        strength: float,
    ) -> PositionDecision:
        if current_quantity <= 0:
            return self._hold("SELL signal but no position is held", 0, strength)

        lot_size = context.lot_size
        target_quantity = int(current_quantity * (1.0 - strength) + 1e-9)
        target_quantity = (target_quantity // lot_size) * lot_size
        quantity = current_quantity - target_quantity
        quantity = min(quantity, current_quantity)

        if quantity < max(self.min_rebalance_quantity, lot_size):
            return self._hold(
                "Required SELL adjustment is below one exchange lot",
                current_quantity,
                strength,
            )

        gross_cash = quantity * context.price
        commission = gross_cash * self.commission_rate
        freed_cash = gross_cash - commission
        realized_pnl = (
            (context.price - average_price) * quantity - commission
        )

        return PositionDecision(
            action="SELL",
            quantity=quantity,
            target_quantity=target_quantity,
            remaining_quantity=current_quantity - quantity,
            estimated_realized_pnl=realized_pnl,
            freed_cash=freed_cash,
            capital_destination="cash",
            strength=strength,
            reason=(
                f"Dynamic SELL reduces exposure from {current_quantity} "
                f"to {target_quantity} shares"
            ),
        )

    @staticmethod
    def _hold(
        reason: str,
        current_quantity: int,
        strength: float = 0.0,
    ) -> PositionDecision:
        return PositionDecision(
            action="HOLD",
            quantity=0,
            target_quantity=current_quantity,
            remaining_quantity=current_quantity,
            estimated_realized_pnl=0.0,
            freed_cash=0.0,
            capital_destination="cash",
            strength=strength,
            reason=reason,
        )
