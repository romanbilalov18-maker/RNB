from bot.config import Config
from bot.market import StubMarketData, TBankMarketData
from bot.model_registry import ModelRegistry
from bot.models import DecisionContext, OrderRequest, SignalResult
from bot.pipeline import TradingDecisionPipeline
from bot.performance_journal import PerformanceJournal
from bot.paper_execution import PaperExecution
from bot.paper_portfolio import PaperPortfolioStore
from bot.paper_scan import rank_paper_candidates
from bot.position_manager import PositionManager
from bot.risk import RiskManager
from bot.sandbox_execution import SandboxExecution
from bot.trading_schedule import TradingSchedule


OUTCOME_TARGET_DEFINITION = (
    "1 if the completed trade outcome is WIN, else 0; BREAKEVEN excluded"
)


class TradingBot:
    def __init__(self, config: Config | None = None):
        self.config = config or Config.from_env()
        self.risk = RiskManager(self.config.max_position_percent, min_confidence=self.config.risk_min_confidence)
        self.position_manager = PositionManager(
            max_position_percent=self.config.max_position_percent,
            min_signal_strength=self.config.position_min_signal_strength,
            commission_rate=self.config.commission_rate,
        )
        self.sandbox_positions: dict[str, float] = {}

        approved_model = (
            ModelRegistry.load_approved(self.config.model_path).model
            if self.config.model_path
            else None
        )
        approved_outcome_model = (
            ModelRegistry.load_approved(
                self.config.outcome_model_path,
                expected_target_definition=OUTCOME_TARGET_DEFINITION,
            ).model
            if self.config.outcome_model_path
            else None
        )

        self.pipeline = TradingDecisionPipeline(
            self.config.ticker,
            min_confidence=0.20,
            model=approved_model,
            outcome_model=approved_outcome_model,
            trading_schedule=TradingSchedule(
                timezone_name=self.config.trading_timezone,
                windows=TradingSchedule.from_string(
                    self.config.trading_windows, self.config.trading_timezone
                ).windows,
            ),
        )
        self.performance_journal = PerformanceJournal(self.config.performance_journal_path)

        if self.config.invest_token:
            self.market = TBankMarketData(
                self.config.invest_token,
                history_days=self.config.market_scan_history_days,
            )
            self.pipeline.schedule.market_open_checker = self.market.is_trading
        else:
            self.market = StubMarketData()

        self.paper_portfolio = None
        if self.config.execution_mode == "paper":
            if not self.config.invest_token:
                raise RuntimeError(
                    "Paper mode requires INVEST_TOKEN or TINKOFF_TOKEN for read-only market data"
                )
            self.paper_portfolio = PaperPortfolioStore(
                self.config.paper_portfolio_path,
                initial_cash=self.config.initial_balance,
                commission_rate=self.config.commission_rate,
            )
            self.execution = PaperExecution(
                self.paper_portfolio,
                commission_rate=self.config.commission_rate,
                slippage_rate=self.config.paper_slippage_rate,
                min_net_profit_percent=self.config.paper_min_net_profit_percent,
                max_position_percent=self.config.max_position_percent,
                risk_per_trade_percent=self.config.paper_risk_per_trade_percent,
                stop_loss_percent=self.config.paper_stop_loss_percent,
                max_quote_age_seconds=self.config.paper_max_quote_age_seconds,
            )
        elif self.config.execution_mode == "sandbox":
            if not self.config.invest_token:
                raise RuntimeError(
                    "Sandbox execution requires INVEST_TOKEN or TINKOFF_TOKEN"
                )
            self.execution = SandboxExecution(
                self.config.invest_token,
                self.config.sandbox_account_id,
            )
        else:
            raise RuntimeError(
                "Live execution is not implemented yet"
            )

    def _pipeline_for_ticker(self, ticker: str) -> TradingDecisionPipeline:
        if ticker == self.config.ticker:
            return self.pipeline
        schedule = TradingSchedule(
            timezone_name=self.config.trading_timezone,
            windows=TradingSchedule.from_string(
                self.config.trading_windows, self.config.trading_timezone
            ).windows,
            market_open_checker=self.market.is_trading
            if isinstance(self.market, TBankMarketData)
            else None,
        )
        return TradingDecisionPipeline(
            ticker,
            min_confidence=0.20,
            model=ModelRegistry.load_approved(self.config.model_path).model
            if self.config.model_path
            else None,
            outcome_model=ModelRegistry.load_approved(
                self.config.outcome_model_path,
                expected_target_definition=OUTCOME_TARGET_DEFINITION,
            ).model
            if self.config.outcome_model_path
            else None,
            trading_schedule=schedule,
        )

    def _decision_context(self, ticker: str | None = None) -> DecisionContext:
        quote = self.market.get_quote(ticker or self.config.ticker)
        return DecisionContext.from_quote(quote)

    def _sync_sandbox_position(self, ticker: str) -> float:
        if self.config.execution_mode != "sandbox":
            return self.sandbox_positions.get(ticker, 0.0)

        getter = getattr(self.execution, "get_position", None)
        if getter is None:
            raise RuntimeError("Sandbox execution cannot read remote position")

        quantity = float(getter(ticker))
        self.sandbox_positions[ticker] = quantity
        return quantity

    def get_signal(self) -> SignalResult:
        context = self._decision_context()
        decision = self.pipeline.decide(context)
        return SignalResult(
            ticker=context.ticker,
            signal=decision.meta.signal,
            confidence=decision.meta.confidence,
            reason=decision.meta.reason,
        )

    def _decision_diagnostics(self, context: DecisionContext, decision) -> dict:
        return {
            "price": context.price,
            "score": decision.meta.confidence * 100.0,
            "upside": (
                ((context.candles[-1].close / context.candles[0].close) - 1.0) * 100.0
                if len(context.candles) >= 2 and context.candles[0].close > 0
                else 0.0
            ),
            "regime": decision.regime.regime.value,
            "regime_volatility": decision.regime.volatility,
            "regime_trend_strength": decision.regime.trend_strength,
            "regime_confidence": decision.regime.confidence,
            "strategies": {
                item.strategy_name: {
                    "signal": item.result.signal,
                    "confidence": item.result.confidence,
                    "reason": item.result.reason,
                }
                for item in getattr(decision, "strategies", ())
            },
            "meta": {
                "signal": decision.meta.signal,
                "confidence": decision.meta.confidence,
                "reason": decision.meta.reason,
                "contributors": decision.meta.contributors,
            },
            "model": (
                {
                    "signal": decision.model.signal,
                    "confidence": decision.model.confidence,
                    "reason": decision.model.reason,
                }
                if getattr(decision, "model", None) is not None
                else None
            ),
            "outcome": (
                {
                    "signal": decision.outcome.signal,
                    "confidence": decision.outcome.confidence,
                    "reason": decision.outcome.reason,
                }
                if getattr(decision, "outcome", None) is not None
                else None
            ),
        }

    def _record_journal(
        self,
        *,
        context,
        signal,
        decision,
        status,
        reason,
        quantity=0,
        position_before=0,
        position_after=0,
        equity=None,
        cash=None,
        estimated_pnl=0,
        freed_cash=0,
        execution_result=None,
    ):
        try:
            self.performance_journal.record_cycle(
                timestamp=context.timestamp,
                ticker=context.ticker,
                price=context.price,
                signal=signal.signal,
                confidence=signal.confidence,
                regime=decision.regime.regime.value,
                status=status,
                reason=reason,
                quantity=quantity,
                position_before=position_before,
                position_after=position_after,
                equity=equity,
                cash=cash,
                estimated_pnl=estimated_pnl,
                freed_cash=freed_cash,
            )
            if execution_result and execution_result.get("status") in {"FILLED", "SUBMITTED", "CANCELLED", "REJECTED"}:
                self.performance_journal.record_trade(
                    timestamp=context.timestamp,
                    ticker=context.ticker,
                    side=execution_result.get("side", signal.signal),
                    quantity=int(execution_result.get("quantity", quantity) or quantity),
                    requested_price=context.price,
                    executed_price=execution_result.get("executed_price", execution_result.get("price", context.price)),
                    commission=float(execution_result.get("commission", 0) or 0),
                    realized_pnl=(
                        execution_result.get("realized_pnl")
                        if signal.signal == "SELL"
                        else None
                    ),
                    order_id=execution_result.get("order_id"),
                    status=execution_result.get("status", status),
                    position_after=position_after,
                    cash_after=cash,
                    equity_after=equity,
                )
        except Exception:
            # Journal failures must never stop the trading engine.
            pass

    def prepare_signal(self, ticker: str | None = None):
        """Build one immutable market decision for later validation/execution."""
        if ticker is None and self.config.market_scan_enabled and isinstance(self.market, TBankMarketData):
            raise ValueError("prepare_signal requires an explicit ticker when market scan is enabled")
        context = self._decision_context(ticker)
        pipeline = self._pipeline_for_ticker(context.ticker)
        decision = pipeline.decide(context)
        return context, decision

    def execute_signal(
        self,
        ticker: str | None = None,
        dry_run: bool = False,
        prepared: tuple[DecisionContext, object] | None = None,
    ):
        if self.config.execution_mode == "paper":
            if ticker is None and self.config.market_scan_enabled:
                return self._execute_paper_market_scan()
            return self._execute_paper_signal(
                ticker=ticker, dry_run=dry_run, prepared=prepared
            )
        if (
            ticker is None
            and self.config.market_scan_enabled
            and isinstance(self.market, TBankMarketData)
        ):
            return self._execute_market_scan()
        if prepared is None:
            context, decision = self.prepare_signal(ticker)
        else:
            context, decision = prepared
            if ticker is not None and context.ticker != ticker:
                raise ValueError("prepared decision ticker does not match requested ticker")
        signal = decision.meta
        decision_diagnostics = self._decision_diagnostics(context, decision)

        if self.config.execution_mode != "sandbox":
            raise RuntimeError("Live execution is not implemented yet")
        state = self.execution.get_account_state(context.ticker, context.price)
        current_quantity = int(state.position_quantity)
        average_price = state.average_price
        equity = state.equity
        available_cash = state.cash

        position_decision = self.position_manager.evaluate(
            context=context,
            regime=decision.regime,
            meta=signal,
            current_quantity=current_quantity,
            average_price=average_price,
            equity=equity,
            available_cash=available_cash,
            # Legacy/mock decisions may omit strategy details. Real pipeline decisions
            # always expose them; an explicit empty tuple remains a hard no-agreement gate.
            strategy_results=getattr(decision, "strategies", None),
        )

        decision_diagnostics["position"] = {
            "action": position_decision.action,
            "quantity": position_decision.quantity,
            "target_quantity": position_decision.target_quantity,
            "remaining_quantity": position_decision.remaining_quantity,
            "strength": position_decision.strength,
            "estimated_realized_pnl": position_decision.estimated_realized_pnl,
            "freed_cash": position_decision.freed_cash,
            "capital_destination": position_decision.capital_destination,
            "reason": position_decision.reason,
        }

        if position_decision.action == "HOLD":
            result = {
                "status": "NO_TRADE",
                "signal": signal.signal,
                "reason": position_decision.reason,
                "regime": decision.regime.regime.value,
                "confidence": signal.confidence,
                "position_quantity": current_quantity,
                "decision_diagnostics": decision_diagnostics,
            }
            self._record_journal(
                context=context, signal=signal, decision=decision,
                status=result["status"], reason=result["reason"],
                position_before=current_quantity, position_after=current_quantity,
                equity=equity, cash=available_cash,
                estimated_pnl=position_decision.estimated_realized_pnl,
                freed_cash=position_decision.freed_cash,
            )
            return result

        assessment = self.risk.assess(
            context=context,
            regime=decision.regime,
            decision=signal,
            quantity=position_decision.quantity,
            equity=equity,
            current_position_quantity=current_quantity,
        )

        if not assessment.approved:
            result = {
                "status": "REJECTED",
                "signal": signal.signal,
                "reason": assessment.reason,
                "regime": decision.regime.regime.value,
                "confidence": signal.confidence,
                "position_quantity": current_quantity,
                "decision_diagnostics": decision_diagnostics,
            }
            self._record_journal(
                context=context, signal=signal, decision=decision,
                status=result["status"], reason=result["reason"],
                position_before=current_quantity, position_after=current_quantity,
                equity=equity, cash=available_cash,
                estimated_pnl=position_decision.estimated_realized_pnl,
                freed_cash=position_decision.freed_cash,
            )
            return result

        order = assessment.order
        assert order is not None

        if dry_run:
            return {
                "status": "SIGNAL_READY",
                "signal": signal.signal,
                "reason": position_decision.reason,
                "regime": decision.regime.regime.value,
                "confidence": signal.confidence,
                "position_quantity_before": current_quantity,
                "decision_diagnostics": decision_diagnostics,
                "order": {
                    "ticker": order.ticker,
                    "side": order.side,
                    "quantity": order.quantity,
                    "price": order.price,
                },
            }

        previous_realized_pnl = 0.0
        execution_result = self.execution.execute(order)

        if execution_result.get("status") == "FILLED" and signal.signal == "SELL":
            executed_price = float(execution_result.get("executed_price", execution_result.get("price", context.price)))
            commission = float(execution_result.get("commission", executed_price * position_decision.quantity * self.config.commission_rate) or 0)
            execution_result["realized_pnl"] = (
                (executed_price - average_price) * position_decision.quantity - commission
            )

        position_after = current_quantity
        equity_after = equity
        cash_after = available_cash
        remote_quantity = execution_result.get("position_quantity")
        if remote_quantity is not None:
            position_after = float(remote_quantity)
            self.sandbox_positions[context.ticker] = position_after
        try:
            after = self.execution.get_account_state(context.ticker, context.price)
            position_after = after.position_quantity
            equity_after = after.equity
            cash_after = after.cash
        except Exception:
            pass

        status = execution_result.get("status", "UNKNOWN")
        reason = position_decision.reason
        self._record_journal(
            context=context, signal=signal, decision=decision,
            status=status, reason=reason,
            quantity=position_decision.quantity,
            position_before=current_quantity, position_after=position_after,
            equity=equity_after, cash=cash_after,
            estimated_pnl=position_decision.estimated_realized_pnl,
            freed_cash=position_decision.freed_cash,
            execution_result=execution_result,
        )

        return {
            **execution_result,
            "signal": signal.signal,
            "reason": reason,
            "regime": decision.regime.regime.value,
            "confidence": signal.confidence,
            "position_quantity_before": current_quantity,
            "position_quantity_after": position_after,
            "decision_diagnostics": decision_diagnostics,
        }

    def _execute_paper_signal(
        self,
        *,
        ticker: str | None,
        dry_run: bool,
        prepared: tuple[DecisionContext, object] | None,
    ) -> dict:
        if prepared is None:
            context, decision = self.prepare_signal(ticker)
        else:
            context, decision = prepared
            if ticker is not None and context.ticker != ticker:
                raise ValueError("prepared decision ticker does not match requested ticker")

        signal = decision.meta
        diagnostics = self._decision_diagnostics(context, decision)
        self.paper_portfolio.update_marks({context.ticker: context.price})
        snapshot = self.paper_portfolio.snapshot({context.ticker: context.price})
        position = snapshot.positions.get(context.ticker)
        order = None
        target_price = None
        reason = "No actionable paper trade"

        if position is not None:
            exit_reason = self.execution.exit_reason(context, position, context.price)
            if exit_reason:
                order = OrderRequest(
                    ticker=context.ticker,
                    side="SELL",
                    quantity=position.quantity,
                    price=context.price,
                )
                reason = exit_reason
            else:
                reason = (
                    "Waiting for fee-adjusted profit target or configured stop-loss; "
                    f"strategy signal is {signal.signal}"
                )
        elif signal.signal == "BUY":
            if signal.confidence < self.config.risk_min_confidence:
                reason = "BUY confidence is below the configured risk threshold"
            else:
                sized = self.execution.evaluate_buy(
                    context,
                    equity=snapshot.equity,
                    cash=snapshot.cash,
                )
                diagnostics["paper_sizing"] = sized
                if sized["approved"]:
                    assessment = self.risk.assess(
                        context=context,
                        regime=decision.regime,
                        decision=signal,
                        quantity=sized["quantity"],
                        equity=snapshot.equity,
                        current_position_quantity=0,
                    )
                    if assessment.approved:
                        order = assessment.order
                        target_price = sized["target_price"]
                        reason = sized["reason"]
                    else:
                        reason = assessment.reason
                else:
                    reason = sized["reason"]
        elif signal.signal == "SELL":
            reason = "SELL signal without a virtual position"

        if order is None:
            status = (
                "REJECTED"
                if "stale quote" in reason.lower()
                else "NO_TRADE"
            )
            result = {
                "status": status,
                "signal": signal.signal,
                "reason": reason,
                "regime": decision.regime.regime.value,
                "confidence": signal.confidence,
                "position_quantity": position.quantity if position else 0,
                "decision_diagnostics": diagnostics,
            }
            self._record_journal(
                context=context,
                signal=signal,
                decision=decision,
                status=result["status"],
                reason=reason,
                position_before=position.quantity if position else 0,
                position_after=position.quantity if position else 0,
                equity=snapshot.equity,
                cash=snapshot.cash,
            )
            return result

        diagnostics["paper_order"] = {
            "ticker": order.ticker,
            "side": order.side,
            "quantity": order.quantity,
            "quote_price": order.price,
            "target_price": target_price,
        }
        if dry_run:
            return {
                "status": "SIGNAL_READY",
                "signal": signal.signal,
                "reason": reason,
                "regime": decision.regime.regime.value,
                "confidence": signal.confidence,
                "position_quantity_before": position.quantity if position else 0,
                "decision_diagnostics": diagnostics,
                "order": {
                    "ticker": order.ticker,
                    "side": order.side,
                    "quantity": order.quantity,
                    "price": order.price,
                },
            }

        execution_result = self.execution.execute(
            order, context, target_price=target_price
        )
        after = self.paper_portfolio.snapshot({context.ticker: context.price})
        after_position = after.positions.get(context.ticker)
        after_quantity = after_position.quantity if after_position else 0
        self._record_journal(
            context=context,
            signal=signal,
            decision=decision,
            status=execution_result.get("status", "UNKNOWN"),
            reason=execution_result.get("reason", reason),
            quantity=order.quantity,
            position_before=position.quantity if position else 0,
            position_after=after_quantity,
            equity=after.equity,
            cash=after.cash,
            execution_result=execution_result,
        )
        return {
            **execution_result,
            "signal": signal.signal,
            "reason": execution_result.get("reason", reason),
            "regime": decision.regime.regime.value,
            "confidence": signal.confidence,
            "position_quantity_before": position.quantity if position else 0,
            "position_quantity_after": after_quantity,
            "trade_realized_pnl": execution_result.get("realized_pnl"),
            "cash": after.cash,
            "equity": after.equity,
            "portfolio_realized_pnl": after.realized_pnl,
            "total_commission": after.total_commission,
            "decision_diagnostics": diagnostics,
        }

    def _execute_paper_market_scan(self) -> dict:
        if not isinstance(self.market, TBankMarketData):
            raise RuntimeError(
                "Paper market scan requires the T-Bank read-only market data provider"
            )
        universe = self.market.get_universe(
            refresh_status=True,
            max_instruments=self.config.market_scan_max_universe_instruments,
        )
        tradable_shares = [
            item
            for item in universe.tradable
            if item.asset_type == "share" and item.currency.upper() in {"RUB", "RUR"}
        ]
        identifiers = [
            item.instrument_id for item in tradable_shares if item.instrument_id
        ]
        prices = self.market.get_last_prices(identifiers)
        held = set(self.paper_portfolio.snapshot().positions)
        quotes = {}
        for instrument in tradable_shares:
            identifier = instrument.figi or instrument.instrument_id
            if (
                identifier not in prices
                and instrument.instrument_id not in prices
                and instrument.ticker not in prices
            ):
                continue
            try:
                quote = self.market.get_quote(identifier)
            except Exception:
                continue
            quotes[identifier] = quote
            quotes[instrument.instrument_id] = quote
            quotes[instrument.ticker] = quote

        candidates = rank_paper_candidates(
            tradable_shares,
            quotes,
            held_tickers=held,
            max_candidates=self.config.market_scan_max_candidates,
            max_quote_age_seconds=self.config.paper_max_quote_age_seconds,
        )
        self.paper_portfolio.update_marks(
            {candidate.instrument.ticker: candidate.quote.price for candidate in candidates}
        )
        evaluated = []
        for candidate in candidates:
            try:
                context = DecisionContext.from_quote(candidate.quote)
                decision = self._pipeline_for_ticker(context.ticker).decide(context)
                result = self.execute_signal(
                    ticker=context.ticker,
                    dry_run=True,
                    prepared=(context, decision),
                )
            except Exception as exc:
                result = {
                    "status": "SCAN_ERROR",
                    "signal": "HOLD",
                    "reason": f"{type(exc).__name__}: {exc}",
                    "confidence": 0.0,
                }
            result["universe"] = {
                "ticker": candidate.instrument.ticker,
                "figi": candidate.instrument.figi,
                "name": candidate.instrument.name,
                "asset_type": candidate.instrument.asset_type,
                "currency": candidate.instrument.currency,
                "average_turnover": candidate.average_turnover,
            }
            evaluated.append((candidate, result))

        actionable = [
            pair
            for pair in evaluated
            if pair[1].get("status") == "SIGNAL_READY" and pair[1].get("order")
        ]
        sells = [pair for pair in actionable if pair[1]["order"]["side"] == "SELL"]
        buys = sorted(
            [pair for pair in actionable if pair[1]["order"]["side"] == "BUY"],
            key=lambda pair: pair[1].get("confidence", 0),
            reverse=True,
        )
        executed = []
        for candidate, _ in sells + buys:
            identifier = candidate.instrument.figi or candidate.instrument.instrument_id
            try:
                result = self.execute_signal(ticker=identifier)
            except Exception as exc:
                result = {
                    "status": "EXECUTION_ERROR",
                    "reason": f"{type(exc).__name__}: {exc}",
                }
            result["universe"] = {
                "ticker": candidate.instrument.ticker,
                "figi": candidate.instrument.figi,
                "average_turnover": candidate.average_turnover,
            }
            executed.append(result)

        final = self.paper_portfolio.snapshot()
        return {
            "status": "PAPER_SCAN_COMPLETE",
            "signal": "HOLD",
            "reason": "Up to ten liquid, fresh RUB shares were evaluated using read-only market data",
            "universe": universe.summary(),
            "candidate_pool": len(tradable_shares),
            "scanned": len(evaluated),
            "actionable": len(actionable),
            "executed": len(executed),
            "cash": final.cash,
            "equity": final.equity,
            "realized_pnl": final.realized_pnl,
            "total_commission": final.total_commission,
            "results": executed,
        }

    def _execute_market_scan(self):
        snapshot = self.market.get_universe(
            refresh_status=True,
            max_instruments=self.config.market_scan_max_universe_instruments,
        )
        tradable = snapshot.tradable
        prices = self.market.get_last_prices(
            [item.instrument_id for item in tradable if item.instrument_id]
        )

        held_ids = set()
        if self.config.execution_mode == "sandbox":
            try:
                portfolio = self.execution.get_portfolio_state()
                held_ids = {
                    position.instrument_id
                    for position in portfolio.positions
                }
            except Exception:
                pass

        asset_priority = {
            "share": 0,
            "etf": 1,
            "bond": 2,
            "futures": 3,
        }
        ordered = sorted(
            tradable,
            key=lambda item: (
                0 if item.instrument_id in held_ids or item.figi in held_ids else 1,
                asset_priority.get(item.asset_type, 9),
                item.ticker,
            ),
        )

        max_candidates = max(1, int(self.config.market_scan_max_candidates))
        candidates = ordered[:max_candidates]

        evaluated = []
        for instrument in candidates:
            if instrument.instrument_id not in prices and instrument.figi not in prices:
                continue
            identifier = instrument.figi or instrument.instrument_id
            try:
                result = self.execute_signal(ticker=identifier, dry_run=True)
            except Exception as exc:
                result = {
                    "status": "SCAN_ERROR",
                    "signal": "HOLD",
                    "reason": f"{type(exc).__name__}: {exc}",
                    "confidence": 0.0,
                }
            result["universe"] = {
                "ticker": instrument.ticker,
                "figi": instrument.figi,
                "name": instrument.name,
                "asset_type": instrument.asset_type,
                "exchange": instrument.exchange,
                "currency": instrument.currency,
            }
            evaluated.append(result)

        actionable = [
            item for item in evaluated
            if item.get("status") == "SIGNAL_READY"
            and item.get("order")
        ]
        sells = sorted(
            [item for item in actionable if item["order"]["side"] == "SELL"],
            key=lambda item: item.get("confidence", 0.0),
            reverse=True,
        )
        buys = sorted(
            [item for item in actionable if item["order"]["side"] == "BUY"],
            key=lambda item: item.get("confidence", 0.0),
            reverse=True,
        )

        executed = []
        # Release capital first. Then allocate the resulting cash to the
        # strongest BUY decisions rather than the alphabetical ticker order.
        for item in sells + buys:
            identifier = item["order"]["ticker"]
            try:
                result = self.execute_signal(ticker=identifier)
                result["universe"] = item["universe"]
                executed.append(result)
            except Exception as exc:
                executed.append({
                    "status": "EXECUTION_ERROR",
                    "signal": item.get("signal", "HOLD"),
                    "reason": f"{type(exc).__name__}: {exc}",
                    "universe": item["universe"],
                })

        return {
            "status": "MARKET_SCAN_COMPLETE",
            "signal": "HOLD",
            "reason": "Full T-Invest universe scanned and portfolio decisions ranked",
            "universe": snapshot.summary(),
            "scanned": len(evaluated),
            "scan_candidates": len(candidates),
            "scan_universe": len(tradable),
            "actionable": len(actionable),
            "sell_candidates": len(sells),
            "buy_candidates": len(buys),
            "executed": len(executed),
            "results": executed,
        }

    def status(self) -> dict:
        paper_account = (
            self.paper_portfolio.snapshot()
            if self.paper_portfolio is not None
            else None
        )
        return {
            "execution_mode": self.config.execution_mode,
            "ticker": self.config.ticker,
            "market_data": self.market.__class__.__name__,
            "decision_pipeline": self.pipeline.__class__.__name__,
            "approved_model": self.config.model_path or "disabled",
            "approved_outcome_model": self.config.outcome_model_path or "disabled",
            "execution": self.execution.__class__.__name__,
            "cash": paper_account.cash if paper_account else None,
            "equity": paper_account.equity if paper_account else None,
            "performance_journal": self.performance_journal.snapshot(self.config.ticker).__dict__,
            "positions": (
                {
                    ticker: {
                        "quantity": position.quantity,
                        "average_price": position.average_price,
                        "target_price": position.target_price,
                    }
                    for ticker, position in paper_account.positions.items()
                }
                if paper_account
                else {}
            ),
            "sandbox_positions": dict(self.sandbox_positions),
        }
