from __future__ import annotations

from time import sleep
from typing import Any, Callable


TERMINAL_STATUSES = {"FILLED", "CANCELLED", "REJECTED"}
KNOWN_STATUSES = {
    "SUBMITTED",
    "ACTIVE",
    "PARTIALLY_FILLED",
    "FILLED",
    "CANCELLED",
    "REJECTED",
}


def _money_value(value: Any) -> float | None:
    if value is None:
        return None
    units = getattr(value, "units", None)
    nano = getattr(value, "nano", None)
    if units is None and nano is None:
        return None
    return float(units or 0) + float(nano or 0) / 1_000_000_000


def _numeric_value(value: Any) -> float | None:
    if isinstance(value, (int, float)):
        return float(value)
    return _money_value(value)


def _quantity_value(position: Any) -> float | None:
    for field_name in ("quantity", "quantity_lots", "balance"):
        value = getattr(position, field_name, None)
        result = _numeric_value(value)
        if result is not None:
            return result
    return None


def normalize_order_status(value: Any, executed: int = 0, requested: int = 0) -> str:
    raw = str(value or "").upper()
    compact = "".join(ch for ch in raw if ch.isalpha())

    if requested > 0 and executed >= requested:
        return "FILLED"
    if "REJECT" in compact:
        return "REJECTED"
    if "CANCEL" in compact:
        return "CANCELLED"
    if "PARTIALLY" in compact or "PARTIAL" in compact:
        return "PARTIALLY_FILLED"
    if compact.endswith("FILL") or compact == "FILL":
        return "FILLED"
    if "NEW" in compact or "ACTIVE" in compact:
        return "ACTIVE"
    if executed > 0:
        return "PARTIALLY_FILLED"
    return "SUBMITTED"


class SandboxOrderReconciler:
    """Read and normalize remote Sandbox order and position state.

    The reconciler never creates, modifies, or cancels orders.
    """

    def __init__(
        self,
        sandbox: Any,
        account_id: str,
        sleep_fn: Callable[[float], None] = sleep,
    ):
        if not account_id:
            raise ValueError("account_id is required")
        self.sandbox = sandbox
        self.account_id = account_id
        self.sleep_fn = sleep_fn

    def get_order_status(self, order_id: str) -> dict:
        if not order_id:
            raise ValueError("order_id is required")

        getter = getattr(self.sandbox, "get_sandbox_order_state", None)
        if getter is None:
            raise RuntimeError("T-Bank SDK does not expose get_sandbox_order_state")

        state = getter(account_id=self.account_id, order_id=order_id)
        requested = int(getattr(state, "lots_requested", 0) or 0)
        executed = int(getattr(state, "lots_executed", 0) or 0)
        status = normalize_order_status(
            getattr(state, "execution_report_status", None),
            executed=executed,
            requested=requested,
        )

        return {
            "status": status,
            "order_id": order_id,
            "account_id": self.account_id,
            "requested_quantity": requested,
            "executed_quantity": executed,
            "remaining_quantity": max(requested - executed, 0),
            "executed_price": _money_value(
                getattr(state, "executed_order_price", None)
            ),
            "initial_price": _money_value(
                getattr(state, "initial_order_price", None)
            ),
            "direction": str(getattr(state, "direction", "")),
            "order_type": str(getattr(state, "order_type", "")),
            "raw_execution_report_status": str(
                getattr(state, "execution_report_status", "")
            ),
        }

    def wait_for_completion(
        self,
        order_id: str,
        timeout_seconds: float = 30.0,
        poll_interval_seconds: float = 2.0,
    ) -> dict:
        if timeout_seconds < 0:
            raise ValueError("timeout_seconds must be non-negative")
        if poll_interval_seconds <= 0:
            raise ValueError("poll_interval_seconds must be positive")

        elapsed = 0.0
        while True:
            result = self.get_order_status(order_id)
            if result["status"] in TERMINAL_STATUSES:
                return result
            if elapsed >= timeout_seconds:
                return result
            delay = min(poll_interval_seconds, timeout_seconds - elapsed)
            self.sleep_fn(delay)
            elapsed += delay

    def get_position(self, ticker: str) -> float:
        if not ticker:
            raise ValueError("ticker is required")

        getter = getattr(self.sandbox, "get_sandbox_positions", None)
        if getter is None:
            raise RuntimeError("T-Bank SDK does not expose get_sandbox_positions")

        response = getter(account_id=self.account_id)
        positions = (
            getattr(response, "securities", None)
            or getattr(response, "positions", None)
            or []
        )
        for position in positions:
            if getattr(position, "figi", "") == ticker:
                quantity = _quantity_value(position)
                if quantity is None:
                    raise RuntimeError(
                        f"Could not read Sandbox position quantity for {ticker}"
                    )
                return quantity
        return 0.0

    def reconcile(self, order_id: str, ticker: str) -> dict:
        order = self.get_order_status(order_id)
        return {
            **order,
            "position_quantity": self.get_position(ticker),
        }
