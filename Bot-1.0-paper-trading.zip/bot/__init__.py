"""Bot-1.0 trading bot package."""
