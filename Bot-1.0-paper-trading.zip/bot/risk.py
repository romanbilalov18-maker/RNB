from dataclasses import dataclass

from bot.market_regime import MarketRegime, RegimeResult
from bot.meta_decision import MetaDecision
from bot.models import DecisionContext, OrderRequest


@dataclass(frozen=True)
class RiskAssessment:
    approved: bool
    order: OrderRequest | None
    reason: str


class RiskManager:
    """Final order gate using decision, regime, capital and position limits."""

    def __init__(self, max_position_percent: float = 10.0, min_confidence: float = 0.5):
        if not 0 < max_position_percent <= 100:
            raise ValueError("max_position_percent must be in (0, 100]")
        if not 0 <= min_confidence <= 1:
            raise ValueError("min_confidence must be between 0 and 1")
        self.max_position_percent = max_position_percent
        self.min_confidence = min_confidence

    def assess(
        self,
        context: DecisionContext,
        *args,
        regime: RegimeResult | None = None,
        decision: MetaDecision | None = None,
        quantity: int | None = None,
        equity: float | None = None,
        current_position_quantity: int = 0,
    ) -> RiskAssessment:
        if args:
            if isinstance(args[0], RegimeResult):
                if len(args) != 4:
                    raise TypeError("regime-aware assess requires regime, decision, quantity, equity")
                regime, decision, quantity, equity = args
            else:
                if len(args) != 3:
                    raise TypeError("legacy assess requires decision, quantity, equity")
                decision, quantity, equity = args

        if decision is None or quantity is None or equity is None:
            raise TypeError("decision, quantity and equity are required")
        if current_position_quantity < 0:
            return RiskAssessment(False, None, "Current position quantity must not be negative")
        if decision.signal == "HOLD":
            return RiskAssessment(False, None, "Meta decision is HOLD")
        if regime is not None and regime.regime not in {MarketRegime.TREND, MarketRegime.LOW_VOLATILITY}:
            return RiskAssessment(False, None, f"Risk rejected directional decision in {regime.regime.value} regime")
        if decision.confidence < self.min_confidence:
            return RiskAssessment(False, None, f"Decision confidence below risk threshold {self.min_confidence:.2f}")
        if quantity <= 0:
            return RiskAssessment(False, None, "Order quantity must be positive")
        if equity <= 0:
            return RiskAssessment(False, None, "Equity must be positive")
        if decision.signal == "SELL" and quantity > current_position_quantity:
            return RiskAssessment(
                False, None,
                f"SELL quantity {quantity} exceeds current position {current_position_quantity}",
            )

        order = OrderRequest(
            ticker=context.ticker,
            side=decision.signal,
            quantity=quantity,
            price=context.price,
        )
        if not self.approve(order, equity, current_position_quantity):
            return RiskAssessment(False, order, "Risk limit rejected order")
        return RiskAssessment(True, order, "Risk approved order")

    def approve(
        self,
        order: OrderRequest,
        equity: float,
        current_position_quantity: int = 0,
    ) -> bool:
        if equity <= 0 or order.quantity <= 0 or order.price <= 0:
            return False
        if current_position_quantity < 0:
            return False
        if order.side == "SELL":
            return order.quantity <= current_position_quantity
        total_position_value = (current_position_quantity + order.quantity) * order.price
        return total_position_value <= equity * self.max_position_percent / 100
