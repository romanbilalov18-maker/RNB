from dataclasses import dataclass
from datetime import datetime

from bot.dataset import Dataset
from bot.models import DecisionContext, OrderRequest
from bot.pipeline import TradingDecisionPipeline
from bot.portfolio import Portfolio
from bot.risk import RiskManager


@dataclass(frozen=True)
class BacktestTrade:
    timestamp: datetime
    ticker: str
    signal: str
    quantity: int
    price: float
    commission: float
    realized_pnl: float


@dataclass(frozen=True)
class BacktestResult:
    initial_balance: float
    final_equity: float
    total_pnl: float
    return_percent: float
    trades: tuple[BacktestTrade, ...]
    equity_curve: tuple[float, ...]
    max_drawdown_percent: float
    commissions: float

    @property
    def trade_count(self) -> int:
        return len(self.trades)


class BacktestEngine:
    """Run the same trading decision pipeline used by Sandbox execution."""

    def __init__(
        self,
        pipeline: TradingDecisionPipeline,
        risk_manager: RiskManager,
        initial_balance: float = 1_000_000.0,
        commission_rate: float = 0.0005,
    ) -> None:
        if initial_balance <= 0:
            raise ValueError("initial_balance must be positive")
        if commission_rate < 0:
            raise ValueError("commission_rate must be non-negative")

        self.pipeline = pipeline
        self.risk_manager = risk_manager
        self.initial_balance = initial_balance
        self.commission_rate = commission_rate

    def run(self, dataset: Dataset, quantity: int = 1) -> BacktestResult:
        if quantity <= 0:
            raise ValueError("quantity must be positive")
        if len(dataset) == 0:
            raise ValueError("dataset must not be empty")

        portfolio = Portfolio(
            cash=self.initial_balance,
            commission_rate=self.commission_rate,
        )
        trades: list[BacktestTrade] = []
        equity_curve: list[float] = []

        for index, candle in enumerate(dataset.candles):
            context = DecisionContext(
                ticker=candle.ticker,
                price=candle.close,
                timestamp=candle.timestamp,
                candles=tuple(dataset.candles[: index + 1]),
            )
            decision = self.pipeline.decide(context)
            signal = decision.meta

            if signal.signal in {"BUY", "SELL"}:
                position = portfolio.positions.get(candle.ticker)
                if signal.signal == "SELL" and (
                    position is None or position.quantity < quantity
                ):
                    equity_curve.append(
                        portfolio.equity({candle.ticker: candle.close})
                    )
                    continue

                # A persistent BUY signal represents an existing directional
                # view, not a request to pyramid on every candle. Keep one
                # position until a SELL signal closes it.
                if signal.signal == "BUY" and (
                    position is not None and position.quantity >= quantity
                ):
                    equity_curve.append(
                        portfolio.equity({candle.ticker: candle.close})
                    )
                    continue

                order = OrderRequest(
                    ticker=candle.ticker,
                    side=signal.signal,
                    quantity=quantity,
                    price=candle.close,
                )
                equity = portfolio.equity({candle.ticker: candle.close})

                current_quantity = position.quantity if position is not None else 0
                if self.risk_manager.approve(order, equity, current_position_quantity=current_quantity):
                    previous_realized_pnl = portfolio.realized_pnl
                    execution = portfolio.execute(
                        ticker=order.ticker,
                        side=order.side,
                        quantity=order.quantity,
                        price=order.price,
                    )
                    realized_pnl = (
                        portfolio.realized_pnl - previous_realized_pnl
                    )

                    trades.append(
                        BacktestTrade(
                            timestamp=candle.timestamp,
                            ticker=candle.ticker,
                            signal=signal.signal,
                            quantity=quantity,
                            price=candle.close,
                            commission=execution["commission"],
                            realized_pnl=realized_pnl,
                        )
                    )

            equity_curve.append(portfolio.equity({candle.ticker: candle.close}))

        final_equity = equity_curve[-1]
        total_pnl = final_equity - self.initial_balance
        return_percent = total_pnl / self.initial_balance * 100

        return BacktestResult(
            initial_balance=self.initial_balance,
            final_equity=final_equity,
            total_pnl=total_pnl,
            return_percent=return_percent,
            trades=tuple(trades),
            equity_curve=tuple(equity_curve),
            max_drawdown_percent=_max_drawdown_percent(equity_curve),
            commissions=portfolio.commissions,
        )


def _max_drawdown_percent(equity_curve: list[float]) -> float:
    if not equity_curve:
        return 0.0

    peak = equity_curve[0]
    max_drawdown = 0.0

    for equity in equity_curve:
        peak = max(peak, equity)
        if peak > 0:
            drawdown = (peak - equity) / peak * 100
            max_drawdown = max(max_drawdown, drawdown)

    return max_drawdown
