from datetime import datetime, timedelta, timezone
import time

from bot.models import HistoricalCandle, MarketQuote
from bot.market_universe import MarketUniverseSnapshot, TBankMarketUniverse


class MarketDataProvider:
    """Read-only market data interface."""

    def get_quote(self, ticker: str) -> MarketQuote:
        raise NotImplementedError


class StubMarketData(MarketDataProvider):
    def get_quote(self, ticker: str) -> MarketQuote:
        raise RuntimeError("Market data provider is not configured")


class TBankMarketData(MarketDataProvider):
    """Read-only T-Bank market data adapter."""

    def __init__(self, token: str, history_days: int = 7, history_cache_seconds: float = 300.0):
        if not token or not token.strip():
            raise ValueError("T-Bank token is required")
        if history_days <= 0:
            raise ValueError("history_days must be positive")
        if history_cache_seconds < 0:
            raise ValueError("history_cache_seconds must be non-negative")
        self.token = token.strip()
        self.history_days = history_days
        self.history_cache_seconds = history_cache_seconds
        self.universe = TBankMarketUniverse(self.token)
        self._history_cache: dict[str, tuple[float, tuple[HistoricalCandle, ...]]] = {}
        self._lot_cache: dict[str, int] = {}

    def get_universe(
        self,
        *,
        refresh_status: bool = True,
        max_instruments: int | None = None,
    ) -> MarketUniverseSnapshot:
        return self.universe.load(
            refresh_status=refresh_status,
            max_instruments=max_instruments,
        )

    def get_last_prices(self, instrument_ids: list[str]) -> dict[str, float]:
        if not instrument_ids:
            return {}
        try:
            from t_tech.invest import Client
        except ImportError as exc:
            raise RuntimeError(
                "T-Bank SDK is not installed; add t-tech-investments to requirements.txt"
            ) from exc

        result: dict[str, float] = {}
        with Client(self.token) as client:
            for start in range(0, len(instrument_ids), 100):
                chunk = instrument_ids[start:start + 100]
                try:
                    response = _call_with_retry(client.market_data.get_last_prices, instrument_id=chunk)
                except TypeError:
                    response = _call_with_retry(client.market_data.get_last_prices, figi=chunk)
                for item in getattr(response, "last_prices", ()) or ():
                    price = _quotation_to_float(getattr(item, "price", None))
                    if price is None or price <= 0:
                        continue
                    for key in (
                        getattr(item, "instrument_uid", None),
                        getattr(item, "figi", None),
                        getattr(item, "ticker", None),
                    ):
                        if key:
                            result[str(key)] = price
        return result

    def is_trading(self, ticker: str) -> bool:
        """Return whether the instrument can currently be traded through the API."""
        try:
            from t_tech.invest import Client
        except ImportError as exc:
            raise RuntimeError(
                "T-Bank SDK is not installed; add t-tech-investments to requirements.txt"
            ) from exc

        with Client(self.token) as client:
            status = _call_with_retry(client.market_data.get_trading_status, figi=ticker)

        return bool(
            getattr(status, "api_trade_available_flag", False)
            and (
                getattr(status, "limit_order_available_flag", False)
                or getattr(status, "market_order_available_flag", False)
            )
        )

    def get_quote(self, ticker: str) -> MarketQuote:
        try:
            from t_tech.invest import CandleInterval, Client
        except ImportError as exc:
            raise RuntimeError(
                "T-Bank SDK is not installed; add t-tech-investments to requirements.txt"
            ) from exc

        now = datetime.now(timezone.utc)
        cached = self._history_cache.get(ticker)

        if cached and time.monotonic() - cached[0] < self.history_cache_seconds:
            historical_candles = list(cached[1])
        else:
            start = now - timedelta(days=self.history_days)
            with Client(self.token) as client:
                candles = _call_with_retry(
                    client.get_all_candles,
                    figi=ticker,
                    from_=start,
                    to=now,
                    interval=CandleInterval.CANDLE_INTERVAL_1_MIN,
                )
                candle_list = list(candles)
            if not candle_list:
                raise RuntimeError(f"No historical candles returned for {ticker}")

            historical_candles = []
            for candle in candle_list:
                open_price = _quotation_to_float(getattr(candle, "open", None))
                high_price = _quotation_to_float(getattr(candle, "high", None))
                low_price = _quotation_to_float(getattr(candle, "low", None))
                close_price = _quotation_to_float(getattr(candle, "close", None))
                volume = int(getattr(candle, "volume", 0) or 0)
                candle_time = getattr(candle, "time", None)
                if (
                    candle_time is not None
                    and open_price is not None
                    and high_price is not None
                    and low_price is not None
                    and close_price is not None
                    and close_price > 0
                ):
                    historical_candles.append(
                        HistoricalCandle(
                            ticker=ticker,
                            timestamp=candle_time,
                            open=open_price,
                            high=high_price,
                            low=low_price,
                            close=close_price,
                            volume=volume,
                        )
                    )

            self._history_cache[ticker] = (time.monotonic(), tuple(historical_candles))

        closes = tuple(candle.close for candle in historical_candles)
        if not closes:
            raise RuntimeError(f"No valid candle closes returned for {ticker}")

        # Refresh current price every cycle; historical candles remain cached.
        with Client(self.token) as client:
            last_prices = _call_with_retry(client.market_data.get_last_prices, figi=[ticker])
        prices = getattr(last_prices, "last_prices", None)
        if not prices:
            raise RuntimeError(f"No current market price returned for {ticker}")

        item = prices[0]
        price = _quotation_to_float(getattr(item, "price", None))
        if price is None or price <= 0:
            raise RuntimeError(f"Invalid market price returned for {ticker}")

        lot_size = self._get_lot_size(ticker)

        timestamp = getattr(item, "time", None) or historical_candles[-1].timestamp
        return MarketQuote(
            ticker=ticker,
            price=price,
            timestamp=timestamp,
            closes=closes,
            candles=tuple(historical_candles),
            lot_size=lot_size,
        )

    def _get_lot_size(self, ticker: str) -> int:
        cached = self._lot_cache.get(ticker)
        if cached:
            return cached

        try:
            from t_tech.invest import Client
        except ImportError as exc:
            raise RuntimeError(
                "T-Bank SDK is not installed; add t-tech-investments to requirements.txt"
            ) from exc

        with Client(self.token) as client:
            finder = getattr(client.instruments, "find_instrument", None)
            if finder is None:
                raise RuntimeError("T-Bank SDK does not expose find_instrument")

            try:
                response = _call_with_retry(finder, query=ticker)
            except TypeError:
                from t_tech.invest import FindInstrumentRequest
                response = _call_with_retry(finder, request=FindInstrumentRequest(query=ticker))

        instruments = list(getattr(response, "instruments", ()) or ())
        exact = next(
            (
                item for item in instruments
                if str(getattr(item, "figi", "") or "") == ticker
                or str(getattr(item, "instrument_uid", "") or "") == ticker
                or str(getattr(item, "ticker", "") or "") == ticker
            ),
            None,
        )
        lot_size = int(getattr(exact, "lot", 1) or 1) if exact is not None else 1
        if lot_size <= 0:
            lot_size = 1
        self._lot_cache[ticker] = lot_size
        return lot_size



def _call_with_retry(method, **kwargs):
    """Retry transient gRPC/T-Invest transport failures."""
    for attempt in range(1, 4):
        try:
            return method(**kwargs)
        except Exception as exc:
            message = str(exc)
            transient = (
                "Stream removed" in message
                or "StatusCode.UNKNOWN" in message
                or "temporarily unavailable" in message.lower()
            )
            if not transient or attempt == 3:
                raise
            time.sleep(attempt)

def _quotation_to_float(value) -> float | None:
    if value is None:
        return None

    units = getattr(value, "units", None)
    nano = getattr(value, "nano", None)
    if units is None and nano is None:
        try:
            return float(value)
        except (TypeError, ValueError):
            return None

    try:
        return float(units or 0) + float(nano or 0) / 1_000_000_000
    except (TypeError, ValueError):
        return None
