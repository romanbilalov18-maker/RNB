from bot.features import FeatureEngine
from bot.models import DecisionContext, SignalResult


OUTCOME_TARGET_DEFINITION = (
    "1 if the completed trade outcome is WIN, else 0; BREAKEVEN excluded"
)


class OutcomeModelDecisionEngine:
    """Use an approved outcome model to gate an already selected direction."""

    def __init__(
        self,
        model,
        feature_engine: FeatureEngine | None = None,
        min_win_probability: float = 0.5,
    ) -> None:
        if not hasattr(model, "predict_proba"):
            raise ValueError("outcome model must provide predict_proba")
        if not 0 <= min_win_probability <= 1:
            raise ValueError("min_win_probability must be between 0 and 1")
        self.model = model
        self.feature_engine = feature_engine or FeatureEngine()
        self.min_win_probability = min_win_probability

    def evaluate(self, context: DecisionContext, candidate: SignalResult) -> SignalResult:
        if candidate.signal == "HOLD":
            return candidate
        if not context.candles:
            raise ValueError("decision context must contain historical candles")

        from bot.dataset import Dataset

        dataset = Dataset.from_candles(context.candles)
        feature = self.feature_engine.compute(dataset, len(dataset) - 1)
        values = self._feature_values(feature)

        if values is None:
            return SignalResult(
                ticker=context.ticker,
                signal="HOLD",
                confidence=0.0,
                reason="Outcome model features are not warmed up",
            )

        probabilities = self.model.predict_proba([values])[0]
        classes = list(getattr(self.model, "classes_", ()))
        if not classes:
            classifier = getattr(self.model, "named_steps", {}).get("classifier")
            classes = list(getattr(classifier, "classes_", ()))
        if len(probabilities) != len(classes):
            raise ValueError("outcome model probabilities and classes do not match")

        probability_by_class = {
            int(label): float(probability)
            for label, probability in zip(classes, probabilities)
        }
        win_probability = probability_by_class.get(1)
        loss_probability = probability_by_class.get(0)
        if win_probability is None or loss_probability is None:
            raise ValueError("outcome model must support binary classes 0 and 1")

        if win_probability < self.min_win_probability:
            return SignalResult(
                ticker=context.ticker,
                signal="HOLD",
                confidence=win_probability,
                reason=(
                    f"Outcome gate rejected {candidate.signal}: "
                    f"WIN probability {win_probability:.3f} "
                    f"below {self.min_win_probability:.3f}"
                ),
            )

        return SignalResult(
            ticker=context.ticker,
            signal=candidate.signal,
            confidence=min(candidate.confidence, win_probability),
            reason=(
                f"Outcome gate approved {candidate.signal}: "
                f"WIN probability {win_probability:.3f}"
            ),
        )

    @staticmethod
    def _feature_values(feature) -> tuple[float, ...] | None:
        names = (
            "sma_fast", "sma_slow", "ema_fast", "ema_slow",
            "return_1", "momentum", "volatility", "rsi", "atr",
            "volume_ratio",
        )
        values = tuple(getattr(feature, name) for name in names)
        if any(value is None for value in values):
            return None
        return tuple(float(value) for value in values)
