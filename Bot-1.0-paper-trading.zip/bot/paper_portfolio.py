from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
import sqlite3
from typing import Mapping


@dataclass(frozen=True)
class PaperPosition:
    quantity: int
    average_price: float
    lot_size: int
    target_price: float


@dataclass(frozen=True)
class PaperPortfolioSnapshot:
    initial_cash: float
    cash: float
    equity: float
    positions: dict[str, PaperPosition]
    realized_pnl: float
    total_commission: float
    trade_count: int


class PaperPortfolioStore:
    """Persistent, local-only paper trading account backed by SQLite."""

    def __init__(
        self,
        path: str,
        initial_cash: float = 10_000.0,
        commission_rate: float = 0.0005,
    ) -> None:
        if not path.strip():
            raise ValueError("portfolio path must not be empty")
        if initial_cash <= 0:
            raise ValueError("initial_cash must be positive")
        if commission_rate < 0:
            raise ValueError("commission_rate must be non-negative")
        self.path = Path(path)
        if str(self.path) != ":memory:":
            self.path.parent.mkdir(parents=True, exist_ok=True)
        # Keep one connection open so :memory: has the same lifetime as this store.
        self._connection = sqlite3.connect(str(self.path))
        self._connection.row_factory = sqlite3.Row
        self.commission_rate = float(commission_rate)
        self._initialize(float(initial_cash))

    def _initialize(self, initial_cash: float) -> None:
        with self._connection as conn:
            conn.execute(
                """CREATE TABLE IF NOT EXISTS account (
                    id INTEGER PRIMARY KEY CHECK (id = 1),
                    initial_cash REAL NOT NULL,
                    cash REAL NOT NULL,
                    realized_pnl REAL NOT NULL DEFAULT 0,
                    total_commission REAL NOT NULL DEFAULT 0
                )"""
            )
            conn.execute(
                """CREATE TABLE IF NOT EXISTS positions (
                    ticker TEXT PRIMARY KEY,
                    quantity INTEGER NOT NULL,
                    average_price REAL NOT NULL,
                    lot_size INTEGER NOT NULL,
                    target_price REAL NOT NULL
                )"""
            )
            conn.execute(
                """CREATE TABLE IF NOT EXISTS trades (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    ticker TEXT NOT NULL,
                    side TEXT NOT NULL,
                    quantity INTEGER NOT NULL,
                    price REAL NOT NULL,
                    commission REAL NOT NULL,
                    realized_pnl REAL
                )"""
            )
            conn.execute(
                """CREATE TABLE IF NOT EXISTS market_marks (
                    ticker TEXT PRIMARY KEY,
                    price REAL NOT NULL,
                    timestamp TEXT NOT NULL
                )"""
            )
            conn.execute(
                "INSERT OR IGNORE INTO account (id, initial_cash, cash) VALUES (1, ?, ?)",
                (initial_cash, initial_cash),
            )

    def snapshot(
        self, prices: Mapping[str, float] | None = None
    ) -> PaperPortfolioSnapshot:
        prices = dict(prices or {})
        saved_marks = self._connection.execute(
            "SELECT ticker, price FROM market_marks"
        ).fetchall()
        for mark in saved_marks:
            prices.setdefault(mark["ticker"], float(mark["price"]))
        row = self._connection.execute(
            "SELECT initial_cash, cash, realized_pnl, total_commission FROM account WHERE id=1"
        ).fetchone()
        if row is None:
            raise RuntimeError("paper portfolio account is missing")
        rows = self._connection.execute(
            "SELECT ticker, quantity, average_price, lot_size, target_price FROM positions"
        ).fetchall()
        positions = {
            item["ticker"]: PaperPosition(
                quantity=int(item["quantity"]),
                average_price=float(item["average_price"]),
                lot_size=int(item["lot_size"]),
                target_price=float(item["target_price"]),
            )
            for item in rows
        }
        equity = float(row["cash"]) + sum(
            position.quantity
            * float(prices.get(ticker, position.average_price))
            for ticker, position in positions.items()
        )
        trade_count = int(
            self._connection.execute("SELECT COUNT(*) FROM trades").fetchone()[0]
        )
        return PaperPortfolioSnapshot(
            initial_cash=float(row["initial_cash"]),
            cash=float(row["cash"]),
            equity=equity,
            positions=positions,
            realized_pnl=float(row["realized_pnl"]),
            total_commission=float(row["total_commission"]),
            trade_count=trade_count,
        )

    def update_marks(self, prices: Mapping[str, float]) -> None:
        """Persist latest observed prices for mark-to-market snapshots."""
        timestamp = datetime.now(timezone.utc).isoformat()
        valid = [
            (ticker, float(price), timestamp)
            for ticker, price in prices.items()
            if ticker and float(price) > 0
        ]
        if not valid:
            return
        with self._connection:
            self._connection.executemany(
                """INSERT INTO market_marks (ticker, price, timestamp)
                   VALUES (?, ?, ?)
                   ON CONFLICT(ticker) DO UPDATE SET
                     price=excluded.price, timestamp=excluded.timestamp""",
                valid,
            )

    def execute(
        self,
        ticker: str,
        side: str,
        quantity: int,
        price: float,
        lot_size: int = 1,
        target_price: float | None = None,
    ) -> dict:
        ticker = ticker.strip()
        side = side.upper()
        if not ticker:
            raise ValueError("ticker must not be empty")
        if side not in {"BUY", "SELL"}:
            raise ValueError("side must be BUY or SELL")
        if quantity <= 0 or price <= 0 or lot_size <= 0:
            raise ValueError("quantity, price and lot_size must be positive")
        if quantity % lot_size:
            raise ValueError("quantity must be a whole number of lots")
        executed_at = datetime.now(timezone.utc).isoformat()
        with self._connection:
            account = self._connection.execute(
                "SELECT cash, realized_pnl, total_commission FROM account WHERE id=1"
            ).fetchone()
            position = self._connection.execute(
                "SELECT quantity, average_price, lot_size, target_price FROM positions WHERE ticker=?",
                (ticker,),
            ).fetchone()
            gross = quantity * price
            commission = round(gross * self.commission_rate, 2)
            realized = 0.0

            if side == "BUY":
                cost = gross + commission
                if cost > float(account["cash"]) + 1e-9:
                    raise ValueError("insufficient cash")
                if position is not None and int(position["lot_size"]) != lot_size:
                    raise ValueError("lot_size does not match the open position")
                old_quantity = int(position["quantity"]) if position else 0
                old_basis = float(position["average_price"]) * old_quantity if position else 0.0
                new_quantity = old_quantity + quantity
                average_price = (old_basis + cost) / new_quantity
                saved_target = (
                    float(target_price)
                    if target_price is not None
                    else (float(position["target_price"]) if position else average_price)
                )
                self._connection.execute(
                    """INSERT INTO positions (ticker, quantity, average_price, lot_size, target_price)
                       VALUES (?, ?, ?, ?, ?)
                       ON CONFLICT(ticker) DO UPDATE SET
                         quantity=excluded.quantity,
                         average_price=excluded.average_price,
                         lot_size=excluded.lot_size,
                         target_price=excluded.target_price""",
                    (ticker, new_quantity, average_price, lot_size, saved_target),
                )
                new_cash = float(account["cash"]) - cost
            else:
                if position is None or quantity > int(position["quantity"]):
                    raise ValueError("insufficient position")
                if int(position["lot_size"]) != lot_size:
                    raise ValueError("lot_size does not match the open position")
                realized = gross - commission - quantity * float(position["average_price"])
                remaining = int(position["quantity"]) - quantity
                if remaining:
                    self._connection.execute(
                        "UPDATE positions SET quantity=? WHERE ticker=?",
                        (remaining, ticker),
                    )
                else:
                    self._connection.execute(
                        "DELETE FROM positions WHERE ticker=?", (ticker,)
                    )
                new_cash = float(account["cash"]) + gross - commission

            self._connection.execute(
                "UPDATE account SET cash=?, realized_pnl=realized_pnl+?, total_commission=total_commission+? WHERE id=1",
                (new_cash, realized, commission),
            )
            self._connection.execute(
                "INSERT INTO trades (timestamp, ticker, side, quantity, price, commission, realized_pnl) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (
                    executed_at,
                    ticker,
                    side,
                    quantity,
                    price,
                    commission,
                    realized if side == "SELL" else None,
                ),
            )
        return {
            "status": "FILLED",
            "ticker": ticker,
            "side": side,
            "quantity": quantity,
            "price": price,
            "commission": commission,
            "realized_pnl": realized if side == "SELL" else None,
            "cash": new_cash,
        }

    def reset(self, confirm: bool = False) -> None:
        if not confirm:
            raise ValueError("reset requires explicit confirmation")
        with self._connection:
            row = self._connection.execute(
                "SELECT initial_cash FROM account WHERE id=1"
            ).fetchone()
            initial_cash = float(row["initial_cash"])
            self._connection.execute("DELETE FROM positions")
            self._connection.execute("DELETE FROM trades")
            self._connection.execute("DELETE FROM market_marks")
            self._connection.execute(
                "UPDATE account SET cash=?, realized_pnl=0, total_commission=0 WHERE id=1",
                (initial_cash,),
            )

    def close(self) -> None:
        self._connection.close()
