from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
import pickle

from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from bot.dataset import Dataset
from bot.features import FeatureEngine, FeatureVector
from bot.trade_memory import TradeMemory, TradeLearningSample


FEATURE_NAMES = (
    "sma_fast",
    "sma_slow",
    "ema_fast",
    "ema_slow",
    "return_1",
    "momentum",
    "volatility",
    "rsi",
    "atr",
    "volume_ratio",
)


@dataclass(frozen=True)
class TrainingSample:
    timestamp: datetime
    values: tuple[float, ...]
    target: int


@dataclass(frozen=True)
class TrainingResult:
    model: Pipeline
    feature_names: tuple[str, ...]
    train_samples: tuple[TrainingSample, ...]
    validation_samples: tuple[TrainingSample, ...]
    target_definition: str

    @property
    def train_size(self) -> int:
        return len(self.train_samples)

    @property
    def validation_size(self) -> int:
        return len(self.validation_samples)

    def save(self, path: str | Path) -> None:
        destination = Path(path)
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open("wb") as handle:
            pickle.dump(self.model, handle)


class TrainingEngine:
    """Train a baseline direction classifier without future leakage."""

    def __init__(
        self,
        feature_engine: FeatureEngine | None = None,
        train_ratio: float = 0.8,
        max_iter: int = 500,
    ):
        if not 0 < train_ratio < 1:
            raise ValueError("train_ratio must be between 0 and 1")
        if max_iter <= 0:
            raise ValueError("max_iter must be positive")

        self.feature_engine = feature_engine or FeatureEngine()
        self.train_ratio = train_ratio
        self.max_iter = max_iter

    def build_samples(self, dataset: Dataset) -> list[TrainingSample]:
        if len(dataset) < 2:
            raise ValueError("dataset must contain at least two candles")

        features = self.feature_engine.build(dataset)
        samples: list[TrainingSample] = []

        for index in range(len(features) - 1):
            feature = features[index]
            values = _feature_values(feature)
            if values is None:
                continue

            current_close = dataset.candles[index].close
            next_close = dataset.candles[index + 1].close
            target = int(next_close > current_close)

            samples.append(
                TrainingSample(
                    timestamp=feature.timestamp,
                    values=values,
                    target=target,
                )
            )

        return samples

    def fit_samples(
        self,
        samples: list[TrainingSample] | tuple[TrainingSample, ...],
    ) -> Pipeline:
        """Fit a fresh classifier on exactly the supplied chronological samples."""
        if len(samples) < 2:
            raise ValueError("at least two training samples are required")

        targets = {sample.target for sample in samples}
        if targets != {0, 1}:
            raise ValueError("training samples must contain both target classes")

        model = Pipeline(
            steps=[
                ("scaler", StandardScaler()),
                (
                    "classifier",
                    LogisticRegression(
                        max_iter=self.max_iter,
                        random_state=0,
                    ),
                ),
            ]
        )

        x_train = [sample.values for sample in samples]
        y_train = [sample.target for sample in samples]
        model.fit(x_train, y_train)
        return model

    def build_memory_samples(
        self,
        memory: TradeMemory,
        *,
        feature_count: int | None = None,
    ) -> list[TrainingSample]:
        """Convert completed Trade Memory outcomes into chronological training samples.

        These samples predict trade outcome (WIN=1, LOSS=0), not next-candle
        direction. They are therefore not interchangeable with market-direction
        training samples used by the decision model.
        """
        expected_count = len(FEATURE_NAMES) if feature_count is None else feature_count
        if expected_count <= 0:
            raise ValueError("feature_count must be positive")
        memory_samples = memory.learning_samples(feature_count=expected_count)
        samples = [
            TrainingSample(
                timestamp=sample.timestamp,
                values=sample.features,
                target=sample.target,
            )
            for sample in memory_samples
        ]
        samples.sort(key=lambda sample: sample.timestamp)
        return samples

    def train_from_memory(self, memory: TradeMemory) -> TrainingResult:
        """Train an outcome model from completed Trade Memory, explicitly on demand."""
        samples = self.build_memory_samples(memory)
        if len(samples) < 4:
            raise ValueError("not enough completed trade samples for training")
        split_index = int(len(samples) * self.train_ratio)
        if split_index <= 0 or split_index >= len(samples):
            raise ValueError("training split leaves no validation samples")
        train_samples = tuple(samples[:split_index])
        validation_samples = tuple(samples[split_index:])
        model = self.fit_samples(train_samples)
        return TrainingResult(
            model=model,
            feature_names=FEATURE_NAMES,
            train_samples=train_samples,
            validation_samples=validation_samples,
            target_definition="1 if the completed trade outcome is WIN, else 0; BREAKEVEN excluded",
        )

    def train(self, dataset: Dataset) -> TrainingResult:
        samples = self.build_samples(dataset)
        if len(samples) < 4:
            raise ValueError("not enough complete feature samples for training")

        split_index = int(len(samples) * self.train_ratio)
        if split_index <= 0 or split_index >= len(samples):
            raise ValueError("training split leaves no validation samples")

        train_samples = tuple(samples[:split_index])
        validation_samples = tuple(samples[split_index:])

        model = self.fit_samples(train_samples)

        return TrainingResult(
            model=model,
            feature_names=FEATURE_NAMES,
            train_samples=train_samples,
            validation_samples=validation_samples,
            target_definition="1 if the next candle closes above the current candle, else 0",
        )


def load_model(path: str | Path) -> Pipeline:
    with Path(path).open("rb") as handle:
        model = pickle.load(handle)

    if not isinstance(model, Pipeline):
        raise ValueError("saved artifact is not a scikit-learn Pipeline")
    return model


def _feature_values(feature: FeatureVector) -> tuple[float, ...] | None:
    values = tuple(getattr(feature, name) for name in FEATURE_NAMES)
    if any(value is None for value in values):
        return None
    return tuple(float(value) for value in values)
