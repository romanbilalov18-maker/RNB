from __future__ import annotations

import os
import time

from bot.market import TBankMarketData
from bot.models import OrderRequest
from bot.sandbox_execution import SandboxExecution


def _money_value(value) -> float | None:
    if value is None:
        return None
    units = getattr(value, "units", None)
    nano = getattr(value, "nano", None)
    if units is None and nano is None:
        return None
    return float(units or 0) + float(nano or 0) / 1_000_000_000


def _quantity_value(position) -> float | None:
    for field_name in ("quantity", "quantity_lots", "balance"):
        value = getattr(position, field_name, None)
        if isinstance(value, (int, float)):
            return float(value)
        result = _money_value(value)
        if result is not None:
            return result
    return None


def _resolve_account(sandbox, account_id: str | None) -> str:
    if account_id:
        return account_id
    accounts = sandbox.get_sandbox_accounts()
    items = getattr(accounts, "accounts", None) or []
    if not items:
        opened = sandbox.open_sandbox_account()
        return opened.account_id
    return items[0].id


def _get_position(sandbox, account_id: str, ticker: str) -> float:
    positions = sandbox.get_sandbox_positions(account_id=account_id)
    items = getattr(positions, "securities", None) or getattr(positions, "positions", None) or []
    for position in items:
        if getattr(position, "figi", "") == ticker:
            quantity = _quantity_value(position)
            if quantity is None:
                raise RuntimeError("Could not read Sandbox position quantity")
            return quantity
    return 0.0


def _wait_for_execution(sandbox, account_id: str, order_id: str, expected: int) -> int:
    for attempt in range(1, 11):
        state = sandbox.get_sandbox_order_state(
            account_id=account_id,
            order_id=order_id,
        )
        executed = int(getattr(state, "lots_executed", 0) or 0)
        print(f"Order status check {attempt}: executed_lots={executed}")
        if executed >= expected:
            return executed
        time.sleep(2)
    return 0


def main() -> None:
    token = (os.getenv("INVEST_TOKEN") or os.getenv("TINKOFF_TOKEN") or "").strip()
    if not token:
        raise RuntimeError("INVEST_TOKEN/TINKOFF_TOKEN is required")

    ticker = os.getenv("SANDBOX_TEST_TICKER", "BBG004730N88").strip()
    configured_account = os.getenv("SANDBOX_ACCOUNT_ID", "").strip() or None
    expected_quantity = int(os.getenv("SANDBOX_SELL_QUANTITY", "2"))

    if expected_quantity <= 0:
        raise ValueError("SANDBOX_SELL_QUANTITY must be positive")

    print("Sandbox SELL test: starting")
    print(f"Instrument: {ticker}")
    print(f"Requested SELL quantity: {expected_quantity}")

    market = TBankMarketData(token, history_days=1)
    quote = market.get_quote(ticker)
    print("Market data: OK")
    print(f"Current price: {quote.price}")

    from t_tech.invest import Client

    execution = SandboxExecution(token)

    with Client(token) as client:
        sandbox = client.sandbox
        account_id = _resolve_account(sandbox, configured_account)
        current_quantity = _get_position(sandbox, account_id, ticker)
        print(f"Account ID: {account_id}")
        print(f"Current Sandbox position: {current_quantity}")

        if current_quantity != expected_quantity:
            raise RuntimeError(
                f"Safety check failed: expected position {expected_quantity}, "
                f"but Sandbox reports {current_quantity}. No SELL submitted."
            )

    order = OrderRequest(
        ticker=ticker,
        side="SELL",
        quantity=expected_quantity,
        price=quote.price,
    )

    result = execution.execute(order)
    order_id = result.get("order_id")
    if not order_id:
        raise RuntimeError("Sandbox SELL was submitted without an order_id")

    print("Sandbox SELL submission: OK")
    print(f"Order ID: {order_id}")
    print(f"Account ID: {account_id}")
    print(f"Status: {result.get('status')}")

    with Client(token) as client:
        sandbox = client.sandbox
        executed = _wait_for_execution(
            sandbox,
            account_id,
            order_id,
            expected_quantity,
        )
        if executed != expected_quantity:
            raise RuntimeError(
                f"SELL order did not fully execute: expected {expected_quantity}, "
                f"executed {executed}"
            )

        final_quantity = _get_position(sandbox, account_id, ticker)
        print(f"Final Sandbox position: {final_quantity}")

        if final_quantity != 0:
            raise RuntimeError(
                f"SELL executed, but final Sandbox position is {final_quantity}; "
                "expected 0."
            )

    print("Sandbox SELL test: completed successfully")
    print("BUY -> FILLED -> position 2 -> SELL 2 -> FILLED -> position 0")


if __name__ == "__main__":
    main()
