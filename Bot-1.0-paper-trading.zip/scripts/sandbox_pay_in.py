from __future__ import annotations

import os

from t_tech.invest import Client
from t_tech.invest.grpc.common import MoneyValue


def money_value(value) -> float:
    units = getattr(value, "units", 0) or 0
    nano = getattr(value, "nano", 0) or 0
    return float(units) + float(nano) / 1_000_000_000


def resolve_account(client, account_id: str | None) -> str:
    if account_id:
        return account_id

    accounts = client.sandbox.get_sandbox_accounts().accounts
    if accounts:
        return accounts[0].id

    created = client.sandbox.open_sandbox_account()
    return created.account_id


def main() -> None:
    token = (os.getenv("INVEST_TOKEN") or os.getenv("TINKOFF_TOKEN") or "").strip()
    if not token:
        raise RuntimeError("INVEST_TOKEN/TINKOFF_TOKEN is required")

    amount = float(os.getenv("SANDBOX_PAYIN_AMOUNT", "10000"))
    if amount <= 0:
        raise ValueError("SANDBOX_PAYIN_AMOUNT must be positive")

    account_id = os.getenv("SANDBOX_ACCOUNT_ID")

    with Client(token) as client:
        sandbox = client.sandbox
        account_id = resolve_account(client, account_id)

        print(f"Sandbox account: {account_id}")
        print(f"Paying in: {amount:.2f} RUB")

        response = sandbox.sandbox_pay_in(
            account_id=account_id,
            amount=MoneyValue(
                currency="RUB",
                units=int(amount),
                nano=int(round((amount - int(amount)) * 1_000_000_000)),
            ),
        )
        balance = money_value(response.balance)

        print("Sandbox pay-in: OK")
        print(f"Current sandbox balance: {balance:.2f} RUB")


if __name__ == "__main__":
    main()
