from __future__ import annotations

import os
import time

from bot.sandbox_execution import SandboxExecution


def _money_value(value) -> float | None:
    if value is None:
        return None
    units = getattr(value, "units", None)
    nano = getattr(value, "nano", None)
    if units is None and nano is None:
        return None
    return float(units or 0) + float(nano or 0) / 1_000_000_000


def _quantity_value(position) -> float | None:
    for field_name in ("quantity", "quantity_lots", "balance"):
        value = getattr(position, field_name, None)
        if isinstance(value, (int, float)):
            return float(value)
        result = _money_value(value)
        if result is not None:
            return result
    return None


def _resolve_account(sandbox, account_id: str | None) -> str:
    if account_id:
        return account_id
    accounts = sandbox.get_sandbox_accounts()
    items = getattr(accounts, "accounts", None) or []
    if not items:
        raise RuntimeError("No Sandbox account exists")
    return items[0].id


def _print_order_state(state) -> int:
    status = getattr(state, "execution_report_status", None)
    requested = int(getattr(state, "lots_requested", 0) or 0)
    executed = int(getattr(state, "lots_executed", 0) or 0)
    print(f"Execution report status: {status}")
    print(f"Requested lots: {requested}")
    print(f"Executed lots: {executed}")
    print(f"Initial order price: {_money_value(getattr(state, 'initial_order_price', None))}")
    print(f"Executed order price: {_money_value(getattr(state, 'executed_order_price', None))}")
    print(f"Direction: {getattr(state, 'direction', None)}")
    print(f"Order type: {getattr(state, 'order_type', None)}")
    return executed


def _get_position(sandbox, account_id: str, ticker: str) -> float:
    positions = sandbox.get_sandbox_positions(account_id=account_id)
    items = getattr(positions, "securities", None) or getattr(positions, "positions", None) or []
    for position in items:
        if getattr(position, "figi", "") == ticker:
            quantity = _quantity_value(position)
            if quantity is None:
                raise RuntimeError("Could not read Sandbox position quantity")
            return quantity
    return 0.0


def main() -> None:
    token = (os.getenv("INVEST_TOKEN") or os.getenv("TINKOFF_TOKEN") or "").strip()
    if not token:
        raise RuntimeError("INVEST_TOKEN/TINKOFF_TOKEN is required")

    ticker = os.getenv("SANDBOX_TEST_TICKER", "BBG004730N88").strip()
    order_id = os.getenv(
        "SANDBOX_ORDER_ID",
        "b4126032-89ce-4b4a-9e7c-4be3e82c4680",
    ).strip()
    configured_account = os.getenv("SANDBOX_ACCOUNT_ID", "").strip() or None
    checks = int(os.getenv("SANDBOX_STATUS_CHECKS", "30"))
    interval = float(os.getenv("SANDBOX_STATUS_INTERVAL", "2"))

    from t_tech.invest import Client

    print("Sandbox existing SELL order check: starting")
    print(f"Instrument: {ticker}")
    print(f"Order ID: {order_id}")

    with Client(token) as client:
        sandbox = client.sandbox
        account_id = _resolve_account(sandbox, configured_account)
        print(f"Account ID: {account_id}")

        for attempt in range(1, checks + 1):
            state = sandbox.get_sandbox_order_state(
                account_id=account_id,
                order_id=order_id,
            )
            print(f"Status check {attempt}/{checks}:")
            executed = _print_order_state(state)

            if executed > 0:
                break

            if attempt < checks:
                time.sleep(interval)

        final_position = _get_position(sandbox, account_id, ticker)
        print(f"Current Sandbox position: {final_position}")

    print("Sandbox existing SELL order check: completed")


if __name__ == "__main__":
    main()
