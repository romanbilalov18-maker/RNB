from __future__ import annotations

import os

from bot.market import TBankMarketData
from bot.models import OrderRequest
from bot.sandbox_execution import SandboxExecution


def _money_value(value) -> float | None:
    if value is None:
        return None
    units = getattr(value, "units", None)
    nano = getattr(value, "nano", None)
    if units is None and nano is None:
        return None
    return float(units or 0) + float(nano or 0) / 1_000_000_000


def _print_balance(portfolio, required_amount: float) -> bool:
    print("Sandbox portfolio: OK")

    currencies = _money_value(getattr(portfolio, "total_amount_currencies", None))
    shares = _money_value(getattr(portfolio, "total_amount_shares", None))
    bonds = _money_value(getattr(portfolio, "total_amount_bonds", None))
    etfs = _money_value(getattr(portfolio, "total_amount_etf", None))

    if currencies is not None:
        print(f"Available currency value: {currencies:.2f}")
    if shares is not None:
        print(f"Shares value: {shares:.2f}")
    if bonds is not None:
        print(f"Bonds value: {bonds:.2f}")
    if etfs is not None:
        print(f"ETF value: {etfs:.2f}")

    print(f"Estimated order amount: {required_amount:.2f}")

    if currencies is not None and currencies < required_amount:
        print("Sandbox balance is insufficient for this test order.")
        print("No order will be submitted.")
        return False

    print("Sandbox balance check: sufficient")
    return True


def _get_sandbox_portfolio(sandbox, account_id: str):
    # SDK 1.51.0 keeps the Sandbox-specific portfolio method on SandboxService.
    # The generic get_portfolio method belongs to the regular operations service.
    getter = getattr(sandbox, "get_sandbox_portfolio", None)
    if getter is None:
        raise RuntimeError(
            "T-Bank SDK does not expose get_sandbox_portfolio on SandboxService"
        )
    return getter(account_id=account_id)


def main() -> None:
    token = (os.getenv("INVEST_TOKEN") or os.getenv("TINKOFF_TOKEN") or "").strip()
    if not token:
        raise RuntimeError("INVEST_TOKEN/TINKOFF_TOKEN is required")

    ticker = os.getenv("SANDBOX_TEST_TICKER", "BBG004730N88").strip()
    quantity = int(os.getenv("SANDBOX_TEST_QUANTITY", "1"))

    if quantity <= 0:
        raise ValueError("SANDBOX_TEST_QUANTITY must be positive")

    print("Sandbox account check: starting")
    print(f"Instrument: {ticker}")
    print(f"Quantity: {quantity}")

    market = TBankMarketData(token, history_days=1)
    quote = market.get_quote(ticker)

    print("Market data: OK")
    print(f"Current price: {quote.price}")

    order = OrderRequest(
        ticker=ticker,
        side="BUY",
        quantity=quantity,
        price=quote.price,
    )

    execution = SandboxExecution(token)

    from t_tech.invest import Client

    with Client(token) as client:
        sandbox = client.sandbox
        account_id = execution._resolve_account_id(sandbox)
        portfolio = _get_sandbox_portfolio(sandbox, account_id)

    if not _print_balance(portfolio, quote.price * quantity):
        return

    result = execution.execute(order)

    print("Sandbox order submission: OK")
    print(f"Order ID: {result.get('order_id')}")
    print(f"Account ID: {result.get('account_id')}")
    print(f"Execution report status: {result.get('execution_report_status')}")
    print(f"Status: {result.get('status')}")


if __name__ == "__main__":
    main()
