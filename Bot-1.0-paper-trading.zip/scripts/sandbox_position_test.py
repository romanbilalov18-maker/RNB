from __future__ import annotations

import os

from bot.sandbox_execution import SandboxExecution


def _money_value(value) -> float | None:
    if value is None:
        return None
    units = getattr(value, "units", None)
    nano = getattr(value, "nano", None)
    if units is None and nano is None:
        return None
    return float(units or 0) + float(nano or 0) / 1_000_000_000


def _quantity_value(position) -> float | None:
    """Read the position quantity across SDK response variants."""
    for field_name in ("quantity", "quantity_lots", "balance"):
        value = getattr(position, field_name, None)
        if isinstance(value, (int, float)):
            return float(value)

        result = _money_value(value)
        if result is not None:
            return result
    return None


def _resolve_account(sandbox, account_id: str | None) -> str:
    if account_id:
        return account_id
    accounts = sandbox.get_sandbox_accounts()
    items = getattr(accounts, "accounts", None) or []
    if not items:
        opened = sandbox.open_sandbox_account()
        return opened.account_id
    return items[0].id


def _print_order_state(order_state) -> None:
    print("Sandbox order state: OK")
    print(f"Execution report status: {getattr(order_state, 'execution_report_status', None)}")
    print(f"Order type: {getattr(order_state, 'order_type', None)}")
    print(f"Direction: {getattr(order_state, 'direction', None)}")
    print(f"Requested lots: {getattr(order_state, 'lots_requested', None)}")
    print(f"Executed lots: {getattr(order_state, 'lots_executed', None)}")
    print(f"Initial order price: {_money_value(getattr(order_state, 'initial_order_price', None))}")
    print(f"Executed order price: {_money_value(getattr(order_state, 'executed_order_price', None))}")


def _print_positions(positions, ticker: str) -> None:
    items = getattr(positions, "securities", None) or getattr(positions, "positions", None) or []
    print(f"Sandbox positions: {len(items)}")

    matched = [position for position in items if getattr(position, "figi", "") == ticker]

    if not matched:
        print(f"Position for {ticker}: NOT FOUND")
        return

    for position in matched:
        quantity = _quantity_value(position)
        print(f"Position {ticker}: quantity={quantity}")

        # Keep this diagnostic visible if the SDK response uses an unexpected
        # field layout. It does not alter the position or place any order.
        if quantity is None:
            field_names = []
            descriptor = getattr(position, "DESCRIPTOR", None)
            if descriptor is not None:
                field_names = [field.name for field in descriptor.fields]
            else:
                field_names = [
                    name for name in ("quantity", "quantity_lots", "balance")
                    if hasattr(position, name)
                ]
            print(f"Position response fields: {field_names}")
            print(f"Position balance raw value: {getattr(position, 'balance', None)!r}")


def main() -> None:
    token = (os.getenv("INVEST_TOKEN") or os.getenv("TINKOFF_TOKEN") or "").strip()
    if not token:
        raise RuntimeError("INVEST_TOKEN/TINKOFF_TOKEN is required")

    ticker = os.getenv("SANDBOX_TEST_TICKER", "BBG004730N88").strip()
    order_id = os.getenv(
        "SANDBOX_ORDER_ID",
        "5367d983-9b71-4dbf-9142-e62b37a2f691",
    ).strip()
    configured_account = os.getenv("SANDBOX_ACCOUNT_ID", "").strip() or None

    print("Sandbox position/status check: starting")
    print(f"Instrument: {ticker}")
    print(f"Order ID: {order_id}")

    from t_tech.invest import Client

    with Client(token) as client:
        sandbox = client.sandbox
        account_id = _resolve_account(sandbox, configured_account)
        print(f"Account ID: {account_id}")

        order_state = sandbox.get_sandbox_order_state(
            account_id=account_id,
            order_id=order_id,
        )
        _print_order_state(order_state)

        positions = sandbox.get_sandbox_positions(account_id=account_id)
        _print_positions(positions, ticker)

    print("Sandbox position/status check: completed")


if __name__ == "__main__":
    main()
