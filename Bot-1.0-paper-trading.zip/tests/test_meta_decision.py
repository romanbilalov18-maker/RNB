import unittest

from bot.meta_decision import DecisionInput, MetaDecisionEngine
from bot.models import SignalResult


def signal(name, value, confidence):
    return DecisionInput(
        source=name,
        result=SignalResult(
            ticker="TEST",
            signal=value,
            confidence=confidence,
            reason=f"{name} reason",
        ),
    )


class TestMetaDecisionEngine(unittest.TestCase):
    def test_buy_consensus(self):
        result = MetaDecisionEngine().decide(
            [
                signal("strategy", "BUY", 0.8),
                signal("model", "BUY", 0.6),
                signal("regime", "SELL", 0.9),
            ]
        )
        self.assertEqual(result.signal, "BUY")
        self.assertAlmostEqual(result.confidence, 0.7)
        self.assertEqual(result.contributors, ("strategy", "model"))

    def test_weighted_consensus(self):
        inputs = (
            DecisionInput(
                source="strategy",
                result=SignalResult("TEST", "BUY", 0.8, "trend"),
                weight=2.0,
            ),
            DecisionInput(
                source="model",
                result=SignalResult("TEST", "SELL", 0.9, "model"),
                weight=1.0,
            ),
        )
        result = MetaDecisionEngine().decide(inputs)
        self.assertEqual(result.signal, "BUY")
        self.assertAlmostEqual(result.confidence, 0.8)

    def test_low_confidence_becomes_hold(self):
        result = MetaDecisionEngine(min_confidence=0.8).decide(
            [signal("model", "BUY", 0.6)]
        )
        self.assertEqual(result.signal, "HOLD")
        self.assertEqual(result.confidence, 0.6)

    def test_tie_becomes_hold(self):
        result = MetaDecisionEngine().decide(
            [
                signal("a", "BUY", 0.9),
                signal("b", "SELL", 0.9),
            ]
        )
        self.assertEqual(result.signal, "HOLD")
        self.assertEqual(result.confidence, 0.0)

    def test_empty_inputs_are_rejected(self):
        with self.assertRaises(ValueError):
            MetaDecisionEngine().decide([])

    def test_invalid_weight_is_rejected(self):
        with self.assertRaises(ValueError):
            MetaDecisionEngine().decide(
                [DecisionInput(
                    source="bad",
                    result=SignalResult("TEST", "BUY", 0.8, "x"),
                    weight=0,
                )]
            )

    def test_invalid_source_is_rejected(self):
        with self.assertRaises(ValueError):
            MetaDecisionEngine().decide(
                [DecisionInput(
                    source="",
                    result=SignalResult("TEST", "BUY", 0.8, "x"),
                )]
            )

    def test_it_does_not_execute_orders(self):
        result = MetaDecisionEngine().decide([signal("strategy", "SELL", 0.9)])
        self.assertEqual(result.signal, "SELL")
        self.assertEqual(result.contributors, ("strategy",))


if __name__ == "__main__":
    unittest.main()
