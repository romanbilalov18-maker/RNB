import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path

from bot.evaluation import ModelEvaluation
from bot.model_registry import ModelApprovalPolicy, ModelRegistry
from bot.training import TrainingEngine, TrainingResult, TrainingSample
from bot.walk_forward import WalkForwardFold, WalkForwardResult


class TestModelRegistry(unittest.TestCase):
    def _training_result(self) -> TrainingResult:
        samples = (
            TrainingSample(datetime(2026, 1, 1, tzinfo=timezone.utc), (1.0,), 0),
            TrainingSample(datetime(2026, 1, 2, tzinfo=timezone.utc), (2.0,), 1),
            TrainingSample(datetime(2026, 1, 3, tzinfo=timezone.utc), (3.0,), 0),
            TrainingSample(datetime(2026, 1, 4, tzinfo=timezone.utc), (4.0,), 1),
        )
        model = TrainingEngine().fit_samples(samples)
        return TrainingResult(
            model=model,
            feature_names=("feature",),
            train_samples=samples[:2],
            validation_samples=samples[2:],
            target_definition="test target",
        )

    def _walk_forward(self) -> WalkForwardResult:
        evaluation = ModelEvaluation(
            sample_count=2,
            accuracy=0.75,
            precision=0.75,
            recall=0.75,
            f1=0.75,
            roc_auc=0.75,
            actual_positive_rate=0.5,
            predicted_positive_rate=0.5,
        )
        fold = WalkForwardFold(
            train_start=datetime(2026, 1, 1, tzinfo=timezone.utc),
            train_end=datetime(2026, 1, 2, tzinfo=timezone.utc),
            validation_start=datetime(2026, 1, 3, tzinfo=timezone.utc),
            validation_end=datetime(2026, 1, 4, tzinfo=timezone.utc),
            train_size=2,
            validation_size=2,
            evaluation=evaluation,
        )
        return WalkForwardResult(folds=(fold,))

    def test_approve_training_runs_validation_and_walk_forward(self):
        training = self._training_result()
        registry = ModelRegistry(
            ModelApprovalPolicy(
                min_validation_accuracy=0.0,
                min_validation_f1=0.0,
                min_walk_forward_accuracy=0.0,
                min_walk_forward_f1=0.0,
                min_walk_forward_folds=1,
            )
        )
        approval = registry.approve_training(
            training,
            train_size=2,
            validation_size=1,
            step_size=1,
        )
        self.assertTrue(approval.approved)
        self.assertGreaterEqual(approval.walk_forward_folds, 1)

    def test_model_is_approved_only_after_all_gates_pass(self):
        training = self._training_result()
        validation = ModelEvaluation(
            sample_count=training.validation_size,
            accuracy=0.75,
            precision=0.75,
            recall=0.75,
            f1=0.75,
            roc_auc=0.75,
            actual_positive_rate=0.5,
            predicted_positive_rate=0.5,
        )
        registry = ModelRegistry(
            ModelApprovalPolicy(
                min_validation_accuracy=0.70,
                min_validation_f1=0.70,
                min_walk_forward_accuracy=0.70,
                min_walk_forward_f1=0.70,
            )
        )

        approval = registry.evaluate_approval(
            training,
            validation,
            self._walk_forward(),
        )

        self.assertTrue(approval.approved)

    def test_target_definition_can_be_required_when_loading(self):
        training = self._training_result()
        validation = ModelEvaluation(
            sample_count=training.validation_size,
            accuracy=0.75, precision=0.75, recall=0.75, f1=0.75, roc_auc=0.75,
            actual_positive_rate=0.5, predicted_positive_rate=0.5,
        )
        registry = ModelRegistry()
        approval = registry.evaluate_approval(training, validation, self._walk_forward())
        training = TrainingResult(
            model=training.model,
            feature_names=training.feature_names,
            train_samples=training.train_samples,
            validation_samples=training.validation_samples,
            target_definition="1 if the completed trade outcome is WIN, else 0; BREAKEVEN excluded",
        )

        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "outcome.pkl"
            registry.save_approved(training, approval, path)
            loaded = registry.load_approved(
                path,
                expected_target_definition="1 if the completed trade outcome is WIN, else 0; BREAKEVEN excluded",
            )
            self.assertEqual(loaded.target_definition, training.target_definition)
            with self.assertRaises(ValueError):
                registry.load_approved(path, expected_target_definition="direction")

    def test_failed_model_cannot_be_saved(self):
        training = self._training_result()
        validation = ModelEvaluation(
            sample_count=training.validation_size,
            accuracy=0.40,
            precision=0.40,
            recall=0.40,
            f1=0.40,
            roc_auc=0.40,
            actual_positive_rate=0.5,
            predicted_positive_rate=0.5,
        )
        registry = ModelRegistry(
            ModelApprovalPolicy(
                min_validation_accuracy=0.70,
                min_validation_f1=0.70,
                min_walk_forward_accuracy=0.70,
                min_walk_forward_f1=0.70,
            )
        )
        approval = registry.evaluate_approval(training, validation, self._walk_forward())

        self.assertFalse(approval.approved)
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(ValueError):
                registry.save_approved(
                    training,
                    approval,
                    Path(directory) / "approved.pkl",
                )

    def test_approved_artifact_round_trip(self):
        training = self._training_result()
        validation = ModelEvaluation(
            sample_count=training.validation_size,
            accuracy=0.75,
            precision=0.75,
            recall=0.75,
            f1=0.75,
            roc_auc=0.75,
            actual_positive_rate=0.5,
            predicted_positive_rate=0.5,
        )
        registry = ModelRegistry()
        approval = registry.evaluate_approval(training, validation, self._walk_forward())

        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "approved.pkl"
            registry.save_approved(training, approval, path)
            artifact = registry.load_approved(path)

            self.assertTrue(artifact.approval.approved)
            self.assertEqual(artifact.feature_names, training.feature_names)
            self.assertEqual(
                artifact.model.predict([[1.0]]).tolist(),
                training.model.predict([[1.0]]).tolist(),
            )


if __name__ == "__main__":
    unittest.main()
