import unittest
from types import SimpleNamespace

from bot.sandbox_reconciliation import SandboxOrderReconciler, normalize_order_status


class FakeSandbox:
    def __init__(self, states, positions=None):
        self.states = list(states)
        self.positions = positions or []
        self.calls = 0

    def get_sandbox_order_state(self, account_id, order_id):
        self.calls += 1
        index = min(self.calls - 1, len(self.states) - 1)
        return self.states[index]

    def get_sandbox_positions(self, account_id):
        return SimpleNamespace(securities=self.positions)


class TestSandboxOrderReconciler(unittest.TestCase):
    def test_normalizes_sdk_statuses(self):
        self.assertEqual(normalize_order_status("EXECUTION_REPORT_STATUS_NEW"), "ACTIVE")
        self.assertEqual(normalize_order_status("EXECUTION_REPORT_STATUS_PARTIALLYFILL", 1), "PARTIALLY_FILLED")
        self.assertEqual(normalize_order_status("EXECUTION_REPORT_STATUS_FILL", 1), "FILLED")
        self.assertEqual(normalize_order_status("EXECUTION_REPORT_STATUS_CANCELLED"), "CANCELLED")
        self.assertEqual(normalize_order_status("EXECUTION_REPORT_STATUS_REJECTED"), "REJECTED")

    def test_reads_filled_order(self):
        sandbox = FakeSandbox([
            SimpleNamespace(
                execution_report_status="EXECUTION_REPORT_STATUS_FILL",
                lots_requested=2,
                lots_executed=2,
                initial_order_price=SimpleNamespace(units=278, nano=500000000),
                executed_order_price=SimpleNamespace(units=278, nano=600000000),
                direction="BUY",
                order_type="LIMIT",
            )
        ])
        reconciler = SandboxOrderReconciler(sandbox, "account")
        result = reconciler.reconcile("order", "FIGI")
        self.assertEqual(result["status"], "FILLED")
        self.assertEqual(result["executed_quantity"], 2)
        self.assertEqual(result["executed_price"], 278.6)
        self.assertEqual(result["position_quantity"], 0.0)

    def test_waits_until_filled(self):
        sandbox = FakeSandbox([
            SimpleNamespace(execution_report_status="EXECUTION_REPORT_STATUS_NEW", lots_requested=1, lots_executed=0),
            SimpleNamespace(execution_report_status="EXECUTION_REPORT_STATUS_FILL", lots_requested=1, lots_executed=1),
        ])
        delays = []
        reconciler = SandboxOrderReconciler(sandbox, "account", sleep_fn=delays.append)
        result = reconciler.wait_for_completion("order", timeout_seconds=4, poll_interval_seconds=2)
        self.assertEqual(result["status"], "FILLED")
        self.assertEqual(sandbox.calls, 2)
        self.assertEqual(delays, [2])

    def test_reads_scalar_position_balance(self):
        position = SimpleNamespace(figi="FIGI", balance=2)
        sandbox = FakeSandbox([], positions=[position])
        reconciler = SandboxOrderReconciler(sandbox, "account")
        self.assertEqual(reconciler.get_position("FIGI"), 2.0)

    def test_returns_zero_when_position_missing(self):
        sandbox = FakeSandbox([], positions=[])
        reconciler = SandboxOrderReconciler(sandbox, "account")
        self.assertEqual(reconciler.get_position("FIGI"), 0.0)


if __name__ == "__main__":
    unittest.main()
