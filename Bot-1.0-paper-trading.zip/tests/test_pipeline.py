import unittest
from datetime import datetime, timedelta, timezone

from bot.dataset import Dataset
from bot.features import FeatureEngine
from bot.market_regime import MarketRegime, MarketRegimeEngine
from bot.models import DecisionContext, HistoricalCandle, MarketQuote
from bot.training import TrainingEngine
from bot.pipeline import TradingDecisionPipeline
from bot.strategy import Strategy


class TestTradingDecisionPipeline(unittest.TestCase):
    def _context(self, closes):
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        candles = tuple(
            HistoricalCandle(
                ticker="TEST",
                timestamp=base + timedelta(minutes=index),
                open=close - 0.2,
                high=close + 0.5,
                low=close - 0.5,
                close=close,
                volume=100 + index,
            )
            for index, close in enumerate(closes)
        )
        return DecisionContext(
            ticker="TEST",
            price=closes[-1] if closes else 100.0,
            timestamp=candles[-1].timestamp if candles else base,
            candles=candles,
        )

    def test_pipeline_connects_regime_strategies_and_meta(self):
        pipeline = TradingDecisionPipeline("TEST")
        result = pipeline.decide(
            self._context([100 + index * 0.8 for index in range(30)])
        )
        self.assertEqual(len(result.strategies), 2)
        self.assertIsNotNone(result.regime)
        self.assertIn(result.meta.signal, {"BUY", "SELL", "HOLD"})

    def test_non_trend_regime_gates_directional_signal(self):
        pipeline = TradingDecisionPipeline(
            "TEST",
            regime_engine=MarketRegimeEngine(
                volatility_period=5,
                trend_period=5,
                high_volatility_threshold=1.0,
                low_volatility_threshold=0.000001,
                trend_threshold=0.5,
            ),
        )
        result = pipeline.decide(self._context([100, 101, 99, 100, 101, 99] * 5))
        self.assertEqual(result.regime.regime, MarketRegime.RANGE)
        self.assertEqual(result.meta.signal, "HOLD")

    def test_low_volatility_directional_move_can_be_trend(self):
        engine = MarketRegimeEngine(
            volatility_period=5,
            trend_period=5,
            high_volatility_threshold=1.0,
            low_volatility_threshold=0.01,
            trend_threshold=0.5,
        )
        result = engine.classify_closes([100, 100.1, 100.2, 100.3, 100.4, 100.5])
        self.assertEqual(result.regime, MarketRegime.TREND)

    def test_persistent_sma_direction_can_reach_meta(self):
        pipeline = TradingDecisionPipeline("TEST")
        result = pipeline.decide(self._context([100 + index * 0.8 for index in range(40)]))
        self.assertIn(result.regime.regime, {MarketRegime.TREND, MarketRegime.LOW_VOLATILITY})
        self.assertIn(result.meta.signal, {"BUY", "HOLD"})

    def test_trained_model_is_added_to_meta_decision(self):
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        close = 100.0
        candles = []
        for index in range(80):
            close += 1.0 if index % 2 == 0 else -0.7
            candles.append(
                HistoricalCandle(
                    ticker="TEST",
                    timestamp=base + timedelta(minutes=index),
                    open=close - 0.2,
                    high=close + 0.5,
                    low=close - 0.5,
                    close=close,
                    volume=100 + index,
                )
            )
        dataset = Dataset.from_candles(candles)
        features = FeatureEngine(
            fast_period=3, slow_period=5, rsi_period=3,
            volatility_period=5, momentum_period=3,
            atr_period=3, volume_period=5,
        )
        TrainingEngine(feature_engine=features).train(dataset)

        class AlwaysBuyModel:
            classes_ = [0, 1]

            def predict_proba(self, values):
                return [[0.01, 0.99] for _ in values]

            def predict(self, values):
                return [1 for _ in values]

        pipeline = TradingDecisionPipeline(
            "TEST",
            model=AlwaysBuyModel(),
            feature_engine=features,
            model_weight=3.0,
        )
        context = DecisionContext(
            ticker="TEST",
            price=dataset.candles[-1].close,
            timestamp=dataset.candles[-1].timestamp,
            candles=dataset.candles,
        )
        result = pipeline.decide(context)
        self.assertIsNotNone(result.model)
        self.assertIn("trained_model", result.meta.contributors)

    def test_outcome_model_gates_meta_direction_without_creating_direction(self):
        class AlwaysWinOutcomeModel:
            classes_ = [0, 1]

            def predict_proba(self, values):
                return [[0.01, 0.99] for _ in values]

            def predict(self, values):
                return [1 for _ in values]

        pipeline = TradingDecisionPipeline(
            "TEST",
            outcome_model=AlwaysWinOutcomeModel(),
            outcome_min_win_probability=0.8,
        )
        result = pipeline.decide(self._context([100 + index * 0.8 for index in range(40)]))
        self.assertIsNotNone(result.outcome)
        self.assertIn(result.meta.signal, {"BUY", "SELL", "HOLD"})

    def test_outcome_model_can_block_meta_direction(self):
        class AlwaysLossOutcomeModel:
            classes_ = [0, 1]

            def predict_proba(self, values):
                return [[0.99, 0.01] for _ in values]

            def predict(self, values):
                return [0 for _ in values]

        pipeline = TradingDecisionPipeline(
            "TEST",
            outcome_model=AlwaysLossOutcomeModel(),
            outcome_min_win_probability=0.5,
        )
        result = pipeline.decide(self._context([100 + index * 0.8 for index in range(40)]))
        self.assertEqual(result.meta.signal, "HOLD")
        self.assertNotEqual(result.meta.signal, "BUY")
        self.assertNotEqual(result.meta.signal, "SELL")

    def test_wrong_ticker_is_rejected(self):
        pipeline = TradingDecisionPipeline("TEST")
        with self.assertRaises(ValueError):
            pipeline.decide(DecisionContext(
                ticker="OTHER",
                price=102,
                timestamp=datetime.now(timezone.utc),
                candles=(HistoricalCandle("OTHER", datetime.now(timezone.utc), 101, 103, 100, 102, 100),),
            ))

    def test_empty_history_is_rejected(self):
        pipeline = TradingDecisionPipeline("TEST")
        with self.assertRaises(ValueError):
            pipeline.decide(self._context([]))


    def test_from_quote_rejects_mismatched_closes(self):
        context = self._context([100, 101, 102])
        quote = MarketQuote(
            ticker=context.ticker,
            price=context.price,
            timestamp=context.timestamp,
            closes=(100, 101, 999),
            candles=context.candles,
        )
        with self.assertRaises(ValueError):
            DecisionContext.from_quote(quote)

    def test_from_quote_rejects_mixed_candle_ticker(self):
        context = self._context([100, 101, 102])
        candles = list(context.candles)
        candles[-1] = HistoricalCandle(
            ticker="OTHER",
            timestamp=candles[-1].timestamp,
            open=candles[-1].open,
            high=candles[-1].high,
            low=candles[-1].low,
            close=candles[-1].close,
            volume=candles[-1].volume,
        )
        quote = __import__("bot.models", fromlist=["MarketQuote"]).MarketQuote(
            ticker="TEST",
            price=context.price,
            timestamp=context.timestamp,
            candles=tuple(candles),
        )
        with self.assertRaises(ValueError):
            DecisionContext.from_quote(quote)

    def test_context_derives_closes_from_candles(self):
        context = self._context([100, 101, 102])
        self.assertEqual(context.closes, (100, 101, 102))
        self.assertEqual(len(context.candles), len(context.closes))

    def test_strategy_accepts_the_shared_decision_context(self):
        context = self._context([100 + index for index in range(25)])
        result = Strategy(5, 20).evaluate(context)
        self.assertEqual(result.ticker, context.ticker)

    def test_model_receives_the_shared_decision_context(self):
        received = []

        class RecordingModel:
            classes_ = [0, 1]

            def predict_proba(self, values):
                received.append(values)
                return [[0.1, 0.9] for _ in values]

            def predict(self, values):
                return [1 for _ in values]

        pipeline = TradingDecisionPipeline("TEST", model=RecordingModel())
        context = self._context([100 + index * 0.5 for index in range(40)])
        pipeline.decide(context)
        self.assertEqual(len(received), 1)


if __name__ == "__main__":
    unittest.main()
