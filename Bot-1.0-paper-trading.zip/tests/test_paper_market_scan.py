import unittest
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

from bot.models import HistoricalCandle, MarketQuote
from bot.paper_scan import rank_paper_candidates


class PaperMarketScanTests(unittest.TestCase):
    def quote(self, ticker, volume, *, timestamp=None, count=30):
        now = timestamp or datetime.now(timezone.utc)
        candles = tuple(
            HistoricalCandle(
                ticker=ticker,
                timestamp=now - timedelta(minutes=count - index),
                open=100,
                high=101,
                low=99,
                close=100,
                volume=volume,
            )
            for index in range(count)
        )
        return MarketQuote(
            ticker=ticker,
            price=100,
            timestamp=now,
            closes=tuple(100 for _ in candles),
            candles=candles,
            lot_size=1,
        )

    def instrument(self, ticker, *, currency="RUB", asset_type="share", tradable=True):
        return SimpleNamespace(
            ticker=ticker,
            figi=ticker,
            instrument_id=ticker,
            currency=currency,
            asset_type=asset_type,
            tradable=tradable,
            buy_available=tradable,
            sell_available=tradable,
        )

    def test_selects_ten_most_liquid_candidates(self):
        instruments = [self.instrument(f"T{i:02}") for i in range(12)]
        quotes = {f"T{i:02}": self.quote(f"T{i:02}", i + 1) for i in range(12)}
        selected = rank_paper_candidates(instruments, quotes, max_candidates=10)
        self.assertEqual(len(selected), 10)
        self.assertEqual([item.instrument.ticker for item in selected], [
            "T11", "T10", "T09", "T08", "T07", "T06", "T05", "T04", "T03", "T02"
        ])

    def test_excludes_non_rub_non_share_stale_and_short_history(self):
        now = datetime.now(timezone.utc)
        instruments = [
            self.instrument("USD", currency="USD"),
            self.instrument("ETF", asset_type="etf"),
            self.instrument("STALE"),
            self.instrument("SHORT"),
            self.instrument("GOOD"),
        ]
        quotes = {
            "USD": self.quote("USD", 500),
            "ETF": self.quote("ETF", 500),
            "STALE": self.quote("STALE", 500, timestamp=now - timedelta(minutes=10)),
            "SHORT": self.quote("SHORT", 500, count=10),
            "GOOD": self.quote("GOOD", 1),
        }
        selected = rank_paper_candidates(instruments, quotes, now=now, max_quote_age_seconds=120)
        self.assertEqual([item.instrument.ticker for item in selected], ["GOOD"])

    def test_held_position_is_kept_in_scan_even_below_liquidity_cutoff(self):
        instruments = [self.instrument("HELD")] + [
            self.instrument(f"T{i:02}") for i in range(10)
        ]
        quotes = {item.ticker: self.quote(item.ticker, 1) for item in instruments}
        quotes.update({f"T{i:02}": self.quote(f"T{i:02}", 100 + i) for i in range(10)})
        selected = rank_paper_candidates(
            instruments, quotes, held_tickers={"HELD"}, max_candidates=3
        )
        self.assertEqual(len(selected), 3)
        self.assertIn("HELD", [item.instrument.ticker for item in selected])


if __name__ == "__main__":
    unittest.main()
