import unittest
from types import SimpleNamespace

from bot.sandbox_execution import _money_to_float, _quantity_to_float


class SandboxAccountValueTests(unittest.TestCase):
    def test_money_conversion(self):
        value = SimpleNamespace(units=9998, nano=957525000)
        self.assertAlmostEqual(_money_to_float(value), 9998.957525)

    def test_quantity_conversion(self):
        value = SimpleNamespace(units=36, nano=0)
        self.assertEqual(_quantity_to_float(value), 36.0)

    def test_total_portfolio_value_is_used_for_equity(self):
        portfolio = SimpleNamespace(
            total_amount_currencies=SimpleNamespace(units=9998, nano=957525000),
            total_amount_portfolio=SimpleNamespace(units=19997, nano=915050000),
        )
        cash = _money_to_float(portfolio.total_amount_currencies)
        equity = _money_to_float(portfolio.total_amount_portfolio)
        self.assertAlmostEqual(cash, 9998.957525)
        self.assertAlmostEqual(equity, 19997.91505)
        self.assertNotAlmostEqual(equity, cash + 36 * 276.53)

    def test_missing_total_portfolio_value_is_not_silently_reconstructed(self):
        portfolio = SimpleNamespace(
            total_amount_currencies=SimpleNamespace(units=9998, nano=957525000)
        )
        self.assertIsNone(_money_to_float(getattr(portfolio, "total_amount_portfolio", None)))


if __name__ == "__main__":
    unittest.main()
