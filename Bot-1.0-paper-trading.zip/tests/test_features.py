import unittest
from datetime import datetime, timedelta, timezone

from bot.dataset import Dataset
from bot.features import FeatureEngine
from bot.models import HistoricalCandle


def make_dataset(size=30):
    base = datetime(2026, 1, 1, tzinfo=timezone.utc)
    candles = []
    for i in range(size):
        close = 100.0 + i
        candles.append(
            HistoricalCandle(
                ticker="TEST",
                timestamp=base + timedelta(minutes=i),
                open=close - 0.5,
                high=close + 1.0,
                low=close - 1.0,
                close=close,
                volume=100 + i,
            )
        )
    return Dataset.from_candles(candles)


class TestFeatureEngine(unittest.TestCase):
    def test_features_are_missing_until_enough_history_exists(self):
        dataset = make_dataset(5)
        engine = FeatureEngine(fast_period=3, slow_period=5)
        features = engine.build(dataset)
        self.assertIsNone(features[0].sma_fast)
        self.assertIsNone(features[3].sma_slow)
        self.assertIsNotNone(features[4].sma_slow)
        self.assertIsNotNone(features[4].ema_slow)

    def test_features_are_point_in_time(self):
        dataset = make_dataset(30)
        engine = FeatureEngine(
            fast_period=3, slow_period=5, rsi_period=3,
            volatility_period=5, momentum_period=3,
            atr_period=3, volume_period=5,
        )
        before = engine.compute(dataset, 20)
        changed = list(dataset.candles)
        changed[21] = HistoricalCandle(
            ticker="TEST", timestamp=changed[21].timestamp,
            open=9999, high=10000, low=9998, close=9999, volume=999999,
        )
        after = engine.compute(Dataset.from_candles(changed), 20)
        self.assertEqual(before, after)

    def test_expected_features_are_calculated(self):
        dataset = make_dataset(30)
        engine = FeatureEngine(
            fast_period=3, slow_period=5, rsi_period=3,
            volatility_period=5, momentum_period=3,
            atr_period=3, volume_period=5,
        )
        feature = engine.compute(dataset, 29)
        self.assertAlmostEqual(feature.sma_fast, (127 + 128 + 129) / 3)
        self.assertAlmostEqual(feature.sma_slow, (125 + 126 + 127 + 128 + 129) / 5)
        self.assertAlmostEqual(feature.momentum, 129 / 126 - 1)
        self.assertAlmostEqual(feature.volume_ratio, 129 / 127.0)
        self.assertIsNotNone(feature.rsi)
        self.assertIsNotNone(feature.atr)
        self.assertIsNotNone(feature.volatility)

    def test_invalid_index_rejected(self):
        dataset = make_dataset(3)
        engine = FeatureEngine()
        with self.assertRaises(IndexError):
            engine.compute(dataset, 3)


if __name__ == "__main__":
    unittest.main()
