import unittest

from bot.runner import TradingRunner


class FakeBot:
    def __init__(self):
        self.calls = 0

    def execute_signal(self):
        self.calls += 1
        return {
            "status": "NO_TRADE",
            "signal": "HOLD",
            "reason": f"cycle {self.calls}",
        }


class TestTradingRunner(unittest.TestCase):
    def test_runs_requested_cycles(self):
        bot = FakeBot()
        sleeps = []

        runner = TradingRunner(
            bot,
            interval_seconds=5,
            sleep_fn=sleeps.append,
        )

        results = runner.run(3)

        self.assertEqual(len(results), 3)
        self.assertEqual(bot.calls, 3)
        self.assertEqual(sleeps, [5, 5])
        self.assertEqual(results[0].signal, "HOLD")

    def test_invalid_cycles_rejected(self):
        with self.assertRaises(ValueError):
            TradingRunner(FakeBot()).run(0)


if __name__ == "__main__":
    unittest.main()
