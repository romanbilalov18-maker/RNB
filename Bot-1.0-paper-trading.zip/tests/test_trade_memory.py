import unittest
from datetime import datetime, timedelta, timezone

from bot.trade_memory import TradeDecision, TradeMemory, TradeResult


class TestTradeMemory(unittest.TestCase):
    def setUp(self):
        self.memory = TradeMemory()
        self.timestamp = datetime(2026, 1, 1, tzinfo=timezone.utc)
        self.decision = TradeDecision(
            timestamp=self.timestamp, ticker="TEST", signal="BUY",
            confidence=0.8, reason="test signal", quantity=10, price=100.0,
            features=(1.0, 2.0),
        )

    def test_records_decision_as_open(self):
        record = self.memory.record_decision(self.decision)
        self.assertEqual(record.outcome, "OPEN")
        self.assertEqual(len(self.memory.records()), 1)

    def test_result_classifies_win_loss_and_breakeven(self):
        self.assertEqual(TradeResult(self.timestamp, 101.0, 5.0).outcome, "WIN")
        self.assertEqual(TradeResult(self.timestamp, 99.0, -5.0).outcome, "LOSS")
        self.assertEqual(TradeResult(self.timestamp, 100.0, 0.0).outcome, "BREAKEVEN")

    def test_result_closes_open_decision(self):
        self.memory.record_decision(self.decision)
        record = self.memory.record_result(self.timestamp, TradeResult(self.timestamp, 101.0, 10.0))
        self.assertEqual(record.outcome, "WIN")
        self.assertEqual(len(self.memory.completed()), 1)
        self.assertEqual(self.memory.completed()[0].result.realized_pnl, 10.0)

    def test_error_is_preserved_for_training(self):
        self.memory.record_decision(self.decision)
        self.memory.record_result(self.timestamp, TradeResult(self.timestamp, 99.0, -10.0), error=True, error_reason="signal failed")
        self.assertEqual(len(self.memory.errors()), 1)
        self.assertEqual(len(self.memory.training_records()), 1)
        self.assertEqual(self.memory.training_records()[0].error_reason, "signal failed")

    def test_record_exit_closes_matching_buy(self):
        self.memory.record_decision(self.decision)
        record = self.memory.record_exit("TEST", 10, TradeResult(datetime(2026, 1, 1, 0, 1, tzinfo=timezone.utc), 101.0, 9.0))
        self.assertEqual(record.outcome, "WIN")
        self.assertEqual(len(self.memory.completed()), 1)

    def test_record_exit_rejects_missing_matching_buy(self):
        with self.assertRaises(KeyError):
            self.memory.record_exit("TEST", 10, TradeResult(self.timestamp, 101.0, 1.0))

    def test_invalid_decision_is_rejected(self):
        with self.assertRaises(ValueError):
            self.memory.record_decision(TradeDecision(self.timestamp, "TEST", "BUY", 1.1, "bad", 1, 100.0))

    def test_result_requires_open_decision(self):
        with self.assertRaises(KeyError):
            self.memory.record_result(self.timestamp, TradeResult(self.timestamp, 101.0, 1.0))

    def test_learning_samples_exclude_open_and_breakeven(self):
        self.memory.record_decision(self.decision)
        ts = self.timestamp + timedelta(minutes=1)
        self.memory.record_decision(TradeDecision(ts, "TEST", "BUY", 0.7, "breakeven", 10, 101.0, features=(3.0, 4.0)))
        self.memory.record_result(ts, TradeResult(ts + timedelta(minutes=1), 101.0, 0.0))
        self.assertEqual(self.memory.learning_samples(feature_count=2), ())

    def test_learning_samples_are_leakage_safe(self):
        self.memory.record_decision(self.decision)
        self.memory.record_result(self.timestamp, TradeResult(self.timestamp + timedelta(minutes=5), 90.0, -10.0), error=True, error_reason="late exit")
        sample = self.memory.learning_samples(feature_count=2)[0]
        self.assertEqual(sample.features, (1.0, 2.0))
        self.assertEqual(sample.target, 0)
        self.assertEqual(sample.outcome, "LOSS")
        self.assertEqual(sample.timestamp, self.timestamp)
        self.assertEqual(sample.signal, "BUY")
        self.assertEqual(sample.confidence, 0.8)

    def test_learning_samples_require_expected_feature_count(self):
        self.memory.record_decision(self.decision)
        self.memory.record_result(self.timestamp, TradeResult(self.timestamp + timedelta(minutes=1), 101.0, 1.0))
        with self.assertRaises(ValueError):
            self.memory.learning_samples(feature_count=3)

    def test_learning_samples_are_numeric(self):
        self.memory.record_decision(TradeDecision(self.timestamp, "TEST", "BUY", 0.8, "test", 1, 100.0, features=(1.0, "bad")))
        self.memory.record_result(self.timestamp, TradeResult(self.timestamp + timedelta(minutes=1), 101.0, 1.0))
        with self.assertRaises(ValueError):
            self.memory.learning_samples(feature_count=2)


if __name__ == "__main__":
    unittest.main()
