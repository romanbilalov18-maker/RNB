import unittest
from datetime import datetime, timedelta, timezone

from bot.backtest import BacktestEngine
from bot.dataset import Dataset
from bot.models import HistoricalCandle
from bot.pipeline import TradingDecisionPipeline
from bot.risk import RiskManager


def make_dataset(closes):
    base = datetime(2026, 1, 1, tzinfo=timezone.utc)
    candles = []
    for index, close in enumerate(closes):
        candles.append(
            HistoricalCandle(
                ticker="TEST",
                timestamp=base + timedelta(minutes=index),
                open=close - 0.5,
                high=close + 1.0,
                low=close - 1.0,
                close=close,
                volume=100,
            )
        )
    return Dataset.from_candles(candles)


def make_engine():
    return BacktestEngine(
        pipeline=TradingDecisionPipeline("TEST"),
        risk_manager=RiskManager(10),
        initial_balance=1_000,
    )


class TestBacktestEngine(unittest.TestCase):
    def test_backtest_produces_equity_curve_for_every_candle(self):
        dataset = make_dataset([100 + index for index in range(40)])
        result = make_engine().run(dataset, quantity=1)

        self.assertEqual(len(result.equity_curve), len(dataset))
        self.assertEqual(result.initial_balance, 1_000)
        self.assertEqual(result.final_equity, result.equity_curve[-1])

    def test_backtest_uses_decision_pipeline(self):
        class SpyPipeline:
            def __init__(self):
                self.calls = []

            def decide(self, quote):
                self.calls.append(quote)
                return TradingDecisionPipeline("TEST").decide(quote)

        pipeline = SpyPipeline()
        engine = BacktestEngine(
            pipeline=pipeline,
            risk_manager=RiskManager(10),
            initial_balance=1_000,
        )
        dataset = make_dataset([100 + index for index in range(25)])

        engine.run(dataset)

        self.assertEqual(len(pipeline.calls), len(dataset))
        self.assertEqual(
            pipeline.calls[10].closes,
            tuple(c.close for c in dataset.candles[:11]),
        )
        self.assertEqual(
            pipeline.calls[10].candles,
            tuple(dataset.candles[:11]),
        )
        self.assertEqual(
            len(pipeline.calls[10].candles),
            len(pipeline.calls[10].closes),
        )

    def test_backtest_does_not_use_future_candles(self):
        closes = [100 - index for index in range(20)] + [
            80 + index for index in range(20)
        ]
        dataset = make_dataset(closes)
        engine = make_engine()

        first = engine.run(dataset)

        changed = list(dataset.candles)
        for index in range(25, len(changed)):
            candle = changed[index]
            changed[index] = HistoricalCandle(
                ticker=candle.ticker,
                timestamp=candle.timestamp,
                open=1_000,
                high=1_001,
                low=999,
                close=1_000,
                volume=999_999,
            )

        second = engine.run(Dataset.from_candles(changed))

        # Only candles before the modified suffix can be compared. Changes
        # from index 25 onward are allowed to change decisions from that point.
        first_prefix = [
            (trade.timestamp, trade.signal)
            for trade in first.trades
            if trade.timestamp < changed[25].timestamp
        ]
        second_prefix = [
            (trade.timestamp, trade.signal)
            for trade in second.trades
            if trade.timestamp < changed[25].timestamp
        ]
        self.assertEqual(first_prefix, second_prefix)

        self.assertEqual(
            first.equity_curve[:25],
            second.equity_curve[:25],
        )

    def test_persistent_buy_does_not_repeat_position(self):
        class BuyPipeline:
            def decide(self, quote):
                base = TradingDecisionPipeline("TEST").decide(quote)
                return type(base)(
                    regime=base.regime,
                    strategies=base.strategies,
                    meta=type(base.meta)(
                        signal="BUY",
                        confidence=1.0,
                        reason="persistent test",
                        contributors=(),
                    ),
                )

        result = BacktestEngine(
            pipeline=BuyPipeline(),
            risk_manager=RiskManager(10),
            initial_balance=1_000,
        ).run(make_dataset([100, 101, 102]), quantity=1)

        self.assertEqual(result.trade_count, 1)
        self.assertEqual(result.trades[0].signal, "BUY")

    def test_sell_when_flat_does_not_crash(self):
        class SellPipeline:
            def decide(self, quote):
                base = TradingDecisionPipeline("TEST").decide(quote)
                return type(base)(
                    regime=base.regime,
                    strategies=base.strategies,
                    meta=type(base.meta)(
                        signal="SELL",
                        confidence=1.0,
                        reason="test",
                        contributors=(),
                    ),
                )

        engine = BacktestEngine(
            pipeline=SellPipeline(),
            risk_manager=RiskManager(10),
            initial_balance=1_000,
        )

        result = engine.run(make_dataset([100, 101, 102]))

        self.assertEqual(result.trade_count, 0)
        self.assertEqual(len(result.equity_curve), 3)

    def test_realized_pnl_is_per_trade_not_cumulative(self):
        class BuySellPipeline:
            def __init__(self):
                self.index = 0

            def decide(self, quote):
                base = TradingDecisionPipeline("TEST").decide(quote)
                signal = "BUY" if self.index in {0, 2} else "SELL"
                self.index += 1
                return type(base)(
                    regime=base.regime,
                    strategies=base.strategies,
                    meta=type(base.meta)(
                        signal=signal,
                        confidence=1.0,
                        reason="test",
                        contributors=(),
                    ),
                )

        result = BacktestEngine(
            pipeline=BuySellPipeline(),
            risk_manager=RiskManager(100),
            initial_balance=1_000,
        ).run(make_dataset([100, 110, 90, 120]), quantity=1)

        self.assertEqual(result.trade_count, 4)
        self.assertAlmostEqual(result.trades[1].realized_pnl, 9.945, places=9)
        self.assertAlmostEqual(result.trades[3].realized_pnl, 29.94, places=9)

    def test_invalid_inputs_are_rejected(self):
        engine = make_engine()

        with self.assertRaises(ValueError):
            engine.run(make_dataset([100]), quantity=0)

        with self.assertRaises(ValueError):
            engine.run(Dataset.from_candles([]))

        with self.assertRaises(ValueError):
            BacktestEngine(
                pipeline=TradingDecisionPipeline("TEST"),
                risk_manager=RiskManager(),
                commission_rate=-0.01,
            )

    def test_max_drawdown_is_non_negative(self):
        dataset = make_dataset([100 + index for index in range(40)])
        result = make_engine().run(dataset)

        self.assertGreaterEqual(result.max_drawdown_percent, 0.0)


if __name__ == "__main__":
    unittest.main()
