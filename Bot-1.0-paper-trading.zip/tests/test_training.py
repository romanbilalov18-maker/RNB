import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

from bot.dataset import Dataset
from bot.features import FeatureEngine
from bot.models import HistoricalCandle
from bot.training import TrainingEngine, load_model
from bot.trade_memory import TradeDecision, TradeMemory, TradeResult


def make_dataset(size=80):
    base = datetime(2026, 1, 1, tzinfo=timezone.utc)
    close = 100.0
    candles = []
    for index in range(size):
        close += 1.0 if index % 2 == 0 else -0.7
        candles.append(
            HistoricalCandle(
                ticker="TEST",
                timestamp=base + timedelta(minutes=index),
                open=close - 0.2,
                high=close + 0.5,
                low=close - 0.5,
                close=close,
                volume=100 + index,
            )
        )
    return Dataset.from_candles(candles)


class TestTrainingEngine(unittest.TestCase):
    def test_training_samples_use_next_candle_only_as_target(self):
        dataset = make_dataset()
        engine = TrainingEngine(
            feature_engine=FeatureEngine(
                fast_period=3,
                slow_period=5,
                rsi_period=3,
                volatility_period=5,
                momentum_period=3,
                atr_period=3,
                volume_period=5,
            )
        )

        samples = engine.build_samples(dataset)

        self.assertGreater(len(samples), 0)
        self.assertEqual(samples[0].timestamp, dataset.candles[5].timestamp)
        self.assertEqual(samples[0].target, int(
            dataset.candles[6].close > dataset.candles[5].close
        ))

    def test_split_is_chronological(self):
        engine = TrainingEngine(
            feature_engine=FeatureEngine(
                fast_period=3,
                slow_period=5,
                rsi_period=3,
                volatility_period=5,
                momentum_period=3,
                atr_period=3,
                volume_period=5,
            ),
            train_ratio=0.75,
        )

        result = engine.train(make_dataset())

        self.assertGreater(result.train_size, result.validation_size)
        self.assertLess(
            result.train_samples[-1].timestamp,
            result.validation_samples[0].timestamp,
        )
        self.assertEqual(result.feature_names, (
            "sma_fast", "sma_slow", "ema_fast", "ema_slow",
            "return_1", "momentum", "volatility", "rsi", "atr",
            "volume_ratio",
        ))

    def test_model_can_predict(self):
        engine = TrainingEngine(
            feature_engine=FeatureEngine(
                fast_period=3,
                slow_period=5,
                rsi_period=3,
                volatility_period=5,
                momentum_period=3,
                atr_period=3,
                volume_period=5,
            )
        )
        result = engine.train(make_dataset())

        predictions = result.model.predict(
            [sample.values for sample in result.validation_samples]
        )

        self.assertEqual(len(predictions), result.validation_size)
        self.assertTrue(set(predictions).issubset({0, 1}))

    def test_model_can_be_saved_and_loaded(self):
        engine = TrainingEngine(
            feature_engine=FeatureEngine(
                fast_period=3,
                slow_period=5,
                rsi_period=3,
                volatility_period=5,
                momentum_period=3,
                atr_period=3,
                volume_period=5,
            )
        )
        result = engine.train(make_dataset())

        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "model.pkl"
            result.save(path)
            loaded = load_model(path)

            sample = result.validation_samples[0].values
            self.assertEqual(
                result.model.predict([sample]).tolist(),
                loaded.predict([sample]).tolist(),
            )

    def test_train_from_memory_uses_completed_trades_in_chronological_order(self):
        memory = TradeMemory()
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        for index in range(6):
            ts = base + timedelta(minutes=index)
            memory.record_decision(TradeDecision(
                timestamp=ts, ticker="TEST", signal="BUY", confidence=0.7,
                reason="memory", quantity=1, price=100.0,
                features=tuple(float(index + value) for value in range(10)),
            ))
            pnl = 1.0 if index % 2 == 0 else -1.0
            memory.record_result(ts, TradeResult(ts + timedelta(minutes=1), 101.0 if pnl > 0 else 99.0, pnl))

        result = TrainingEngine().train_from_memory(memory)
        self.assertEqual(result.train_size, 4)
        self.assertEqual(result.validation_size, 2)
        self.assertLess(result.train_samples[-1].timestamp, result.validation_samples[0].timestamp)
        self.assertIn("completed trade outcome", result.target_definition)

    def test_train_from_memory_requires_both_outcome_classes(self):
        memory = TradeMemory()
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        for index in range(4):
            ts = base + timedelta(minutes=index)
            memory.record_decision(TradeDecision(
                timestamp=ts, ticker="TEST", signal="BUY", confidence=0.7,
                reason="memory", quantity=1, price=100.0, features=(1.0,) * 10,
            ))
            memory.record_result(ts, TradeResult(ts + timedelta(minutes=1), 101.0, 1.0))
        with self.assertRaises(ValueError):
            TrainingEngine().train_from_memory(memory)

    def test_train_from_memory_does_not_auto_activate_model(self):
        memory = TradeMemory()
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        for index in range(4):
            ts = base + timedelta(minutes=index)
            memory.record_decision(TradeDecision(
                timestamp=ts, ticker="TEST", signal="BUY", confidence=0.7,
                reason="memory", quantity=1, price=100.0, features=(float(index),) * 10,
            ))
            memory.record_result(ts, TradeResult(ts + timedelta(minutes=1), 101.0 if index % 2 == 0 else 99.0, 1.0 if index % 2 == 0 else -1.0))
        result = TrainingEngine().train_from_memory(memory)
        self.assertIsNotNone(result.model)

    def test_invalid_training_configuration_is_rejected(self):
        with self.assertRaises(ValueError):
            TrainingEngine(train_ratio=0)

        with self.assertRaises(ValueError):
            TrainingEngine(max_iter=0)


if __name__ == "__main__":
    unittest.main()
