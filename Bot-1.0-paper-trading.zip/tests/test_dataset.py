import unittest
from datetime import datetime, timedelta, timezone

from bot.dataset import Dataset
from bot.models import HistoricalCandle


def candle(timestamp: datetime, close: float) -> HistoricalCandle:
    return HistoricalCandle(
        ticker="TEST",
        timestamp=timestamp,
        open=close - 1,
        high=close + 1,
        low=close - 2,
        close=close,
        volume=100,
    )


class TestDataset(unittest.TestCase):
    def test_normalizes_order_and_removes_duplicates(self):
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        dataset = Dataset.from_candles(
            [
                candle(base + timedelta(minutes=2), 102),
                candle(base, 100),
                candle(base + timedelta(minutes=1), 101),
                candle(base + timedelta(minutes=1), 999),
            ]
        )

        self.assertEqual(len(dataset), 3)
        self.assertEqual(dataset.closes(), (100, 101, 102))

    def test_rejects_invalid_candle(self):
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        invalid = HistoricalCandle(
            ticker="TEST",
            timestamp=base,
            open=100,
            high=90,
            low=80,
            close=85,
            volume=100,
        )

        with self.assertRaises(ValueError):
            Dataset((invalid,))

    def test_chronological_split_prevents_future_leakage(self):
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        dataset = Dataset.from_candles(
            [candle(base + timedelta(minutes=i), 100 + i) for i in range(10)]
        )

        train, test = dataset.split(0.7)

        self.assertEqual(len(train), 7)
        self.assertEqual(len(test), 3)
        self.assertLess(train.end, test.start)

    def test_invalid_split_ratio_rejected(self):
        dataset = Dataset(())
        with self.assertRaises(ValueError):
            dataset.split(1.0)


if __name__ == "__main__":
    unittest.main()
