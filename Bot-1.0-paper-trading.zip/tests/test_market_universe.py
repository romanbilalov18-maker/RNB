import unittest

from types import SimpleNamespace

from bot.market_universe import InstrumentInfo, MarketUniverseSnapshot


class TestMarketUniverse(unittest.TestCase):
    def test_groups_and_counts_instruments(self):
        snapshot = MarketUniverseSnapshot(
            instruments=(
                InstrumentInfo(
                    instrument_id="1",
                    figi="F1",
                    ticker="AAA",
                    name="A",
                    asset_type="share",
                    api_trade_available=True,
                    buy_available=True,
                    sell_available=True,
                ),
                InstrumentInfo(
                    instrument_id="2",
                    figi="F2",
                    ticker="BBB",
                    name="B",
                    asset_type="bond",
                    api_trade_available=True,
                    buy_available=False,
                    sell_available=True,
                ),
            ),
            refreshed_at=__import__("datetime").datetime.now(__import__("datetime").timezone.utc),
        )
        self.assertEqual(snapshot.summary()["total"], 2)
        self.assertEqual(snapshot.summary()["tradable"], 2)
        self.assertEqual(snapshot.summary()["by_type"], {"share": 1, "bond": 1})
        self.assertEqual(snapshot.summary()["tradable_by_type"], {"share": 1, "bond": 1})


if __name__ == "__main__":
    unittest.main()
