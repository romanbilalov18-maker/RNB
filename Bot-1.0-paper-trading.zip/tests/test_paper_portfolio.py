import unittest
from pathlib import Path

from bot.paper_portfolio import PaperPortfolioStore


class PaperPortfolioStoreTests(unittest.TestCase):
    TEST_DATA = Path(__file__).parent / "testdata"

    def setUp(self):
        self.TEST_DATA.mkdir(exist_ok=True)
        self.stores = []

    def tearDown(self):
        for store in self.stores:
            store.close()
        for path in self.TEST_DATA.glob("paper-*.sqlite3*"):
            path.unlink(missing_ok=True)

    def open_store(self, *args, **kwargs):
        store = PaperPortfolioStore(*args, **kwargs)
        self.stores.append(store)
        return store

    def test_initial_balance_is_granted_once_and_persists_across_instances(self):
        path = str(self.TEST_DATA / "paper-persistence.sqlite3")
        first = self.open_store(path, initial_cash=10_000)
        self.assertEqual(first.snapshot().cash, 10_000)
        first.execute("AAA", "BUY", 10, 100)
        first.close()

        reopened = self.open_store(path, initial_cash=20_000)
        self.assertEqual(reopened.snapshot().initial_cash, 10_000)
        self.assertEqual(reopened.snapshot().cash, 8_999.5)
        self.assertEqual(reopened.snapshot().positions["AAA"].quantity, 10)

    def test_buy_and_sell_update_cash_cost_basis_and_net_realized_profit(self):
        store = self.open_store(":memory:", initial_cash=10_000)
        store.execute("AAA", "BUY", 10, 100)
        bought = store.snapshot({"AAA": 100})
        self.assertEqual(bought.cash, 8_999.5)
        self.assertEqual(bought.positions["AAA"].average_price, 100.05)
        self.assertEqual(bought.total_commission, 0.5)

        store.execute("AAA", "SELL", 4, 110)
        sold = store.snapshot({"AAA": 110})
        self.assertEqual(sold.cash, 9_439.28)
        self.assertEqual(sold.positions["AAA"].quantity, 6)
        self.assertAlmostEqual(sold.realized_pnl, 39.58)
        self.assertEqual(sold.total_commission, 0.72)

    def test_rejected_orders_leave_portfolio_unchanged(self):
        store = self.open_store(":memory:", initial_cash=2_000)
        for args in (("AAA", "BUY", 12, 100, 5), ("AAA", "BUY", 20, 100, 1)):
            with self.assertRaises(ValueError):
                store.execute(*args[:4], lot_size=args[4])
        store.execute("AAA", "BUY", 10, 100)
        with self.assertRaises(ValueError):
            store.execute("AAA", "SELL", 12, 110)
        snapshot = store.snapshot()
        self.assertEqual(snapshot.cash, 999.5)
        self.assertEqual(snapshot.positions["AAA"].quantity, 10)

    def test_reset_requires_explicit_confirmation(self):
        store = self.open_store(":memory:", initial_cash=10_000)
        store.execute("AAA", "BUY", 1, 100)
        with self.assertRaises(ValueError):
            store.reset()
        self.assertEqual(store.snapshot().positions["AAA"].quantity, 1)
        store.reset(confirm=True)
        self.assertEqual(store.snapshot().cash, 10_000)
        self.assertEqual(store.snapshot().positions, {})

    def test_latest_mark_is_persisted_and_used_for_equity(self):
        path = str(self.TEST_DATA / "paper-marks.sqlite3")
        store = self.open_store(path)
        store.execute("AAA", "BUY", 10, 100)
        store.update_marks({"AAA": 110})
        store.close()
        reopened = self.open_store(path)
        self.assertEqual(reopened.snapshot().equity, 10_099.5)


if __name__ == "__main__":
    unittest.main()
