import unittest
from datetime import datetime, timedelta, timezone

from bot.features import FeatureEngine
from bot.models import DecisionContext, HistoricalCandle
from bot.training import TrainingEngine
from bot.dataset import Dataset
from bot.model_decision import ModelDecisionEngine


def make_dataset(size=80):
    base = datetime(2026, 1, 1, tzinfo=timezone.utc)
    close = 100.0
    candles = []
    for index in range(size):
        close += 1.0 if index % 2 == 0 else -0.7
        candles.append(
            HistoricalCandle(
                ticker="TEST",
                timestamp=base + timedelta(minutes=index),
                open=close - 0.2,
                high=close + 0.5,
                low=close - 0.5,
                close=close,
                volume=100 + index,
            )
        )
    return Dataset.from_candles(candles)


class TestModelDecisionEngine(unittest.TestCase):
    def setUp(self):
        self.dataset = make_dataset()
        self.features = FeatureEngine(
            fast_period=3, slow_period=5, rsi_period=3,
            volatility_period=5, momentum_period=3,
            atr_period=3, volume_period=5,
        )
        self.result = TrainingEngine(feature_engine=self.features).train(self.dataset)

    def test_model_produces_direction_and_confidence(self):
        engine = ModelDecisionEngine(self.result.model, self.features)
        result = engine.evaluate(DecisionContext("TEST", self.dataset.candles[-1].close, self.dataset.candles[-1].timestamp, self.dataset.candles))
        self.assertIn(result.signal, {"BUY", "SELL"})
        self.assertGreaterEqual(result.confidence, 0.5)
        self.assertLessEqual(result.confidence, 1.0)

    def test_warmup_returns_hold(self):
        engine = ModelDecisionEngine(self.result.model, self.features)
        candles = self.dataset.candles[:4]
        context = DecisionContext("TEST", candles[-1].close, candles[-1].timestamp, candles)
        result = engine.evaluate(context)
        self.assertEqual(result.signal, "HOLD")
        self.assertEqual(result.confidence, 0.0)

    def test_invalid_model_is_rejected(self):
        with self.assertRaises(ValueError):
            ModelDecisionEngine(object())

if __name__ == "__main__":
    unittest.main()
