import os
import unittest
from unittest.mock import patch

from bot.config import Config


class PaperConfigTests(unittest.TestCase):
    def test_defaults_are_a_ten_thousand_ruble_paper_account(self):
        config = Config()
        self.assertEqual(config.execution_mode, "paper")
        self.assertEqual(config.initial_balance, 10_000)
        self.assertEqual(config.paper_portfolio_path, "data/paper_portfolio.sqlite3")

    def test_environment_can_select_paper_settings(self):
        with patch.dict(os.environ, {
            "EXECUTION_MODE": "paper",
            "INITIAL_BALANCE": "12000",
            "PAPER_PORTFOLIO_PATH": "data/custom.sqlite3",
            "PAPER_SLIPPAGE_RATE": "0.002",
        }, clear=True):
            config = Config.from_env()
        self.assertEqual(config.initial_balance, 12_000)
        self.assertEqual(config.paper_portfolio_path, "data/custom.sqlite3")
        self.assertEqual(config.paper_slippage_rate, 0.002)

    def test_unknown_execution_mode_is_rejected(self):
        with patch.dict(os.environ, {"EXECUTION_MODE": "unsafe"}, clear=True):
            with self.assertRaises(ValueError):
                Config.from_env()


if __name__ == "__main__":
    unittest.main()
