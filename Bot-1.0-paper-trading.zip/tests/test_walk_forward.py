import unittest
from datetime import datetime, timedelta, timezone

from bot.dataset import Dataset
from bot.features import FeatureEngine
from bot.models import HistoricalCandle
from bot.training import TrainingEngine
from bot.walk_forward import WalkForwardEngine


def make_dataset(size=140):
    base = datetime(2026, 1, 1, tzinfo=timezone.utc)
    close = 100.0
    candles = []
    for index in range(size):
        close += 1.0 if index % 2 == 0 else -0.7
        candles.append(
            HistoricalCandle(
                ticker="TEST",
                timestamp=base + timedelta(minutes=index),
                open=close - 0.2,
                high=close + 0.5,
                low=close - 0.5,
                close=close,
                volume=100 + index,
            )
        )
    return Dataset.from_candles(candles)


def make_engine():
    return TrainingEngine(
        feature_engine=FeatureEngine(
            fast_period=3,
            slow_period=5,
            rsi_period=3,
            volatility_period=5,
            momentum_period=3,
            atr_period=3,
            volume_period=5,
        )
    )


class TestWalkForwardEngine(unittest.TestCase):
    def test_expanding_windows_are_chronological_and_non_overlapping(self):
        result = WalkForwardEngine(training_engine=make_engine()).run(
            make_dataset(),
            train_size=30,
            validation_size=10,
            step_size=10,
            expanding=True,
        )

        self.assertGreaterEqual(result.fold_count, 2)

        for fold in result.folds:
            self.assertLess(fold.train_end, fold.validation_start)
            self.assertEqual(fold.validation_size, 10)

        for previous, current in zip(result.folds, result.folds[1:]):
            self.assertLess(previous.validation_end, current.validation_start)
            self.assertGreaterEqual(current.train_size, previous.train_size)

        self.assertEqual(result.folds[0].train_size, 30)

    def test_rolling_windows_keep_fixed_train_size(self):
        result = WalkForwardEngine(training_engine=make_engine()).run(
            make_dataset(),
            train_size=30,
            validation_size=10,
            step_size=10,
            expanding=False,
        )

        self.assertGreaterEqual(result.fold_count, 2)
        self.assertTrue(all(fold.train_size == 30 for fold in result.folds))

    def test_aggregate_metrics_are_available(self):
        result = WalkForwardEngine(training_engine=make_engine()).run(
            make_dataset(),
            train_size=30,
            validation_size=10,
            step_size=10,
        )

        self.assertGreater(result.mean_accuracy, 0.0)
        self.assertGreater(result.mean_f1, 0.0)
        self.assertIsNotNone(result.mean_roc_auc)

    def test_future_data_does_not_change_earlier_fold(self):
        dataset = make_dataset()
        baseline = WalkForwardEngine(training_engine=make_engine()).run(
            dataset, train_size=30, validation_size=10, step_size=10
        )

        changed = list(dataset.candles)
        for index in range(100, len(changed)):
            candle = changed[index]
            changed[index] = HistoricalCandle(
                ticker=candle.ticker,
                timestamp=candle.timestamp,
                open=candle.open + 5000,
                high=candle.high + 5000,
                low=candle.low + 5000,
                close=candle.close + 5000,
                volume=candle.volume,
            )

        future_dataset = Dataset.from_candles(changed)
        future_result = WalkForwardEngine(training_engine=make_engine()).run(
            future_dataset, train_size=30, validation_size=10, step_size=10
        )

        self.assertEqual(
            baseline.folds[0].evaluation,
            future_result.folds[0].evaluation,
        )

    def test_run_samples_supports_trade_memory_outcome_samples(self):
        samples = tuple(
            __import__("bot.training", fromlist=["TrainingSample"]).TrainingSample(
                datetime(2026, 1, 1, tzinfo=timezone.utc) + timedelta(days=i),
                (float(i), float(i + 1)),
                i % 2,
            )
            for i in range(60)
        )
        result = WalkForwardEngine(training_engine=TrainingEngine()).run_samples(
            samples,
            train_size=20,
            validation_size=10,
            step_size=10,
        )
        self.assertGreaterEqual(result.fold_count, 3)
        self.assertLess(
            result.folds[0].train_end,
            result.folds[0].validation_start,
        )

    def test_invalid_window_configuration_is_rejected(self):
        engine = WalkForwardEngine(training_engine=make_engine())

        with self.assertRaises(ValueError):
            engine.run(make_dataset(), 0, 10, 10)

        with self.assertRaises(ValueError):
            engine.run(make_dataset(), 30, 0, 10)

        with self.assertRaises(ValueError):
            engine.run(make_dataset(), 30, 10, 0)

        with self.assertRaises(ValueError):
            engine.run(make_dataset(40), 30, 20, 10)


if __name__ == "__main__":
    unittest.main()
