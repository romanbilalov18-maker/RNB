import unittest
from datetime import datetime, timezone

from bot.trading_schedule import TradingSchedule


class TestTradingSchedule(unittest.TestCase):
    def test_uses_local_exchange_time(self):
        schedule = TradingSchedule()
        ts = datetime(2026, 9, 25, 7, 0, tzinfo=timezone.utc)
        self.assertTrue(schedule.is_open(ts))
        self.assertAlmostEqual(schedule.min_confidence(ts, 0.5), 0.40)

    def test_threshold_changes_by_session(self):
        schedule = TradingSchedule(
            "Europe/Moscow",
            (
                __import__("bot.trading_schedule", fromlist=["TradingWindow"]).TradingWindow(
                    __import__("datetime").time(9, 0),
                    __import__("datetime").time(11, 0),
                    0.30,
                ),
                __import__("bot.trading_schedule", fromlist=["TradingWindow"]).TradingWindow(
                    __import__("datetime").time(11, 0),
                    __import__("datetime").time(16, 0),
                    0.60,
                ),
            ),
        )
        morning = datetime(2026, 9, 25, 7, 30, tzinfo=timezone.utc)
        midday = datetime(2026, 9, 25, 10, 0, tzinfo=timezone.utc)
        self.assertAlmostEqual(schedule.min_confidence(morning, 0.5), 0.30)
        self.assertAlmostEqual(schedule.min_confidence(midday, 0.5), 0.60)

    def test_instrument_status_can_open_weekend_or_evening_session(self):
        calls = []

        def checker(instrument):
            calls.append(instrument)
            return instrument == "TEST"

        schedule = TradingSchedule(market_open_checker=checker)
        open_time = datetime(2026, 9, 26, 15, 0, tzinfo=timezone.utc)
        self.assertTrue(schedule.is_open(open_time, "TEST"))
        self.assertFalse(schedule.is_open(open_time, "OTHER"))
        self.assertEqual(calls, ["TEST", "OTHER"])

    def test_live_market_status_can_open_outside_fixed_window(self):
        schedule = TradingSchedule(market_open_checker=lambda _: True)
        closed = datetime(2026, 9, 26, 3, 0, tzinfo=timezone.utc)
        self.assertTrue(schedule.is_open(closed, "TEST"))

    def test_live_market_status_overrides_fixed_time_windows(self):
        schedule = TradingSchedule(market_open_checker=lambda _: True)
        closed_by_window = datetime(2026, 9, 26, 3, 0, tzinfo=timezone.utc)
        self.assertTrue(schedule.is_open(closed_by_window, "WEEKEND_INSTRUMENT"))

    def test_closed_outside_windows(self):
        schedule = TradingSchedule.from_env()
        closed = datetime(2026, 9, 25, 3, 0, tzinfo=timezone.utc)
        self.assertFalse(schedule.is_open(closed))
        self.assertIsNone(schedule.for_timestamp(closed))


if __name__ == "__main__":
    unittest.main()
