import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from bot.app import TradingBot
from bot.config import Config
from bot.market_regime import MarketRegime, RegimeResult
from bot.market import TBankMarketData
from bot.market_universe import InstrumentInfo, MarketUniverseSnapshot
from bot.models import HistoricalCandle, MarketQuote
from bot.paper_execution import PaperExecution


class PaperBotIntegrationTests(unittest.TestCase):
    TEST_DATA = Path(__file__).parent / "testdata"

    def setUp(self):
        self.TEST_DATA.mkdir(exist_ok=True)
        self.portfolio_path = self.TEST_DATA / "paper-bot.sqlite3"
        self.portfolio_path.unlink(missing_ok=True)

    def tearDown(self):
        for bot in getattr(self, "bots", []):
            bot.paper_portfolio.close()
        for path in self.TEST_DATA.glob("paper-bot.sqlite3*"):
            path.unlink(missing_ok=True)

    def create_bot(self, market_scan_enabled=False):
        with patch("bot.trading_schedule.ZoneInfo", return_value=timezone.utc):
            bot = TradingBot(Config(
                execution_mode="paper",
                invest_token="read-only-market-token",
                ticker="AAA",
                market_scan_enabled=market_scan_enabled,
                paper_portfolio_path=str(self.portfolio_path),
                performance_journal_path=":memory:",
            ))
        self.bots = getattr(self, "bots", []) + [bot]
        return bot

    def decision(self, signal="BUY"):
        return SimpleNamespace(
            regime=RegimeResult(MarketRegime.TREND, 0.01, 0.02, 1.0),
            strategies=(),
            meta=SimpleNamespace(
                signal=signal,
                confidence=0.9,
                reason="integration test",
                contributors=(),
            ),
            model=None,
            outcome=None,
        )

    def quote(self, price=100, age_seconds=0):
        now = datetime.now(timezone.utc) - timedelta(seconds=age_seconds)
        candles = tuple(
            HistoricalCandle(
                "AAA",
                now - timedelta(minutes=20 - i),
                100,
                103,
                97,
                100,
                1000,
            )
            for i in range(20)
        )
        return MarketQuote("AAA", price, now, tuple(100 for _ in candles), candles)

    def test_paper_cycle_persists_local_fill_without_sandbox_executor(self):
        bot = self.create_bot()
        quote = self.quote()
        bot.market = SimpleNamespace(get_quote=lambda ticker: quote)
        bot.pipeline.decide = lambda context: self.decision("BUY")

        result = bot.execute_signal(ticker="AAA")

        self.assertEqual(result["status"], "FILLED")
        self.assertIsInstance(bot.execution, PaperExecution)
        account = bot.paper_portfolio.snapshot({"AAA": quote.price})
        self.assertLess(account.cash, 10_000)
        self.assertGreater(account.positions["AAA"].quantity, 0)
        self.assertEqual(account.trade_count, 1)

    def test_stale_prepared_quote_cannot_create_a_virtual_trade(self):
        bot = self.create_bot()
        stale_quote = self.quote(age_seconds=300)
        bot.market = SimpleNamespace(get_quote=lambda ticker: stale_quote)
        bot.pipeline.decide = lambda context: self.decision("BUY")
        prepared = bot.prepare_signal("AAA")

        result = bot.execute_signal(ticker="AAA", prepared=prepared)

        self.assertEqual(result["status"], "REJECTED")
        self.assertEqual(bot.paper_portfolio.snapshot().cash, 10_000)
        self.assertEqual(bot.paper_portfolio.snapshot().trade_count, 0)

    def test_profit_target_sale_updates_balance_after_both_commissions(self):
        bot = self.create_bot()
        bot.market = SimpleNamespace(get_quote=lambda ticker: self.quote(price=100))
        bot.pipeline.decide = lambda context: self.decision("BUY")
        buy = bot.execute_signal(ticker="AAA")
        self.assertEqual(buy["status"], "FILLED")
        position = bot.paper_portfolio.snapshot().positions["AAA"]
        bot.market = SimpleNamespace(get_quote=lambda ticker: self.quote(price=position.target_price + 1))
        bot.pipeline.decide = lambda context: self.decision("HOLD")

        sell = bot.execute_signal(ticker="AAA")

        self.assertEqual(sell["status"], "FILLED")
        account = bot.paper_portfolio.snapshot()
        self.assertEqual(account.positions, {})
        self.assertGreater(account.cash, 10_000)
        self.assertGreater(account.realized_pnl, 0)
        self.assertEqual(account.trade_count, 2)

    def test_market_scan_evaluates_at_most_ten_liquid_ruble_shares(self):
        bot = self.create_bot(market_scan_enabled=True)
        now = datetime.now(timezone.utc)
        instruments = tuple(
            InstrumentInfo(
                instrument_id=f"UID{i:02}",
                figi=f"T{i:02}",
                ticker=f"T{i:02}",
                name=f"Test {i}",
                asset_type="share",
                currency="RUB",
                api_trade_available=True,
                buy_available=True,
                sell_available=True,
            )
            for i in range(12)
        )
        quotes = {}
        for i, instrument in enumerate(instruments):
            candles = tuple(
                HistoricalCandle(
                    instrument.figi,
                    now - timedelta(minutes=30 - index),
                    100,
                    101,
                    99,
                    100,
                    i + 1,
                )
                for index in range(30)
            )
            quotes[instrument.figi] = MarketQuote(
                instrument.figi, 100, now, tuple(100 for _ in candles), candles
            )

        class FakeTBankMarket(TBankMarketData):
            def get_universe(self, **kwargs):
                return MarketUniverseSnapshot(instruments, now)

            def get_last_prices(self, instrument_ids):
                return {instrument_id: 100 for instrument_id in instrument_ids}

            def get_quote(self, ticker):
                return quotes[ticker]

        bot.market = FakeTBankMarket.__new__(FakeTBankMarket)
        bot.pipeline = SimpleNamespace()
        bot._pipeline_for_ticker = lambda ticker: SimpleNamespace(
            decide=lambda context: self.decision("HOLD")
        )

        result = bot.execute_signal()

        self.assertEqual(result["candidate_pool"], 12)
        self.assertEqual(result["scanned"], 10)
        self.assertEqual(result["actionable"], 0)
        self.assertEqual(result["executed"], 0)


if __name__ == "__main__":
    unittest.main()
