import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path

from bot.performance_journal import PerformanceJournal


class TestPerformanceJournal(unittest.TestCase):
    def test_in_memory_journal_keeps_schema_and_records_across_operations(self):
        journal = PerformanceJournal(":memory:")
        journal.record_cycle(
            timestamp="2026-01-01T00:00:00+00:00",
            ticker="AAA",
            price=100,
            signal="HOLD",
            confidence=0,
            regime="RANGE",
            status="NO_TRADE",
            reason="test",
        )
        self.assertEqual(journal.snapshot().cycles, 1)

    def test_persists_cycles_and_trades(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = str(Path(tmp) / "journal.sqlite3")
            journal = PerformanceJournal(path)
            now = datetime.now(timezone.utc)

            journal.record_cycle(
                timestamp=now,
                ticker="TEST",
                price=100,
                signal="BUY",
                confidence=0.8,
                regime="TREND",
                status="FILLED",
                reason="test",
                quantity=10,
                position_before=0,
                position_after=10,
                equity=1000,
                cash=0,
            )
            journal.record_trade(
                timestamp=now,
                ticker="TEST",
                side="BUY",
                quantity=10,
                requested_price=100,
                executed_price=100,
                commission=0.5,
                status="FILLED",
                position_after=10,
                cash_after=0,
                equity_after=1000,
            )

            reopened = PerformanceJournal(path)
            snapshot = reopened.snapshot("TEST")
            self.assertEqual(snapshot.cycles, 1)
            self.assertEqual(snapshot.trades, 1)
            self.assertEqual(snapshot.filled_buys, 1)
            self.assertEqual(snapshot.filled_sells, 0)
            self.assertAlmostEqual(snapshot.total_commission, 0.5)
            self.assertEqual(snapshot.equity, 1000)

    def test_records_hold_cycles(self):
        with tempfile.TemporaryDirectory() as tmp:
            journal = PerformanceJournal(str(Path(tmp) / "journal.sqlite3"))
            journal.record_cycle(
                timestamp=datetime.now(timezone.utc),
                ticker="TEST",
                price=100,
                signal="HOLD",
                confidence=0.2,
                regime="LOW_VOLATILITY",
                status="NO_TRADE",
                reason="weak signal",
            )
            self.assertEqual(journal.snapshot("TEST").cycles, 1)
            self.assertEqual(journal.snapshot("TEST").trades, 0)


if __name__ == "__main__":
    unittest.main()
