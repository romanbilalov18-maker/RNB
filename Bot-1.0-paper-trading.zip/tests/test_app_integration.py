import unittest
from datetime import datetime, timezone
from types import SimpleNamespace

from bot.app import TradingBot
from bot.config import Config
from bot.models import HistoricalCandle, MarketQuote
from bot.meta_decision import MetaDecision
from bot.market_regime import MarketRegime, RegimeResult


class FakeMarket:
    def __init__(self, quote):
        self.quote = quote

    def get_quote(self, ticker):
        return self.quote


class TestTradingBotIntegration(unittest.TestCase):
    def _bot(self, closes):
        bot = TradingBot(
            Config(
                execution_mode="sandbox",
                initial_balance=1_000_000,
                max_position_percent=10,
                ticker="TEST",
                invest_token="test-token",
            )
        )
        bot.market = FakeMarket(
            MarketQuote(
                ticker="TEST",
                price=closes[-1],
                timestamp=datetime.now(timezone.utc),
                closes=tuple(closes),
                candles=tuple(
                    HistoricalCandle(
                        ticker="TEST",
                        timestamp=datetime(
                            2026, 1, 1, 0, index, tzinfo=timezone.utc
                        ),
                        open=close - 0.2,
                        high=close + 0.5,
                        low=close - 0.5,
                        close=close,
                        volume=100 + index,
                    )
                    for index, close in enumerate(closes)
                ),
            )
        )
        return bot

    def test_sandbox_is_used_for_integration(self):
        bot = self._bot([100 + index * 0.8 for index in range(30)])
        self.assertEqual(bot.config.execution_mode, "sandbox")

    def test_prepared_decision_is_not_recomputed_for_execution(self):
        bot = self._bot([100 + index * 0.8 for index in range(30)])
        regime = RegimeResult(
            regime=MarketRegime.TREND,
            volatility=0.01,
            trend_strength=0.02,
            confidence=1.0,
        )
        calls = {"count": 0}

        def decide(context):
            calls["count"] += 1
            return SimpleNamespace(
                regime=regime,
                meta=MetaDecision(
                    signal="BUY",
                    confidence=0.9,
                    reason="test buy",
                    contributors=(),
                ),
                model=None,
                outcome=None,
            )

        bot.pipeline.decide = decide

        class FakeSandboxExecution:
            def get_account_state(self, ticker, price):
                return SimpleNamespace(
                    cash=1_000_000.0,
                    equity=1_000_000.0,
                    position_quantity=0.0,
                    average_price=0.0,
                )

            def execute(self, order):
                return {
                    "status": "FILLED",
                    "quantity": order.quantity,
                    "position_quantity": order.quantity,
                    "price": order.price,
                }

        bot.execution = FakeSandboxExecution()
        prepared = bot.prepare_signal("TEST")
        first = bot.execute_signal(ticker="TEST", dry_run=True, prepared=prepared)
        second = bot.execute_signal(ticker="TEST", prepared=prepared)

        self.assertEqual(calls["count"], 1)
        self.assertEqual(first["status"], "SIGNAL_READY")
        self.assertEqual(second["status"], "FILLED")

    def test_sandbox_sell_requires_remote_position(self):
        bot = self._bot([100 + index * 0.8 for index in range(30)])
        regime = RegimeResult(
            regime=MarketRegime.TREND,
            volatility=0.02,
            trend_strength=0.02,
            confidence=1.0,
        )
        bot.pipeline.decide = lambda quote: SimpleNamespace(
            regime=regime,
            meta=MetaDecision(
                signal="SELL",
                confidence=0.8,
                reason="test sell",
                contributors=(),
            ),
        )

        class FakeSandboxExecution:
            def __init__(self):
                self.calls = 0

            def get_account_state(self, ticker, price):
                return SimpleNamespace(
                    cash=1_000_000.0,
                    equity=1_000_000.0,
                    position_quantity=0.0,
                    average_price=0.0,
                )

            def execute(self, order):
                self.calls += 1
                return {"status": "FILLED", "position_quantity": 0.0}

        execution = FakeSandboxExecution()
        bot.execution = execution

        result = bot.execute_signal()

        self.assertEqual(result["status"], "NO_TRADE")
        self.assertIn("no position", result["reason"].lower())
        self.assertEqual(execution.calls, 0)


if __name__ == "__main__":
    unittest.main()
