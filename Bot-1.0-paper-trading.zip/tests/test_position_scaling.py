import unittest
from datetime import datetime, timezone

from bot.market_regime import MarketRegime, RegimeResult
from bot.meta_decision import MetaDecision
from bot.models import DecisionContext, HistoricalCandle, SignalResult
from bot.position_manager import PositionManager


class Item:
    def __init__(self, signal):
        self.result = SignalResult("TEST", signal, 0.8, "test")


class TestPositionManager(unittest.TestCase):
    def setUp(self):
        candle = HistoricalCandle(
            "TEST", datetime.now(timezone.utc), 100, 101, 99, 100, 100
        )
        self.context = DecisionContext(
            "TEST", 100, candle.timestamp, (candle,) * 30
        )
        self.regime = RegimeResult(MarketRegime.TREND, 0.01, 0.02, 0.9)
        self.buy = MetaDecision(
            "BUY", 0.8, "consensus", ("sma_5_20", "sma_3_10")
        )
        self.sell = MetaDecision(
            "SELL", 0.8, "consensus", ("sma_5_20", "sma_3_10")
        )
        self.engine = PositionManager(max_position_percent=10.0)

    def test_buy_quantity_is_dynamic_not_fixed_chunk(self):
        d = self.engine.evaluate(
            self.context, self.regime, self.buy,
            current_quantity=0, average_price=0,
            equity=10_000, available_cash=10_000,
            strategy_results=(Item("BUY"), Item("BUY")),
        )
        self.assertEqual(d.action, "BUY")
        self.assertGreater(d.quantity, 0)
        self.assertEqual(d.target_quantity, d.quantity)
        self.assertNotEqual(d.quantity, 3)

    def test_stronger_existing_position_does_not_get_pyramided_beyond_target(self):
        d = self.engine.evaluate(
            self.context, self.regime, self.buy,
            current_quantity=8, average_price=100,
            equity=10_000, available_cash=10_000,
            strategy_results=(Item("BUY"), Item("BUY")),
        )
        self.assertEqual(d.action, "HOLD")
        self.assertEqual(d.remaining_quantity, 8)

    def test_cash_limits_buy_size(self):
        d = self.engine.evaluate(
            self.context, self.regime, self.buy,
            current_quantity=0, average_price=0,
            equity=10_000, available_cash=250,
            strategy_results=(Item("BUY"), Item("BUY")),
        )
        self.assertEqual(d.action, "BUY")
        self.assertEqual(d.quantity, 2)

    def test_sell_is_dynamic_and_partial(self):
        d = self.engine.evaluate(
            self.context, self.regime, self.sell,
            current_quantity=30, average_price=90,
            equity=10_000, available_cash=7_000,
            strategy_results=(Item("SELL"), Item("SELL")),
        )
        self.assertEqual(d.action, "SELL")
        self.assertGreater(d.quantity, 0)
        self.assertLess(d.quantity, 30)
        self.assertEqual(d.remaining_quantity, 30 - d.quantity)
        self.assertGreater(d.freed_cash, 0)
        self.assertGreater(d.estimated_realized_pnl, 0)
        self.assertEqual(d.capital_destination, "cash")

    def test_sell_cannot_exceed_position(self):
        d = self.engine.evaluate(
            self.context, self.regime, self.sell,
            current_quantity=1, average_price=90,
            equity=10_000, available_cash=9_900,
            strategy_results=(Item("SELL"), Item("SELL")),
        )
        self.assertEqual(d.action, "SELL")
        self.assertEqual(d.quantity, 1)
        self.assertEqual(d.remaining_quantity, 0)

    def test_sell_pnl_accounts_for_commission(self):
        engine = PositionManager(
            max_position_percent=10.0, commission_rate=0.01
        )
        d = engine.evaluate(
            self.context, self.regime, self.sell,
            current_quantity=10, average_price=90,
            equity=10_000, available_cash=9_000,
            strategy_results=(Item("SELL"), Item("SELL")),
        )
        self.assertEqual(d.action, "SELL")
        self.assertAlmostEqual(d.freed_cash, 792.0, places=6)
        self.assertAlmostEqual(d.estimated_realized_pnl, 72.0, places=6)

    def test_disagreement_reduces_signal_strength(self):
        weak_buy = MetaDecision("BUY", 0.3, "weak", ("sma_5_20",))
        d = self.engine.evaluate(
            self.context, self.regime, weak_buy,
            current_quantity=0, average_price=0,
            equity=10_000, available_cash=10_000,
            strategy_results=(Item("BUY"), Item("SELL")),
        )
        self.assertEqual(d.action, "HOLD")

    def test_no_strategy_agreement_blocks_position_change(self):
        d = self.engine.evaluate(
            self.context, self.regime, self.buy,
            current_quantity=0, average_price=0,
            equity=10_000, available_cash=10_000,
            strategy_results=(),
        )
        self.assertEqual(d.action, "HOLD")

    def test_non_trend_blocks_position_change(self):
        range_regime = RegimeResult(
            MarketRegime.RANGE, 0.01, 0.001, 0.9
        )
        d = self.engine.evaluate(
            self.context, range_regime, self.buy,
            current_quantity=0, average_price=0,
            equity=10_000, available_cash=10_000,
            strategy_results=(Item("BUY"), Item("BUY")),
        )
        self.assertEqual(d.action, "HOLD")

    def test_hold_signal_does_not_change_position(self):
        hold = MetaDecision("HOLD", 0.9, "no consensus", ())
        d = self.engine.evaluate(
            self.context, self.regime, hold,
            current_quantity=30, average_price=90,
            equity=10_000, available_cash=7_000,
            strategy_results=(Item("HOLD"), Item("HOLD")),
        )
        self.assertEqual(d.action, "HOLD")
        self.assertEqual(d.quantity, 0)
        self.assertEqual(d.remaining_quantity, 30)


if __name__ == "__main__":
    unittest.main()
