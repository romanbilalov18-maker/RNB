import unittest
from datetime import datetime, timezone

from bot.app import TradingBot
from bot.config import Config
from bot.models import DecisionContext, HistoricalCandle, MarketQuote, OrderRequest
from bot.meta_decision import MetaDecision
from bot.portfolio import Portfolio
from bot.risk import RiskManager
from bot.strategy import Strategy


class TestBotSkeleton(unittest.TestCase):
    def test_sandbox_is_default(self):
        bot = TradingBot(Config(execution_mode="sandbox", invest_token="test-token"))
        self.assertEqual(bot.status()["execution_mode"], "sandbox")

    def test_risk_limit(self):
        risk = RiskManager(10)
        order = OrderRequest("TEST", "BUY", 10, 100)
        self.assertTrue(risk.approve(order, 10_000))
        self.assertFalse(risk.approve(order, 9_999))

    def _context(self, closes):
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        candles = tuple(
            HistoricalCandle("TEST", base, close - 0.1, close + 0.1, close - 0.2, close, 100)
            for close in closes
        )
        return DecisionContext("TEST", closes[-1], base, candles)

    def test_strategy_holds_without_history(self):
        strategy = Strategy()
        result = strategy.evaluate(self._context((100, 101)))
        self.assertEqual(result.signal, "HOLD")

    def test_strategy_buy_crossover(self):
        strategy = Strategy(2, 4)
        result = strategy.evaluate(self._context((10, 9, 8, 7, 7, 9)))
        self.assertEqual(result.signal, "BUY")

    def test_strategy_sell_crossover(self):
        strategy = Strategy(2, 4)
        result = strategy.evaluate(self._context((7, 8, 9, 10, 10, 8)))
        self.assertEqual(result.signal, "SELL")

    def test_strategy_keeps_direction_after_crossover(self):
        strategy = Strategy(2, 4)
        result = strategy.evaluate(self._context((10, 9, 8, 7, 7, 9, 10)))
        self.assertEqual(result.signal, "BUY")
        self.assertGreaterEqual(result.confidence, 0.5)

    def test_strategy_holds_when_sma_spread_is_too_small(self):
        strategy = Strategy(2, 4, min_spread=0.01)
        result = strategy.evaluate(self._context((100, 100.01, 100.02, 100.03, 100.04)))
        self.assertEqual(result.signal, "HOLD")

    def test_risk_assessment_builds_order(self):
        risk = RiskManager(10)
        context = self._context((100, 101))
        decision = MetaDecision("BUY", 0.8, "test", ("strategy",))
        assessment = risk.assess(context, decision, 1, 10_000)
        self.assertTrue(assessment.approved)
        self.assertEqual(assessment.order.ticker, "TEST")
        self.assertEqual(assessment.order.price, 101)

    def test_risk_assessment_rejects_hold(self):
        risk = RiskManager(10)
        context = self._context((100, 101))
        decision = MetaDecision("HOLD", 0.0, "test", ())
        assessment = risk.assess(context, decision, 1, 10_000)
        self.assertFalse(assessment.approved)
        self.assertIsNone(assessment.order)

    def test_portfolio_buy_sell_and_pnl(self):
        portfolio = Portfolio(1_000)
        buy = portfolio.execute("TEST", "BUY", 5, 100)
        self.assertEqual(buy["status"], "FILLED")
        self.assertEqual(portfolio.positions["TEST"].quantity, 5)

        sell = portfolio.execute("TEST", "SELL", 5, 110)
        self.assertEqual(sell["status"], "FILLED")
        self.assertNotIn("TEST", portfolio.positions)
        self.assertGreater(portfolio.realized_pnl, 0)

    def test_portfolio_rejects_oversell(self):
        portfolio = Portfolio(1_000)
        with self.assertRaises(ValueError):
            portfolio.execute("TEST", "SELL", 1, 100)

    def test_portfolio_rejects_insufficient_cash(self):
        portfolio = Portfolio(100)
        with self.assertRaises(ValueError):
            portfolio.execute("TEST", "BUY", 2, 100)


if __name__ == "__main__":
    unittest.main()
