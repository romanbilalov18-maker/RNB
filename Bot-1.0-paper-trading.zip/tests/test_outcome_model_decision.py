import unittest
from datetime import datetime, timedelta, timezone

from bot.models import DecisionContext, HistoricalCandle, SignalResult
from bot.outcome_model_decision import OutcomeModelDecisionEngine


class TestOutcomeModelDecisionEngine(unittest.TestCase):
    def _context(self):
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        candles = tuple(
            HistoricalCandle(
                ticker="TEST",
                timestamp=base + timedelta(minutes=i),
                open=100 + i - 0.2,
                high=100 + i + 0.5,
                low=100 + i - 0.5,
                close=100 + i,
                volume=100 + i,
            )
            for i in range(40)
        )
        return DecisionContext(
            ticker="TEST",
            price=candles[-1].close,
            timestamp=candles[-1].timestamp,
            candles=candles,
        )

    def test_win_probability_keeps_candidate_direction(self):
        class Model:
            classes_ = [0, 1]

            def predict_proba(self, values):
                return [[0.2, 0.8] for _ in values]

            def predict(self, values):
                return [1 for _ in values]

        engine = OutcomeModelDecisionEngine(Model(), min_win_probability=0.7)
        result = engine.evaluate(
            self._context(),
            SignalResult("TEST", "BUY", 0.9, "candidate"),
        )
        self.assertEqual(result.signal, "BUY")
        self.assertAlmostEqual(result.confidence, 0.8)

    def test_low_win_probability_blocks_candidate(self):
        class Model:
            classes_ = [0, 1]

            def predict_proba(self, values):
                return [[0.8, 0.2] for _ in values]

            def predict(self, values):
                return [0 for _ in values]

        engine = OutcomeModelDecisionEngine(Model(), min_win_probability=0.5)
        result = engine.evaluate(
            self._context(),
            SignalResult("TEST", "SELL", 0.9, "candidate"),
        )
        self.assertEqual(result.signal, "HOLD")
        self.assertIn("Outcome gate rejected SELL", result.reason)

    def test_hold_is_not_changed(self):
        class Model:
            def predict_proba(self, values):
                raise AssertionError("model must not be called for HOLD")

        candidate = SignalResult("TEST", "HOLD", 0.0, "no signal")
        result = OutcomeModelDecisionEngine(Model()).evaluate(self._context(), candidate)
        self.assertEqual(result, candidate)


if __name__ == "__main__":
    unittest.main()
