import sys
import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch

from bot import __main__ as entrypoint


class PaperResetCliTests(unittest.TestCase):
    def test_reset_requires_explicit_yes_flag(self):
        with patch.object(sys, "argv", ["bot", "--reset-paper-portfolio"]):
            with patch.object(entrypoint.Config, "from_env", return_value=Mock(execution_mode="paper")):
                with patch.object(entrypoint, "TradingBot") as bot:
                    with self.assertRaises(SystemExit):
                        entrypoint.main()
                    bot.assert_not_called()

    def test_confirmed_reset_resets_portfolio_without_running_trading_cycles(self):
        with patch.object(sys, "argv", [
            "bot", "--reset-paper-portfolio", "--yes"
        ]):
            with patch.object(entrypoint.Config, "from_env", return_value=Mock(execution_mode="paper")):
                bot = Mock()
                bot.paper_portfolio.snapshot.return_value = SimpleNamespace(cash=10_000)
                with patch.object(entrypoint, "TradingBot", return_value=bot):
                    entrypoint.main()
        bot.paper_portfolio.reset.assert_called_once_with(confirm=True)
        bot.paper_portfolio.snapshot.assert_called_once()


if __name__ == "__main__":
    unittest.main()
