import unittest
from datetime import datetime, timedelta, timezone

from bot.models import DecisionContext, HistoricalCandle, SignalResult
from bot.multi_strategy import MultiStrategyEngine


class FakeStrategy:
    def __init__(self, name, signal, confidence=0.8):
        self.name = name
        self._signal = signal
        self._confidence = confidence

    def evaluate(self, context):
        return SignalResult(
            ticker="TEST",
            signal=self._signal,
            confidence=self._confidence,
            reason=f"{self.name} signal",
        )


class TestMultiStrategyEngine(unittest.TestCase):
    def _context(self, closes):
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        candles = tuple(
            HistoricalCandle(
                ticker="TEST",
                timestamp=base + timedelta(minutes=index),
                open=close - 0.2,
                high=close + 0.5,
                low=close - 0.5,
                close=close,
                volume=100,
            )
            for index, close in enumerate(closes)
        )
        return DecisionContext(
            ticker="TEST",
            price=closes[-1] if closes else 100.0,
            timestamp=candles[-1].timestamp if candles else base,
            candles=candles,
        )

    def test_all_strategies_are_evaluated(self):
        engine = MultiStrategyEngine(
            [
                FakeStrategy("trend", "BUY"),
                FakeStrategy("mean_reversion", "SELL"),
            ]
        )
        decisions = engine.evaluate(self._context([100.0, 101.0]))
        self.assertEqual(
            [decision.strategy_name for decision in decisions],
            ["trend", "mean_reversion"],
        )

    def test_majority_buy_consensus(self):
        engine = MultiStrategyEngine(
            [
                FakeStrategy("a", "BUY", 0.8),
                FakeStrategy("b", "BUY", 0.6),
                FakeStrategy("c", "SELL", 0.9),
            ]
        )
        result = engine.consensus(self._context([100.0, 101.0]))
        self.assertEqual(result.signal, "BUY")
        self.assertAlmostEqual(result.confidence, 0.7)
        self.assertIn("2/3", result.reason)

    def test_majority_sell_consensus(self):
        engine = MultiStrategyEngine(
            [
                FakeStrategy("a", "SELL"),
                FakeStrategy("b", "SELL"),
                FakeStrategy("c", "HOLD"),
            ]
        )
        self.assertEqual(engine.consensus(self._context([100.0, 101.0])).signal, "SELL")

    def test_tie_is_hold(self):
        engine = MultiStrategyEngine(
            [
                FakeStrategy("a", "BUY"),
                FakeStrategy("b", "SELL"),
            ]
        )
        result = engine.consensus(self._context([100.0, 101.0]))
        self.assertEqual(result.signal, "HOLD")
        self.assertEqual(result.confidence, 0.0)

    def test_empty_strategies_are_rejected(self):
        with self.assertRaises(ValueError):
            MultiStrategyEngine([])

    def test_duplicate_strategy_names_are_rejected(self):
        with self.assertRaises(ValueError):
            MultiStrategyEngine(
                [
                    FakeStrategy("same", "BUY"),
                    FakeStrategy("same", "SELL"),
                ]
            )

    def test_empty_closes_are_rejected(self):
        engine = MultiStrategyEngine([FakeStrategy("a", "BUY")])
        with self.assertRaises(ValueError):
            engine.evaluate(self._context([]))

    def test_strategy_results_are_preserved(self):
        engine = MultiStrategyEngine([FakeStrategy("a", "BUY", 0.73)])
        decision = engine.evaluate(self._context([100.0]))[0]
        self.assertEqual(decision.result.ticker, "TEST")
        self.assertEqual(decision.result.signal, "BUY")
        self.assertEqual(decision.result.confidence, 0.73)


if __name__ == "__main__":
    unittest.main()
