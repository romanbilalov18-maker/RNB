import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

from bot.models import DecisionContext, HistoricalCandle, OrderRequest
from bot.paper_execution import PaperExecution
from bot.paper_portfolio import PaperPortfolioStore


class PaperExecutionTests(unittest.TestCase):
    TEST_DATA = Path(__file__).parent / "testdata"

    def setUp(self):
        self.TEST_DATA.mkdir(exist_ok=True)
        self.store = PaperPortfolioStore(":memory:", initial_cash=10_000)

    def tearDown(self):
        self.store.close()

    def context(self, *, timestamp=None, candle_range=2.0, lot_size=1):
        now = timestamp or datetime.now(timezone.utc)
        candles = tuple(
            HistoricalCandle(
                ticker="AAA",
                timestamp=now - timedelta(minutes=20 - i),
                open=100.0,
                high=100.0 + candle_range,
                low=100.0 - candle_range,
                close=100.0,
                volume=1000,
            )
            for i in range(20)
        )
        return DecisionContext(
            ticker="AAA", price=100.0, timestamp=now, candles=candles, lot_size=lot_size
        )

    def test_buy_size_respects_cash_position_risk_and_lot_caps(self):
        execution = PaperExecution(self.store, max_position_percent=10, risk_per_trade_percent=1)
        result = execution.evaluate_buy(self.context(lot_size=5), equity=10_000, cash=10_000)
        self.assertTrue(result["approved"], result["reason"])
        self.assertEqual(result["quantity"], 5)
        self.assertEqual(result["quantity"] % 5, 0)
        self.assertGreater(result["target_price"], 100.4)

    def test_buy_is_rejected_when_history_does_not_support_fee_and_profit_target(self):
        execution = PaperExecution(
            self.store, min_net_profit_percent=0.2, slippage_rate=0.001
        )
        result = execution.evaluate_buy(
            self.context(candle_range=0.01), equity=10_000, cash=10_000
        )
        self.assertFalse(result["approved"])
        self.assertIn("fees", result["reason"].lower())

    def test_execution_rejects_stale_quote_without_changing_cash(self):
        execution = PaperExecution(self.store, max_quote_age_seconds=120)
        context = self.context(timestamp=datetime.now(timezone.utc) - timedelta(minutes=3))
        result = execution.execute(
            OrderRequest("AAA", "BUY", 1, 100), context
        )
        self.assertEqual(result["status"], "REJECTED")
        self.assertEqual(self.store.snapshot().cash, 10_000)
        self.assertIn("stale", result["reason"].lower())

    def test_position_exits_at_profit_target_or_risk_stop(self):
        execution = PaperExecution(self.store, stop_loss_percent=2)
        position = type(
            "Position", (), {"average_price": 100.0, "target_price": 101.0}
        )()
        self.assertEqual(
            execution.exit_reason(self.context(), position, 101.0), "TAKE_PROFIT"
        )
        self.assertEqual(
            execution.exit_reason(self.context(), position, 97.9), "STOP_LOSS"
        )
        self.assertIsNone(execution.exit_reason(self.context(), position, 100.0))


if __name__ == "__main__":
    unittest.main()
